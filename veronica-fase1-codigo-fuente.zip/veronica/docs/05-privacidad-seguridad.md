# 5. Privacidad y seguridad

## Qué sale de tu dispositivo, y cuándo
| Dato | ¿Sale? | Detalle |
|---|---|---|
| Audio mientras espera «Oye Verónica» | **Nunca** | Procesado en el dispositivo por Vosk; no se guarda ni se envía |
| Audio de la frase tras despertarla | Solo si configuraste voz a texto en la nube | Se envía a **tu** proveedor, se mantiene en memoria y no se escribe en disco |
| Texto de la conversación | Solo al proveedor de IA que configuraste | Más tus datos de memoria que ella decida usar para responder |
| Memoria, notas, tareas, historial | **Nunca** | Android: SQLite privada de la app. Windows: archivo cifrado con DPAPI |
| Claves de API | **Nunca** (salvo hacia su propio proveedor) | Android Keystore / DPAPI; no aparecen en registros |
| Modo «Solo en el equipo» | Nada sale | Solo comandos básicos y voz local |

No hay servidores de Verónica ni telemetría. `allowBackup=false` evita copias de seguridad de la base y las claves.

## Controles
- **Micrófono en pausa:** libera el micrófono por completo (el indicador del sistema se apaga). Notificación (Android), bandeja (Windows).
- **Indicador visual:** el símbolo aparece al despertar; el punto de micrófono del sistema nunca se oculta.
- **Memoria:** interruptor, lista, borrar uno o todo. **Modo privado:** no guarda historial ni memoria.
- **Historial:** se puede desactivar y borrar.
- **Confirmación por voz** para llamadas, SMS, apagado/reinicio/suspensión y cerrar ventanas. Sin respuesta clara cuenta como «no».
  Apagar/reiniciar en Windows esperan 15 s y se cancelan con «cancela el apagado».
- La IA no puede ejecutar comandos arbitrarios: solo las herramientas del catálogo, con argumentos acotados (`open_url` solo http/https).

## Permisos de Android y para qué
| Permiso | Uso |
|---|---|
| Micrófono, servicio en primer plano (micrófono) | Escuchar la palabra de activación y tus órdenes |
| Mostrar sobre otras apps | Dibujar el símbolo |
| Notificaciones | La notificación fija y los recordatorios |
| Contactos / Llamadas / SMS / Calendario | Solo para «llama a…», «envía…», «¿qué tengo hoy?». Sin ellos, abre el marcador o el compositor |
| Alarmas exactas | Recordatorios puntuales |
| Excluir de ahorro de batería | Que el sistema no mate la escucha |
| Acceso a notificaciones (opcional) | «¿Tengo notificaciones?» Lee las activas bajo demanda |
| Accesibilidad (opcional) | Inicio/atrás/recientes/captura. **No** lee el contenido de la pantalla |

## Riesgos que debes conocer
- Una persona que hable cerca puede darle órdenes (como a cualquier asistente de voz). Las acciones sensibles piden confirmación, pero
  no hay verificación de voz. Úsala sin confirmar solo en entornos que controles.
- Las respuestas de IA pueden equivocarse; para datos críticos (dosis, dinero, cifras legales) verifica en una fuente.
- Un proveedor de IA ve el texto que le envías: elige uno acorde a tu confianza, o usa un modelo local (Ollama).
- Un teléfono sin bloqueo de pantalla expone la memoria a quien lo tenga: mantén el bloqueo activado.
