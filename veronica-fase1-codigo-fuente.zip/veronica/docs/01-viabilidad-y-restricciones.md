# 1. Viabilidad técnica y restricciones reales

**Veredicto:** el proyecto es viable. Lo que pides existe hoy, con límites que ningún software puede saltarse.
Aquí está cada límite, su consecuencia y la mejor alternativa implementada. Nada se simula.

## Android

### 1.1 Escucha permanente
- Un servicio que graba el micrófono **debe** ser un *servicio en primer plano* de tipo `microphone`, con notificación visible
  y con el indicador de micrófono del sistema (punto verde). **No se puede ocultar** y Verónica no lo intenta.
- Desde Android 14, un servicio de micrófono **no puede iniciarse desde `BOOT_COMPLETED`**, y desde Android 12 tampoco desde segundo
  plano en general. Las excepciones documentadas por Android incluyen que **la app provea un `VoiceInteractionService`**
  (es decir, que sea el *asistente digital predeterminado*) o que el usuario toque una notificación.
- **Qué implementé:** `ListenService` (primer plano, micrófono) + `VeronicaInteractionService`. Si eliges a Verónica como asistente
  predeterminado, Android la reconecta tras reiniciar y ella reactiva la escucha sola. Si no, tras reiniciar recibes una notificación
  «Toca para reactivar» (tocarla sí está permitido). Además, mantener pulsado el botón de encendido invoca a Verónica.
- **Consecuencia:** sin ser asistente predeterminado, cada reinicio del teléfono exige un toque. Es una regla de Android, no un fallo.
- **Pendiente de validar en dispositivo real:** el comportamiento exacto de la excepción varía por fabricante y versión (13 a 16).

### 1.2 Detección local de la palabra
- El reconocimiento de palabra clave "de baja potencia" de Android (`AlwaysOnHotwordDetector`) está reservado a apps del sistema
  con permisos privilegiados. Una app normal **no puede usarlo**.
- **Qué implementé:** Vosk (código abierto, 100 % local) con gramática restringida a tus frases. Ventaja: cambias la palabra
  sin entrenar nada. Costo: consume más batería que un motor dedicado y puede activarse por error con sonidos parecidos.
- **Fase 2:** adaptador Porcupine (Picovoice): mucho más eficiente, requiere cuenta gratuita y entrenar «Oye Verónica» en su consola
  (uso personal gratuito; uso comercial requiere licencia).

### 1.3 Otras restricciones
| Restricción | Consecuencia | Qué hace Verónica |
|---|---|---|
| Solo un app puede grabar a la vez | Durante una llamada o grabación de otra app deja de oír | Reanuda sola al terminar |
| Pantalla bloqueada | Las superposiciones no se dibujan sobre el bloqueo; abrir apps suele exigir desbloquear | Puede oír y hablar; el símbolo aparece al desbloquear |
| Wi-Fi/Bluetooth/modo avión | Desde Android 10 una app no puede activarlos | Abre el panel de ajustes correspondiente |
| Cerrar apps de terceros | Android no permite matar otras apps | Ir a inicio / recientes / atrás vía Accesibilidad |
| Notificaciones | Solo con el acceso especial que tú concedes | Lee las activas bajo demanda, sin guardarlas |
| Ahorro de batería de fabricantes (Xiaomi, Huawei, Samsung…) | Pueden matar el servicio | Pide quitar la optimización; ver dontkillmyapp.com |
| Alarmas exactas (Android 12+) | Requieren permiso concedido por ti | Si falta, usa alarma aproximada |
| Tienda Google Play | Restringe SMS/llamadas, accesibilidad y exclusión de batería | Este APK es para instalación directa; ver `docs/06` |
| `targetSdk` | Play exige uno reciente para publicar | Está en 35; sube a lo que Play pida al publicar |

## Windows
- **Escucha permanente:** un proceso residente con el micrófono en modo compartido funciona sin trucos y sin servicio especial.
  Windows muestra su icono de micrófono mientras escucha (no se oculta). Debe estar activo *Configuración → Privacidad → Micrófono →
  Permitir que las aplicaciones de escritorio accedan*.
- **Sin escucha** con el equipo suspendido o apagado, ni antes de iniciar sesión.
- **Pantalla bloqueada:** oye, pero el símbolo no se muestra sobre la pantalla de bloqueo.
- **Juegos en pantalla completa exclusiva:** el símbolo puede no verse (en ventana sin bordes sí). El audio de Verónica sí se oye.
- **Eco:** Windows no cancela el eco del altavoz hacia el micrófono, por eso la interrupción por voz mientras habla está desactivada
  por defecto (actívala con audífonos). Siempre queda Ctrl + Alt + V.
- **Privilegios:** corre como usuario normal. Apagar/reiniciar usan `shutdown` con 15 s de gracia cancelables.
- **Vosk en Windows:** el modelo pequeño usa ~40 MB de disco y unos pocos puntos de CPU; el símbolo no consume nada mientras está oculto.

## Lo que sí requiere algo de ti
| Capacidad | Necesita |
|---|---|
| Conversación inteligente | Clave de API de un proveedor de IA (ver `docs/04`) |
| Voz a texto de alta calidad | Clave de un servicio compatible (Groq/OpenAI) — sin ella usa el reconocimiento local, menos preciso |
| Voz neuronal muy natural | Clave de un servicio de voz (opcional); la voz del sistema es gratis |
| Búsqueda web general | Clave de Tavily (opcional); sin ella usa Wikipedia |
| Clima, noticias, divisas | Nada (servicios abiertos) |
| Calendarios en Windows, contactos en Windows | Fase 2 (Microsoft Graph / OAuth) |
