# 3. Instalación y configuración

> El código no se ha compilado todavía (ver README). El camino más corto es dejar que GitHub lo compile y te entregue los archivos.

## A. Obtener el APK, el AAB y el EXE (sin instalar nada)
1. Crea un repositorio privado en GitHub y sube **toda** esta carpeta.
2. Pestaña **Actions → build → Run workflow**. Tarda unos 5–10 min.
3. Al terminar, descarga los artefactos: `veronica-android` (APK de depuración + AAB sin firmar) y `veronica-windows` (`Veronica.exe`).
4. Si el flujo falla, copia el error de la sección roja y pégamelo: se corrige rápido.

### Compilar a mano (opcional)
- **Android:** instala Android Studio, abre la carpeta `android/`, deja que sincronice (genera el *Gradle wrapper*) y usa *Build → Build APK(s)*.
  Por consola: `gradle -p android :app:assembleDebug` (APK) y `gradle -p android :app:bundleRelease` (AAB).
- **Windows:** instala el SDK de .NET 8 y ejecuta
  `dotnet publish windows/Veronica/Veronica.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o out`.

### Firmar el AAB para Google Play
Crea un almacén de claves con `keytool` y define antes de compilar: `VERONICA_KEYSTORE`, `VERONICA_KS_PASS`, `VERONICA_KEY_ALIAS`, `VERONICA_KEY_PASS`.
Guárdalo fuera del repositorio. Antes de publicar lee `docs/06` (políticas de Play sobre SMS, llamadas y accesibilidad).

## B. Instalar y configurar en Android (≈10 min)
1. Instala el APK (permite «instalar apps de origen desconocido» para tu navegador o gestor de archivos).
2. Abre **Verónica**. En **Permisos y requisitos**, de arriba abajo:
   1. **Micrófono** → Conceder. 2. **Notificaciones** (Android 13+).
   3. **Mostrar sobre otras apps** → activa para Verónica (es donde aparece su símbolo).
   4. **Modelo de voz local** → Descargar (≈40 MB, una vez; después funciona sin Internet).
   5. **Asistente digital predeterminado** → elige *Verónica*. **Es el paso que permite que se reactive sola tras reiniciar.**
   6. **Sin restricción de batería** → Permitir.
   7. Contactos, llamadas, SMS y calendario → Conceder solo lo que quieras que use.
   8. Opcionales: *Leer notificaciones* y *Accesibilidad* (inicio, atrás, capturas). Android te mostrará advertencias: son normales.
3. En **Inteligencia artificial** pega tu clave (ver `docs/04`). Pon tu **ciudad** para el clima.
4. Activa **Escuchar «Oye Verónica»**. Aparece una notificación fija y el punto de micrófono del sistema: es obligatorio.
5. Prueba: *«Oye Verónica»* → «Aquí estoy» → *«¿qué hora es?»* (esta no usa Internet).
6. **Xiaomi / Huawei / Samsung / OPPO:** además fija la app en recientes y desactiva el «ahorro de batería inteligente» para Verónica.

Uso sin abrir la app: di «Oye Verónica», o mantén pulsado el botón de encendido (si es tu asistente), o toca el símbolo mientras esté visible.

## C. Instalar y configurar en Windows (≈5 min)
1. Copia `Veronica.exe` a una carpeta fija (p. ej. `C:\Users\tú\Apps\Veronica`). Si SmartScreen avisa, *Más información → Ejecutar de todos modos* (el EXE no está firmado; ver `docs/06`).
2. Se abre la **Configuración** (la primera vez). **Estado → Descargar modelo de voz**.
3. Pestaña **Inteligencia**: pega tu clave (ver `docs/04`) y la ciudad.
4. **Estado → Iniciar con Windows** (opcional, requiere tu autorización: la escribes tú). Al arrancar así queda en la bandeja, sin ventana.
5. Verás un icono en la bandeja (junto al reloj). Clic derecho: *Activar ahora*, *Micrófono en pausa*, *Configuración*, *Salir*.
6. Prueba: *«Oye Verónica»* → *«abre la calculadora»*. Atajo manual: **Ctrl + Alt + V**.
7. Si no te oye: *Configuración de Windows → Privacidad y seguridad → Micrófono* → permite el acceso a apps de escritorio.

## D. Cambiar la palabra de activación
Ajustes → palabras separadas por comas (p. ej. `oye verónica, hey vero, computadora`). Reinicia la escucha.
Elige frases de 2–3 sílabas o más y distintas de palabras comunes: las muy cortas generan falsas activaciones.

## E. Problemas frecuentes
| Síntoma | Causa probable | Solución |
|---|---|---|
| No se activa nunca | Falta el modelo, o permiso de micrófono | Revisa los ✓ de Permisos (Android) o el estado (Windows) |
| Se activa sin que la llame | Frase muy corta o ruido | Usa «oye verónica» sola; sube el umbral en Fase 2 |
| Tras reiniciar el móvil no escucha | No es el asistente predeterminado | Paso B.2.5, o toca la notificación «Toca para reactivar» |
| Oigo el saludo pero no entiende órdenes | STT en la nube sin clave: usa el modo local | Agrega la clave de voz a texto (`docs/04`) |
| «No pude conectarme con mi inteligencia» | Clave, URL o modelo incorrectos | Revisa en `docs/04`; los nombres de modelo cambian con el tiempo |
| El símbolo no aparece (Android) | Falta «Mostrar sobre otras apps» | Paso B.2.3 |
| No abre una app (Android) | Solo ve apps con icono de lanzador | Dile el nombre tal como aparece en tu menú |
