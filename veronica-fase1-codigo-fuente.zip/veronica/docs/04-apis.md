# 4. Configuración de las APIs

Verónica no incluye ninguna clave. Las pegas en Ajustes; se guardan **cifradas** (Android Keystore / DPAPI de Windows).
Los nombres de modelos y los precios cambian: **confirma en la documentación del proveedor** antes de elegir.

## 4.1 Cerebro (IA)
| Proveedor | Ajuste «Proveedor» | URL base | Modelo de ejemplo | Dónde sacar la clave |
|---|---|---|---|---|
| Anthropic | `anthropic` | `https://api.anthropic.com` | `claude-haiku-5-5` (rápido y económico) | console.anthropic.com |
| OpenAI | `openai` | `https://api.openai.com/v1` | uno de la serie «mini» vigente | platform.openai.com |
| Groq | `openai` | `https://api.groq.com/openai/v1` | un modelo Llama vigente | console.groq.com |
| Google Gemini | `openai` | `https://generativelanguage.googleapis.com/v1beta/openai` | un modelo Gemini «flash» | aistudio.google.com |
| OpenRouter | `openai` | `https://openrouter.ai/api/v1` | cualquiera de su catálogo | openrouter.ai |
| Ollama / LM Studio (local) | `openai` | `http://IP-del-equipo:11434/v1` | el que hayas descargado | (sin clave) |

Para voz conviene un modelo **rápido** (la latencia se nota al hablar) antes que el más grande.
> Local sin cifrar (`http://`): Android bloquea por defecto el tráfico sin HTTPS. Para usar Ollama en tu red, ponlo detrás de HTTPS
> o añade `android:usesCleartextTraffic="true"` al manifiesto (reduce la seguridad; solo en tu red doméstica).
> En Windows funciona directo.

## 4.2 Voz a texto (muy recomendable)
Cualquier servicio con el endpoint `/audio/transcriptions` compatible con OpenAI.
| Servicio | URL base | Modelo de ejemplo |
|---|---|---|
| OpenAI | `https://api.openai.com/v1` | `whisper-1` o uno de transcripción vigente |
| Groq | `https://api.groq.com/openai/v1` | `whisper-large-v3-turbo` |

Si dejas la clave de voz vacía se reutiliza la del cerebro (útil si usas Groq u OpenAI para ambos).
**Sin clave** usa el reconocimiento local Vosk: funciona sin Internet pero entiende peor frases largas.
Qué se envía: solo el audio de la frase tras despertarla, nunca el audio de espera.

## 4.3 Texto a voz
- **Del sistema (predeterminado):** gratis y sin Internet. En Android mejora instalando voces *es-MX* en Google TTS (Ajustes → Idioma → Salida de texto a voz).
  En Windows usa la voz es-MX instalada (p. ej. Sabina) si existe.
- **Neuronal en la nube:** `/audio/speech` compatible con OpenAI (p. ej. `gpt-4o-mini-tts`, voz `nova` o `coral`). Más natural, de pago.
  Cambia «Voz» a **Neuronal (nube)** (Android) / `cloud` (Windows). Si la nube falla, vuelve sola a la del sistema.

## 4.4 Búsqueda web (opcional)
Tavily (tavily.com): plan gratuito mensual limitado. Pega la clave en «Clave de Tavily».
Sin ella: respaldo con Wikipedia en español.

## 4.5 Sin clave (siempre disponible)
Clima y geocodificación: Open-Meteo. Noticias: Google News RSS. Divisas: Frankfurter (Banco Central Europeo; no incluye todas las monedas).

## 4.6 Combinación recomendada para empezar con el menor costo
1. Cuenta gratuita en Groq → una sola clave para **cerebro + voz a texto** (proveedor `openai`, URLs de Groq).
2. Voz del sistema.
3. Ciudad configurada. Con eso: conversación, órdenes, clima, noticias y divisas.
4. Cuando quieras más naturalidad, activa la voz neuronal; para buscar en Internet, agrega Tavily.

## 4.7 Cómo probar que quedó bien
1. *«Oye Verónica, ¿qué hora es?»* → responde sin Internet (prueba micrófono, modelo local y voz).
2. *«¿Cuánto es 15 por ciento de 2300?»* → usa IA + calculadora (prueba la clave del cerebro).
3. *«¿Qué tiempo hace mañana?»* → prueba herramientas de red y tu ciudad.
4. *«Recuerda que mi app de música es Spotify»* → revisa en Memoria que apareció.
