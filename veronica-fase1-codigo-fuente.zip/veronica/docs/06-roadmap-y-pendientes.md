# 6. Hoja de ruta y pendientes

## Fase 1 (esta entrega, sin compilar/probar)
Activación por voz local, símbolo animado, conversación con contexto, memoria, 39 herramientas (Android 33 / Windows 25), configuración,
privacidad, compilación en la nube. **Primer hito: que compile y corra en tu equipo.** Espera un ciclo corto de corrección de errores.

## Fase 2 — calidad y consumo
- Adaptador **Porcupine** para la palabra de activación (menos batería, menos falsas activaciones).
- **Respuesta en streaming** y TTS por frases: el primer sonido llega antes (hoy espera la respuesta completa).
- Voz y reconocimiento con **cancelación de eco** también en Windows (barge-in sin audífonos).
- Actualizaciones automáticas en Windows (Velopack o GitHub Releases) y EXE firmado.
- Ajuste de sensibilidad de activación y prueba de la palabra en Ajustes.
- Calendario/contactos en Windows (Microsoft Graph) y creación de documentos (Markdown/Word) en ambas.
- Reconocimiento de voz del sistema como STT sin clave en Android; selección de voz del sistema desde una lista.
- Pruebas automáticas (enrutador de órdenes, calculadora, intérprete de respuestas) y en dispositivos reales (Samsung, Xiaomi, Pixel).

## Fase 3 — plataforma
- **Panel HTML complementario: sí conviene**, solo como administración (no activación). Se sirve en `localhost` desde la app de Windows
  y permite ajustes, memoria, historial, voces e integraciones con mejor edición. Para el teléfono, solo con sincronización cifrada
  explícita; hasta entonces la configuración nativa ya cubre el caso. La activación por voz seguirá 100 % nativa.
- Integraciones: Google Calendar/Gmail, Home Assistant, Spotify, mensajería.
- Vinculación de dispositivos (teléfono ⇄ PC) con cifrado de extremo a extremo.
- Perfil de voz del dueño para sensibilizar las acciones.

## Si quieres publicar en Google Play
- Cambiar `targetSdk` al nivel que Play exija en ese momento.
- Separar una variante «play» sin `SEND_SMS` (enviar solo vía el compositor) y revisar el uso de Accesibilidad y la exclusión de batería
  (declaraciones y justificación obligatorias).
- Política de privacidad pública y declaración de datos.
- AAB firmado (ver `docs/03`).

## Conocido / limitaciones de la Fase 1
- No hay detección de la propia voz en altavoz en Windows (por eso `BargeIn` desactivado por defecto).
- La palabra de activación por gramática puede fallar con ruido fuerte o con una voz muy distinta; prueba y ajusta frases.
- `play_music` y `open_app` dependen de qué apps expongan los intents estándar; algunas respuestas varían por fabricante.
- Los saludos hablados añaden ≈1 s antes de escuchar; cámbialos a «tono» para más velocidad.
- La orden en una sola frase («Oye Verónica, abre WhatsApp») aún no se captura de corrido: dices el nombre, esperas el saludo o el tono, y dices la orden.
