# 2. Arquitectura

## Principios
1. **El micrófono tiene un solo dueño** (`AudioEngine`) y tres modos sin soltarlo: espera de palabra (Vosk), captura de frase (VAD) y sí/no (Vosk).
2. **Todo lo cambiable está tras una interfaz:** proveedor de IA, voz a texto, texto a voz, herramientas.
3. **Una sola fuente de verdad** para personalidad y herramientas: `shared/`. Se incrusta en ambas apps en la compilación.
4. **El código de la plataforma solo ejecuta**; la decisión de qué hacer está en el agente (idéntico en diseño en ambas).

## Flujo
```
 micrófono ─► AudioEngine ──(frase de activación, local)──► Conductor ──► símbolo (Orb)
                 ▲  ▲                                          │
                 │  └── sí/no (local) ◄── confirmar ◄──────────┤
                 │                                             ▼
          captura de frase ──► STT ──► texto ──► Agent ──┬─► OfflineRouter (orden directa, sin IA)
                                                          └─► LLM ⇄ ToolRegistry ⇄ herramientas del dispositivo
                                                                    │
                          Memoria (hechos/notas/tareas/historial) ◄─┘
                                                                    ▼
                                              respuesta ──► TTS ──► voz ──► (seguimiento) ──► espera
```

## Máquina de estados (símbolo)
`OFF` (apagada) · `IDLE` (espera, oculto) · `LISTENING` (pulsos con tu voz) · `THINKING` (energía en movimiento) ·
`SPEAKING` (anillo ondulado) · `EXECUTING` (arco dorado) · `ERROR` (rojo, tiembla).

## Decisión en tres niveles
| Nivel | Qué | Dónde |
|---|---|---|
| 1. Orden directa | «abre WhatsApp», «temporizador de 10 minutos», «sube el volumen», «qué hora es». Sin IA, sin Internet, instantáneo | `OfflineRouter` |
| 2. Agente | Preguntas, razonamiento, varias acciones. Bucle de hasta 4 vueltas modelo ⇄ herramientas | `Agent` + `ILlm` |
| 3. Respaldo | Sin Internet o sin clave: explica qué sí puede hacer | `Agent` |

Cada herramienta declara en `shared/tools.json` su **riesgo**: sin `confirm` se ejecuta; con `confirm` (y opcionalmente `confirm_if`,
p. ej. solo para `shutdown`/`restart`) Verónica **pregunta en voz alta y escucha sí/no localmente**. Sin respuesta clara = no.
Si falta un permiso del sistema, la herramienta lo devuelve como texto y la IA te lo explica.

## Protocolo con el modelo
El modelo responde siempre un JSON: `{"say":"…","tools":[{"name":"…","args":{…}}],"follow_up":"ask|open|close"}`.
Funciona con cualquier proveedor (no depende de funciones nativas de cada API). `follow_up` decide si ella sigue escuchando.
Los resultados vuelven como `RESULTADOS_DE_HERRAMIENTAS:` y el modelo los resume. Contexto: últimos 16 mensajes, expira a los 10 min.

## Proveedores
| Capa | Interfaz | Implementaciones Fase 1 |
|---|---|---|
| IA | `LlmProvider` / `ILlm` | Anthropic; compatible OpenAI (OpenAI, Groq, Gemini, OpenRouter, Ollama, LM Studio…) |
| Voz a texto | `Stt` | Nube compatible OpenAI (`/audio/transcriptions`); Vosk local de respaldo |
| Texto a voz | `SpeakerHub` | Voz del sistema; neuronal en nube (`/audio/speech`); respaldo automático al sistema |
| Palabra clave | `AudioEngine` | Vosk con gramática (Fase 2: Porcupine) |

**Añadir un proveedor:** implementa la interfaz (≈30 líneas), añádelo a `Llms.current()` y a la lista de ajustes.
**Añadir una herramienta:** una entrada en `shared/tools.json` + un `h("nombre") { … }` (Android) o `H/HS("nombre", …)` (Windows).
Si falta uno de los dos lados, la herramienta responde «aún no implementada» en esa plataforma; no falla.

## Android: piezas
| Archivo | Rol |
|---|---|
| `service/ListenService` | Servicio en primer plano (micrófono) + notificación con Pausar/Detener |
| `service/VoiceInteraction` | Asistente digital predeterminado: ancla del sistema, reconexión tras reinicio, gesto de encendido |
| `service/Conductor` | Orquesta el ciclo; una sesión a la vez; interrupción por voz |
| `voice/*` | `AudioEngine`, `ModelManager`, `Stt`, `Tts` |
| `ai/*` | `Llm`, `Agent`, `OfflineRouter` |
| `tools/*` | `ToolRegistry`, `AndroidTools`, `WebTools`, `Reminders` |
| `service/SystemHooks` | Arranque, lector de notificaciones, accesibilidad (solo acciones globales), reconocimiento (requerido por el sistema) |
| `ui/OrbView`, `OverlayController` | Símbolo (Canvas, mezcla aditiva) y ventana flotante |
| `ui/SettingsActivity` | Configuración completa (Compose) |

## Windows: piezas
`Program` (bandeja, instancia única) · `Conductor` · `Voice` (`AudioEngine`, `Stt`, `SystemTts`, `CloudTts`) · `Agent` ·
`Core` (ajustes cifrados, memoria, LLM, calculadora, web) · `Tools` (herramientas, índice de apps, recordatorios) ·
`Ui` (símbolo WPF, ventana flotante sin foco ni clics, configuración).

## Memoria
- Android: SQLite privada de la app. Windows: archivo cifrado con DPAPI (solo tu usuario de Windows lo abre).
- Tablas: hechos (clave/valor), notas, tareas, historial, recordatorios.
- Los hechos se inyectan en el prompt en cada turno; ella los usa para responder «¿cuál es mi app de música?».
- Se guardan solo con tu autorización (interruptor), nunca en modo privado, y se pueden ver, borrar uno o borrar todo.
