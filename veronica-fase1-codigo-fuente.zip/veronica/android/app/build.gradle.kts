plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "mx.veronica"
    compileSdk = 35

    defaultConfig {
        applicationId = "mx.veronica.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") }
    }

    // Firma de release: solo si defines estas variables de entorno (ver docs/03).
    signingConfigs {
        create("release") {
            System.getenv("VERONICA_KEYSTORE")?.let {
                storeFile = file(it)
                storePassword = System.getenv("VERONICA_KS_PASS")
                keyAlias = System.getenv("VERONICA_KEY_ALIAS")
                keyPassword = System.getenv("VERONICA_KEY_PASS")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release").takeIf { it.storeFile != null }
        }
    }

    // El prompt y el catálogo de herramientas se comparten con la versión Windows.
    sourceSets["main"].assets.srcDirs("src/main/assets", "../../shared")

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // Reconocimiento local (palabra de activación, sí/no y respaldo sin Internet)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
}
