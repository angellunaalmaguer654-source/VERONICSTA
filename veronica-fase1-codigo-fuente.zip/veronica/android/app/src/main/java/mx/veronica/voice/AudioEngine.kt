package mx.veronica.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.SystemClock
import kotlinx.coroutines.*
import mx.veronica.util.Text
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Único dueño del micrófono (Android solo permite un consumidor a la vez).
 * Un solo bucle de lectura alterna entre tres modos sin soltar el micrófono:
 *  WAKE    - Vosk con gramática restringida a la palabra de activación (100 % local).
 *  CAPTURE - graba una frase y detecta el final con un detector de actividad de voz (VAD).
 *  YESNO   - Vosk con gramática de sí/no para las confirmaciones (100 % local).
 */
class AudioEngine(private val ctx: Context, private val models: ModelManager) {
    companion object { const val RATE = 16000 }
    private enum class Mode { WAKE, CAPTURE, YESNO }

    @Volatile private var mode = Mode.WAKE
    @Volatile private var capture: Capture? = null
    @Volatile private var yesNo: YesNo? = null
    private var job: Job? = null

    var onLevel: (Float) -> Unit = {}
    var onFail: (String) -> Unit = {}
    val running get() = job?.isActive == true

    fun start(scope: CoroutineScope, phrases: List<String>, onWake: () -> Unit) {
        if (running) return
        job = scope.launch(Dispatchers.IO) { loop(phrases, onWake) }
    }

    /** Suelta el micrófono por completo (el indicador de privacidad del sistema se apaga). */
    fun stop() { job?.cancel(); job = null }

    suspend fun captureUtterance(timeoutMs: Long = 8000, maxMs: Long = 15000): ByteArray? {
        if (!running) return null
        val c = Capture(timeoutMs, maxMs)
        capture = c; mode = Mode.CAPTURE
        return try { c.done.await() } finally { mode = Mode.WAKE; capture = null }
    }

    suspend fun listenYesNo(timeoutMs: Long = 7000): Boolean? {
        if (!running) return null
        val y = YesNo(Recognizer(models.model(), RATE.toFloat(), YesNo.GRAMMAR))
        yesNo = y; mode = Mode.YESNO
        return try { withTimeoutOrNull(timeoutMs) { y.result.await() } } finally { mode = Mode.WAKE; yesNo = null; y.close() }
    }

    @SuppressLint("MissingPermission")
    private suspend fun loop(phrases: List<String>, onWake: () -> Unit) {
        val frame = RATE / 10 // 100 ms
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, max(minBuf, frame * 8))
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); onFail("No pude abrir el micrófono"); return }
        // Cancelación de eco y supresión de ruido del sistema cuando existen: permiten interrumpirla mientras habla.
        runCatching { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true }
        runCatching { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.enabled = true }

        val wakeNorm = phrases.map { Text.norm(it) }
        val grammar = org.json.JSONArray((phrases + "[unk]").toList()).toString()
        val wake = Recognizer(models.model(), RATE.toFloat(), grammar)
        val buf = ShortArray(frame)
        var cooldownUntil = 0L
        try {
            rec.startRecording()
            while (currentCoroutineContext().isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) { onFail("Error de lectura del micrófono"); break }
                if (n == 0) continue
                val rms = rms(buf, n)
                onLevel(min(1f, (rms / 5000.0).toFloat()))
                when (mode) {
                    Mode.WAKE -> {
                        val bytes = toBytes(buf, n)
                        val done = wake.acceptWaveForm(bytes, bytes.size)
                        val text = if (done) JSONObject(wake.result).optString("text") else JSONObject(wake.partialResult).optString("partial")
                        val now = SystemClock.elapsedRealtime()
                        if (text.isNotBlank() && now > cooldownUntil) {
                            val t = Text.norm(text)
                            if (wakeNorm.any { it.isNotEmpty() && t.contains(it) }) {
                                wake.reset(); cooldownUntil = now + 1500
                                onWake()
                            }
                        }
                    }
                    Mode.CAPTURE -> capture?.feed(toBytes(buf, n), rms)
                    Mode.YESNO -> yesNo?.feed(toBytes(buf, n))
                }
            }
        } finally {
            runCatching { rec.stop() }; rec.release(); wake.close()
        }
    }

    private fun rms(b: ShortArray, n: Int): Double {
        var s = 0.0
        for (i in 0 until n) s += b[i].toDouble() * b[i]
        return sqrt(s / n)
    }

    private fun toBytes(b: ShortArray, n: Int): ByteArray {
        val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.asShortBuffer().put(b, 0, n)
        return bb.array()
    }

    /** Graba hasta detectar silencio (900 ms tras al menos 300 ms de voz). */
    private class Capture(val timeoutMs: Long, val maxMs: Long) {
        val out = ByteArrayOutputStream()
        val done = CompletableDeferred<ByteArray?>()
        private val start = SystemClock.elapsedRealtime()
        private var noise = -1.0
        private var voicedFrames = 0
        private var lastVoice = 0L
        private var inSpeech = false

        fun feed(bytes: ByteArray, rms: Double) {
            val now = SystemClock.elapsedRealtime()
            out.write(bytes)
            if (noise < 0) noise = rms else if (!inSpeech) noise = noise * 0.9 + rms * 0.1
            val voiced = rms > max(500.0, noise * 2.5)
            if (voiced) { voicedFrames++; lastVoice = now; if (voicedFrames >= 3) inSpeech = true }
            when {
                inSpeech && now - lastVoice > 900 -> done.complete(out.toByteArray())
                !inSpeech && voicedFrames > 0 && now - lastVoice > 400 -> voicedFrames = 0 // fue un ruido breve
                !inSpeech && now - start > timeoutMs -> done.complete(null)
                now - start > maxMs -> done.complete(if (inSpeech) out.toByteArray() else null)
            }
        }
    }

    private class YesNo(private val rec: Recognizer) {
        companion object {
            const val GRAMMAR = """["sí","si","no","claro","confirmo","confirmado","adelante","hazlo","dale","cancela","cancelar","detente","[unk]"]"""
            private val NEG = setOf("no", "cancela", "cancelar", "detente")
            private val POS = setOf("si", "claro", "confirmo", "confirmado", "adelante", "hazlo", "dale")
        }
        val result = CompletableDeferred<Boolean?>()
        fun feed(bytes: ByteArray) {
            val done = rec.acceptWaveForm(bytes, bytes.size)
            val text = if (done) JSONObject(rec.result).optString("text") else JSONObject(rec.partialResult).optString("partial")
            val words = Text.norm(text).split(" ").toSet()
            when {
                words.any { it in NEG } -> result.complete(false) // ante la duda, cancelar
                words.any { it in POS } -> result.complete(true)
            }
        }
        fun close() = rec.close()
    }
}
