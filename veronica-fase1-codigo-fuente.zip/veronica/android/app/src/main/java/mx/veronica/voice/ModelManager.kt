package mx.veronica.voice

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import mx.veronica.ai.Http
import okhttp3.Request
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import java.io.File
import java.io.IOException
import java.util.zip.ZipInputStream
import kotlin.coroutines.coroutineContext

/** Descarga (una sola vez, ~40 MB) y carga el modelo de voz local en español. Funciona sin Internet después. */
class ModelManager(private val ctx: Context) {
    private val url = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"
    private val root = File(ctx.filesDir, "vosk")
    private val dir = File(root, "vosk-model-small-es-0.42")
    @Volatile private var loaded: Model? = null

    fun installed() = File(dir, "am").isDirectory

    fun model(): Model = loaded ?: synchronized(this) {
        loaded ?: run {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            Model(dir.absolutePath).also { loaded = it }
        }
    }

    suspend fun download(onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        root.mkdirs()
        val tmp = File(ctx.cacheDir, "vosk-model.zip")
        val client = Http.client.newBuilder().readTimeout(60, java.util.concurrent.TimeUnit.SECONDS).build()
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("Respuesta vacía")
            val total = body.contentLength(); var done = 0L
            body.byteStream().use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done += n
                        if (total > 0) onProgress((done * 90 / total).toInt())
                    }
                }
            }
        }
        val base = root.canonicalPath + File.separator
        ZipInputStream(tmp.inputStream().buffered()).use { zin ->
            generateSequence { zin.nextEntry }.forEach { e ->
                val f = File(root, e.name)
                if (!f.canonicalPath.startsWith(base)) throw IOException("Ruta no válida en el zip") // protección zip-slip
                if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { zin.copyTo(it) } }
            }
        }
        tmp.delete(); onProgress(100)
    }
}
