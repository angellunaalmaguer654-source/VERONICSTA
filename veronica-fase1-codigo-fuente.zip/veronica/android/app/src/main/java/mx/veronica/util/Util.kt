package mx.veronica.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.Normalizer

object Net {
    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

object Text {
    /** Minúsculas, sin acentos ni signos: para comparar nombres de apps, contactos y comandos. */
    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim()

    /** Limpia lo que el sintetizador pronunciaría mal (markdown, enlaces). */
    fun forSpeech(s: String): String =
        s.replace(Regex("https?://\\S+"), "").replace(Regex("[*_#`>~]"), "").replace(Regex("\\s+"), " ").trim()
}

object Wav {
    fun wrap(pcm: ByteArray, rate: Int = 16000): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
        h.put("data".toByteArray()).putInt(pcm.size)
        return h.array() + pcm
    }
}
