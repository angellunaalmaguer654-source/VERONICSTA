package mx.veronica.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import mx.veronica.R
import mx.veronica.Veronica
import mx.veronica.ui.SettingsActivity

/**
 * Servicio en primer plano de tipo "microphone": mantiene viva la escucha de la palabra de activación.
 * La notificación es obligatoria y el indicador de micrófono del sistema NO se oculta.
 */
class ListenService : Service() {
    companion object {
        const val ACTION_START = "mx.veronica.START"
        const val ACTION_ACTIVATE = "mx.veronica.ACTIVATE"
        const val ACTION_MUTE = "mx.veronica.MUTE"
        const val ACTION_STOP = "mx.veronica.STOP"
        private const val CHANNEL = "veronica_listen"
        private const val ID = 1
        @Volatile var conductor: Conductor? = null

        fun start(ctx: Context, action: String = ACTION_START) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, ListenService::class.java).setAction(action))
        fun activate(ctx: Context) = conductor?.onWake() ?: start(ctx, ACTION_ACTIVATE)
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, ListenService::class.java)) }
        fun status(ctx: Context, msg: String) {
            ctx.getSystemService(NotificationManager::class.java).notify(ID, build(ctx, msg))
        }

        private fun build(ctx: Context, text: String): Notification {
            fun pi(action: String, code: Int) = PendingIntent.getService(ctx, code,
                Intent(ctx, ListenService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, SettingsActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val muted = Veronica.prefs.muted
            return NotificationCompat.Builder(ctx, CHANNEL).setSmallIcon(R.drawable.ic_stat_orb)
                .setContentTitle("Verónica").setContentText(text).setOngoing(true).setSilent(true)
                .setContentIntent(open).setCategory(NotificationCompat.CATEGORY_SERVICE)
                .addAction(0, if (muted) "Reanudar" else "Pausar micrófono", pi(ACTION_MUTE, 1))
                .addAction(0, "Detener", pi(ACTION_STOP, 2)).build()
        }
        fun idleText(): String = if (Veronica.prefs.muted) "Micrófono en pausa" else "Escuchando «${Veronica.prefs.wakeList.firstOrNull() ?: "Oye Verónica"}»"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Escucha de Verónica", NotificationManager.IMPORTANCE_LOW))
        try {
            ServiceCompat.startForeground(this, ID, build(this, idleText()), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            // Android negó el micrófono en segundo plano (p. ej. arranque desde BOOT_COMPLETED). Ver docs/01.
            stopSelf(); return
        }
        Veronica.prefs.listeningEnabled = true
        conductor = Conductor(this, scope).also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ACTIVATE -> conductor?.onWake()
            ACTION_MUTE -> { conductor?.setMuted(!Veronica.prefs.muted); status(this, idleText()) }
            ACTION_STOP -> { Veronica.prefs.listeningEnabled = false; stopSelf() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        conductor?.shutdown(); conductor = null; scope.cancel()
        super.onDestroy()
    }
}
