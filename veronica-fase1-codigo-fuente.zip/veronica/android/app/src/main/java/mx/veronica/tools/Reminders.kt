package mx.veronica.tools

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import mx.veronica.R
import mx.veronica.Veronica
import mx.veronica.service.ListenService

object Reminders {
    const val CHANNEL = "veronica_reminders"

    fun schedule(ctx: Context, id: Long, text: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, id.toInt(), Intent(ctx, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        // Android 12+: las alarmas exactas requieren permiso concedido por el usuario; si falta, se usa la inexacta.
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun rescheduleAll(ctx: Context) = Veronica.db.pendingReminders().forEach { (id, text, at) -> schedule(ctx, id, text, at) }

    fun channel(ctx: Context) = ctx.getSystemService(NotificationManager::class.java)
        .createNotificationChannel(NotificationChannel(CHANNEL, "Recordatorios y avisos", NotificationManager.IMPORTANCE_HIGH))

    fun notify(ctx: Context, text: String) {
        channel(ctx)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.notify(text.hashCode(), NotificationCompat.Builder(ctx, CHANNEL).setSmallIcon(R.drawable.ic_stat_orb)
            .setContentTitle("Verónica").setContentText(text).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build())
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val text = i.getStringExtra("text") ?: return
        Veronica.db.finishReminder(i.getLongExtra("id", -1))
        Reminders.notify(ctx, text)
        ListenService.conductor?.announce("Recordatorio: $text")
    }
}
