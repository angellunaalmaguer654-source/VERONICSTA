package mx.veronica.service

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import mx.veronica.Veronica
import mx.veronica.ai.Agent
import mx.veronica.ai.AgentIO
import mx.veronica.tools.ToolRegistry
import mx.veronica.tools.androidHandlers
import mx.veronica.ui.OrbState
import mx.veronica.ui.OverlayController
import mx.veronica.util.Text
import mx.veronica.voice.AudioEngine
import mx.veronica.voice.SpeakerHub
import mx.veronica.voice.Stt

/**
 * Orquesta el ciclo completo:
 * espera → palabra de activación → símbolo → escucha → transcribe → piensa/ejecuta → habla → (seguimiento) → espera.
 * Una sola sesión a la vez; una nueva activación interrumpe a la anterior (interrupción por voz).
 */
class Conductor(private val ctx: Context, private val scope: CoroutineScope) {
    private val p get() = Veronica.prefs
    private val audio = AudioEngine(ctx, Veronica.models)
    private val speaker = SpeakerHub(ctx)
    private val overlay = OverlayController(ctx) { onTap() }
    private val agent = Agent(ctx, ToolRegistry(ctx, androidHandlers(ctx)))
    private var session: Job? = null
    private var hideJob: Job? = null

    private fun setState(s: OrbState) { Veronica.state.value = s; overlay.setState(s) }

    fun start() {
        if (p.muted) { setState(OrbState.OFF); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { fail("Falta el permiso de micrófono."); return }
        if (!Veronica.models.installed()) { fail("Falta descargar el modelo de voz. Ábreme y toca \"Descargar modelo\"."); return }
        overlay.attach()
        audio.onLevel = { overlay.level(it) }
        audio.onFail = { fail(it) }
        audio.start(scope, p.wakeList) { onWake() }
        setState(OrbState.IDLE)
    }

    private fun fail(msg: String) {
        Log.w("Veronica", msg)
        setState(OrbState.ERROR)
        ListenService.status(ctx, msg)
    }

    fun onWake() {
        if (p.muted) return
        if (!p.bargeIn && session?.isActive == true) return
        val old = session
        session = scope.launch {
            old?.cancelAndJoin()
            speaker.stop()
            try { runSession() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                Log.e("Veronica", "Sesión fallida", e)
                setState(OrbState.ERROR)
                runCatching { speaker.speak("Tuve un problema. Intenta de nuevo.", p.language) }
                delay(800)
            } finally { finishSession() }
        }
    }

    private suspend fun runSession() {
        hideJob?.cancel()
        setState(OrbState.LISTENING); overlay.show()
        greet()
        var window = 8000L
        while (true) {
            setState(OrbState.LISTENING)
            val pcm = audio.captureUtterance(timeoutMs = window) ?: break
            setState(OrbState.THINKING)
            val text = Stt.transcribe(ctx, pcm) // el audio solo vive en memoria
            if (text.isBlank()) break
            agent.handle(text, io)
            window = when (agent.followUp) { "close" -> break; "ask" -> 9000L; else -> p.followUpMs.toLong() }
            if (window <= 0) break
        }
    }

    private fun finishSession() {
        setState(if (p.muted) OrbState.OFF else OrbState.IDLE)
        hideJob = scope.launch { delay(900); overlay.hide() }
    }

    private suspend fun greet() {
        when (p.greeting) {
            "voz" -> {
                setState(OrbState.SPEAKING)
                val name = Veronica.db.facts().firstOrNull { it.first == "nombre" }?.second
                val es = listOf("Aquí estoy, ¿qué necesitas?", "Dime.", "¿Sí?", "Te escucho.", if (name != null) "Dime, $name." else "Aquí estoy.")
                val en = listOf("I'm here.", "Yes?", "Go ahead.")
                speaker.speak(if (p.lang2 == "es") es.random() else en.random(), p.language)
            }
            "tono" -> { ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_BEEP, 120); delay(220) }
        }
    }

    private val io = object : AgentIO {
        override suspend fun say(text: String) { setState(OrbState.SPEAKING); speaker.speak(Text.forSpeech(text), p.language) }
        override suspend fun confirm(question: String): Boolean {
            setState(OrbState.SPEAKING); speaker.speak(question, p.language)
            setState(OrbState.LISTENING)
            return audio.listenYesNo() == true // sin respuesta clara = no
        }
        override fun executing() = setState(OrbState.EXECUTING)
        override fun error() = setState(OrbState.ERROR)
    }

    /** Toque sobre el símbolo: activa, o interrumpe si ya está en conversación. */
    fun onTap() { if (session?.isActive == true) { session?.cancel(); speaker.stop() } else onWake() }

    fun setMuted(m: Boolean) {
        p.muted = m
        if (m) {
            session?.cancel(); audio.stop(); setState(OrbState.OFF); overlay.show()
            hideJob = scope.launch { delay(1600); overlay.hide() }
        } else start()
    }

    /** Aviso hablado (recordatorios). No interrumpe una conversación en curso. */
    fun announce(text: String) {
        if (session?.isActive == true || p.muted) return
        session = scope.launch {
            try { hideJob?.cancel(); setState(OrbState.SPEAKING); overlay.show(); speaker.speak(text, p.language) }
            finally { finishSession() }
        }
    }

    fun shutdown() {
        session?.cancel(); audio.stop(); speaker.stop(); speaker.release(); overlay.detach()
        Veronica.state.value = OrbState.OFF
    }
}
