package mx.veronica.ui

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState { OFF, IDLE, LISTENING, THINKING, SPEAKING, EXECUTING, ERROR }

/**
 * El símbolo de Verónica: un núcleo perlado rodeado de tres "velos" de luz (ámbar, magenta, índigo)
 * que se mezclan con brillo aditivo. Cada estado cambia el movimiento, no solo el color:
 *  IDLE respira · LISTENING late con el micrófono y emite ondas · THINKING gira rápido con un arco de energía ·
 *  SPEAKING dibuja un anillo ondulado · EXECUTING orbita un arco dorado · ERROR vira a rojo y tiembla · OFF se apaga.
 */
class OrbView(ctx: Context) : View(ctx) {
    var state: OrbState = OrbState.IDLE
        set(v) { field = v; invalidate() }
    /** Nivel del micrófono 0..1, lo actualiza el motor de audio. */
    @Volatile var level = 0f

    private val AMBER = Color.rgb(255, 179, 71)
    private val MAGENTA = Color.rgb(224, 64, 154)
    private val INDIGO = Color.rgb(91, 75, 255)
    private val PEARL = Color.rgb(255, 244, 230)
    private val RED = Color.rgb(255, 59, 78)
    private val GOLD = Color.rgb(255, 214, 102)
    private val GREY = Color.rgb(120, 118, 135)

    private val lobePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private val rect = RectF()
    private val argb = ArgbEvaluator()
    private val filters = HashMap<Int, PorterDuffColorFilter>()

    // Un único degradado radial blanco→transparente; el color de cada velo se aplica con un filtro SRC_IN.
    private val unitShader = RadialGradient(0f, 0f, 100f,
        intArrayOf(0xFFFFFFFF.toInt(), 0x99FFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)

    private var smooth = 0f
    private var mix = 0f // 0 = paleta normal, 1 = paleta del estado actual (transición suave)
    private val dp = resources.displayMetrics.density

    private fun tint(c: Int) = filters.getOrPut(c) { PorterDuffColorFilter(c, PorterDuff.Mode.SRC_IN) }
    private fun lerp(a: Int, b: Int, t: Float) = argb.evaluate(t.coerceIn(0f, 1f), a, b) as Int

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, color: Int, alpha: Float) {
        lobePaint.shader = unitShader
        lobePaint.colorFilter = tint(color)
        lobePaint.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt()
        c.save(); c.translate(x, y); c.scale(r / 100f, r / 100f); c.drawCircle(0f, 0f, 100f, lobePaint); c.restore()
    }

    override fun onDraw(c: Canvas) {
        val t = SystemClock.uptimeMillis() / 1000f
        val cx = width / 2f; val cy = height / 2f; val R = width * 0.2f
        val s = state

        val target = when (s) {
            OrbState.LISTENING -> level.coerceIn(0f, 1f)
            OrbState.SPEAKING -> 0.35f + 0.3f * abs(sin(t * 7f)) * (0.6f + 0.4f * sin(t * 2.3f))
            OrbState.THINKING -> 0.4f; OrbState.EXECUTING -> 0.45f; OrbState.ERROR -> 0.6f
            OrbState.IDLE -> 0.12f + 0.06f * sin(t * 1.6f); OrbState.OFF -> 0f
        }
        smooth += (target - smooth) * 0.18f
        val speed = when (s) {
            OrbState.THINKING -> 2.4f; OrbState.EXECUTING -> 3.2f; OrbState.LISTENING -> 1f + smooth * 2f
            OrbState.SPEAKING -> 1.5f; OrbState.ERROR -> 0.4f; else -> 0.5f
        }
        mix += ((if (s == OrbState.IDLE || s == OrbState.LISTENING || s == OrbState.SPEAKING || s == OrbState.THINKING) 0f else 1f) - mix) * 0.12f
        val alt = when (s) { OrbState.ERROR -> RED; OrbState.OFF -> GREY; OrbState.EXECUTING -> GOLD; else -> AMBER }
        val c1 = lerp(AMBER, alt, mix); val c2 = lerp(MAGENTA, alt, mix); val c3 = lerp(INDIGO, if (s == OrbState.ERROR) RED else alt, mix)
        val off = s == OrbState.OFF

        c.save()
        if (s == OrbState.ERROR) c.translate(sin(t * 45f) * 2f * dp, 0f)

        // Halo exterior
        corePaint.shader = RadialGradient(cx, cy, R * 2.1f, intArrayOf(Color.argb(if (off) 18 else 60, 255, 190, 140), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 2.1f, corePaint)
        corePaint.shader = null

        // Velos de luz
        val orbit = R * (0.16f + 0.14f * smooth)
        val cols = intArrayOf(c1, c2, c3)
        for (i in 0..2) {
            val a = t * speed * (1f + i * 0.35f) * (if (i == 1) -1f else 1f) + i * 2.094f
            val r = R * (0.80f + 0.20f * smooth + 0.05f * sin(t * 1.3f + i))
            blob(c, cx + cos(a) * orbit, cy + sin(a) * orbit, r * 1.5f, cols[i], if (off) 0.18f else 0.85f)
        }
        // Núcleo perlado
        blob(c, cx, cy, R * (0.62f + 0.22f * smooth), if (off) GREY else PEARL, if (off) 0.3f else 0.95f)

        // Anillos por estado
        ringPaint.strokeWidth = 2.5f * dp
        when (s) {
            OrbState.LISTENING -> for (k in 0..1) {
                val ph = (t * 0.9f + k * 0.5f) % 1f
                ringPaint.color = Color.argb(((1f - ph) * (110 + 120 * smooth)).toInt().coerceIn(0, 255), 255, 244, 230)
                c.drawCircle(cx, cy, R * (1.15f + 0.95f * ph + 0.2f * smooth), ringPaint)
            }
            OrbState.SPEAKING -> {
                path.reset()
                val n = 96
                for (i in 0..n) {
                    val th = (i.toFloat() / n) * 2f * PI.toFloat()
                    val w = (sin(3 * th + t * 6f) + 0.6f * sin(5 * th - t * 4.3f) + 0.4f * sin(7 * th + t * 9f)) / 2f
                    val rr = R * 1.25f + R * 0.3f * smooth * w
                    val x = cx + cos(th) * rr; val y = cy + sin(th) * rr
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                ringPaint.strokeWidth = 7f * dp; ringPaint.color = Color.argb(55, 255, 214, 160); c.drawPath(path, ringPaint)
                ringPaint.strokeWidth = 2.2f * dp; ringPaint.color = Color.argb(230, 255, 244, 230); c.drawPath(path, ringPaint)
            }
            OrbState.THINKING, OrbState.EXECUTING -> {
                rect.set(cx - R * 1.3f, cy - R * 1.3f, cx + R * 1.3f, cy + R * 1.3f)
                ringPaint.color = if (s == OrbState.EXECUTING) Color.argb(240, 255, 214, 102) else Color.argb(220, 255, 244, 230)
                val a0 = (t * speed * 140f) % 360f
                c.drawArc(rect, a0, if (s == OrbState.EXECUTING) 110f else 80f, false, ringPaint)
                c.drawArc(rect, a0 + 180f, 50f, false, ringPaint)
            }
            OrbState.ERROR -> { ringPaint.color = Color.argb(200, 255, 59, 78); c.drawCircle(cx, cy, R * 1.3f, ringPaint) }
            OrbState.OFF -> { ringPaint.strokeWidth = 1.5f * dp; ringPaint.color = Color.argb(110, 160, 158, 175); c.drawCircle(cx, cy, R * 1.1f, ringPaint) }
            OrbState.IDLE -> {}
        }
        c.restore()
        // OFF es estático; el resto anima solo mientras la vista es visible (ahorra batería).
        if (s != OrbState.OFF && visibility == VISIBLE) postInvalidateOnAnimation()
    }
}
