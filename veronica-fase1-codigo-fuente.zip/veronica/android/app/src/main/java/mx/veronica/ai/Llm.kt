package mx.veronica.ai

import kotlinx.coroutines.suspendCancellableCoroutine
import mx.veronica.data.Prefs
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class Msg(val role: String, val content: String)

/** Cliente HTTP único. Cancelar la corrutina cancela la petición (necesario para interrumpir a Verónica). */
object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).build()
    val JSON = "application/json".toMediaType()

    suspend fun bytes(req: Request): ByteArray = suspendCancellableCoroutine { cont ->
        val call = client.newCall(req)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { if (cont.isActive) cont.resumeWithException(e) }
            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    val body = r.body?.bytes() ?: ByteArray(0)
                    if (!cont.isActive) return
                    if (r.isSuccessful) cont.resume(body)
                    else cont.resumeWithException(IOException("HTTP ${r.code}: ${String(body).take(200)}"))
                }
            }
        })
    }
    suspend fun call(req: Request): String = String(bytes(req))
}

/** Contrato que todo proveedor de IA implementa. Cambiar de proveedor = cambiar una clase. */
interface LlmProvider {
    suspend fun chat(system: String, msgs: List<Msg>): String
}

private fun mergeRoles(msgs: List<Msg>): List<Msg> {
    val out = mutableListOf<Msg>()
    for (m in msgs) {
        if (out.isNotEmpty() && out.last().role == m.role) out[out.lastIndex] = Msg(m.role, out.last().content + "\n" + m.content)
        else out += m
    }
    return out
}

/** Cubre OpenAI, Groq, Gemini (endpoint compatible), OpenRouter, Together, Ollama, LM Studio, etc. */
class OpenAiCompatLlm(private val baseUrl: String, private val key: String, private val model: String) : LlmProvider {
    override suspend fun chat(system: String, msgs: List<Msg>): String {
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        mergeRoles(msgs).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.5).put("max_tokens", 700)
        val rb = Request.Builder().url(baseUrl.trimEnd('/') + "/chat/completions")
            .post(body.toString().toRequestBody(Http.JSON))
        if (key.isNotBlank()) rb.header("Authorization", "Bearer $key")
        val resp = JSONObject(Http.call(rb.build()))
        return resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
    }
}

class AnthropicLlm(private val baseUrl: String, private val key: String, private val model: String) : LlmProvider {
    override suspend fun chat(system: String, msgs: List<Msg>): String {
        val arr = JSONArray()
        mergeRoles(msgs).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject().put("model", model).put("max_tokens", 700).put("system", system).put("messages", arr)
        val req = Request.Builder().url(baseUrl.trimEnd('/') + "/v1/messages")
            .header("x-api-key", key).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody(Http.JSON)).build()
        val content = JSONObject(Http.call(req)).getJSONArray("content")
        return (0 until content.length()).joinToString("") { content.getJSONObject(it).optString("text") }
    }
}

object Llms {
    fun current(p: Prefs): LlmProvider =
        if (p.llmProvider == "anthropic") AnthropicLlm(p.llmBaseUrl, p.llmKey, p.llmModel)
        else OpenAiCompatLlm(p.llmBaseUrl, p.llmKey, p.llmModel)
}
