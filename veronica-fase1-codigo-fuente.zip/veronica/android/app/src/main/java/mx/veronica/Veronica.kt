package mx.veronica

import android.app.Application
import kotlinx.coroutines.flow.MutableStateFlow
import mx.veronica.data.MemoryDb
import mx.veronica.data.Prefs
import mx.veronica.ui.OrbState
import mx.veronica.voice.ModelManager

/** Contenedor global mínimo (sin framework de inyección para mantener el APK ligero). */
object Veronica {
    lateinit var app: Application
    val prefs by lazy { Prefs(app) }
    val db by lazy { MemoryDb(app) }
    val models by lazy { ModelManager(app) }
    /** Estado visible del símbolo; la interfaz de ajustes lo observa. */
    val state = MutableStateFlow(OrbState.OFF)
}

class VeronicaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Veronica.app = this
    }
}
