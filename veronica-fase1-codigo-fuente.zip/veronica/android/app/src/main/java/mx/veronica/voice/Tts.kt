package mx.veronica.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import mx.veronica.Veronica
import mx.veronica.ai.Http
import mx.veronica.util.Net
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** Voz del sistema (gratis, sin Internet). La calidad depende de las voces es-MX instaladas en Google TTS / Samsung TTS. */
class SystemTts(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private val ready = CompletableDeferred<Boolean>()

    private fun engine(): TextToSpeech = tts ?: TextToSpeech(ctx) { ready.complete(it == TextToSpeech.SUCCESS) }.also { tts = it }

    suspend fun speak(text: String, lang: String) {
        val t = engine()
        if (!ready.await()) return
        val loc = Locale.forLanguageTag(lang)
        if (t.setLanguage(loc) < TextToSpeech.LANG_AVAILABLE) t.setLanguage(Locale(loc.language))
        val p = Veronica.prefs
        if (p.systemVoice.isNotBlank()) t.voices?.firstOrNull { it.name == p.systemVoice }?.let { t.voice = it }
        t.setSpeechRate(p.ttsRate)
        val id = UUID.randomUUID().toString()
        suspendCancellableCoroutine<Unit> { cont ->
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onDone(u: String?) { if (u == id && cont.isActive) cont.resume(Unit) }
                @Deprecated("Deprecated in Java") override fun onError(u: String?) { if (u == id && cont.isActive) cont.resume(Unit) }
            })
            cont.invokeOnCancellation { t.stop() }
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    fun voices(): List<String> = tts?.voices?.filter { it.locale.language == "es" }?.map { it.name }?.sorted() ?: emptyList()
    fun stop() { tts?.stop() }
    fun release() { tts?.shutdown(); tts = null }
}

/** Voz neuronal en la nube con la API /audio/speech (compatible con OpenAI). Más natural; requiere clave y Internet. */
class CloudTts(private val ctx: Context) {
    private var player: MediaPlayer? = null

    suspend fun speak(text: String) {
        val p = Veronica.prefs
        val body = JSONObject().put("model", p.ttsModel).put("voice", p.ttsVoice).put("input", text).put("response_format", "mp3")
        val bytes = Http.bytes(Request.Builder().url(p.ttsBaseUrl.trimEnd('/') + "/audio/speech")
            .header("Authorization", "Bearer ${p.ttsKey}").post(body.toString().toRequestBody(Http.JSON)).build())
        val f = File(ctx.cacheDir, "tts-${UUID.randomUUID()}.mp3").apply { writeBytes(bytes) }
        try {
            suspendCancellableCoroutine<Unit> { cont ->
                val mp = MediaPlayer().also { player = it }
                mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                mp.setDataSource(f.absolutePath)
                mp.setOnCompletionListener { if (cont.isActive) cont.resume(Unit) }
                mp.setOnErrorListener { _, _, _ -> if (cont.isActive) cont.resume(Unit); true }
                cont.invokeOnCancellation { runCatching { mp.stop() } }
                mp.prepare(); mp.start()
            }
        } finally { player?.release(); player = null; f.delete() }
    }
    fun stop() { runCatching { player?.stop() } }
}

/** Fachada: elige nube o sistema, y cae al sistema si la nube falla. */
class SpeakerHub(ctx: Context) {
    private val ctx = ctx.applicationContext
    private val system = SystemTts(this.ctx)
    private val cloud = CloudTts(this.ctx)

    suspend fun speak(text: String, lang: String) {
        if (text.isBlank()) return
        val p = Veronica.prefs
        if (p.ttsMode == "cloud" && p.ttsKey.isNotBlank() && Net.online(ctx) && !p.offlineOnly) {
            try { cloud.speak(text); return } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { /* respaldo */ }
        }
        system.speak(text, lang)
    }
    fun stop() { system.stop(); cloud.stop() }
    fun release() { system.release() }
}
