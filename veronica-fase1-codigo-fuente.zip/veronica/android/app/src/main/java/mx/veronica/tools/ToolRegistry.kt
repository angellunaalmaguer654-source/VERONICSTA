package mx.veronica.tools

import android.content.Context
import kotlinx.coroutines.CancellationException
import mx.veronica.Veronica
import mx.veronica.ai.AgentIO
import org.json.JSONObject

data class ToolSpec(
    val name: String, val desc: String, val args: Map<String, String>,
    val confirm: String?, val confirmIf: Pair<String, List<String>>?, val offline: Boolean,
)

/**
 * Las descripciones viven en shared/tools.json (única fuente de verdad, igual en Windows).
 * Aquí solo se enlazan con su implementación y se aplica la política de confirmación.
 */
class ToolRegistry(ctx: Context, private val handlers: Map<String, suspend (JSONObject) -> String>) {
    val specs: Map<String, ToolSpec>

    init {
        val arr = org.json.JSONArray(ctx.assets.open("tools.json").bufferedReader().readText())
        specs = (0 until arr.length()).map { arr.getJSONObject(it) }
            .filter { o -> (0 until o.getJSONArray("platforms").length()).any { o.getJSONArray("platforms").getString(it) == "android" } }
            .associate { o ->
                val a = o.getJSONObject("args")
                val ci = o.optJSONObject("confirm_if")?.let { c ->
                    val k = c.keys().next(); k to (0 until c.getJSONArray(k).length()).map { c.getJSONArray(k).getString(it) }
                }
                o.getString("name") to ToolSpec(
                    o.getString("name"), o.getString("desc"),
                    a.keys().asSequence().associateWith { a.getString(it) },
                    o.optString("confirm").ifBlank { null }, ci, o.optBoolean("offline", false),
                )
            }
    }

    fun catalog(): String = specs.values.filter { !Veronica.prefs.offlineOnly || it.offline }.joinToString("\n") { s ->
        "- ${s.name}(${s.args.entries.joinToString(", ") { "${it.key}: ${it.value}" }}): ${s.desc}"
    }

    private fun needsConfirm(s: ToolSpec, a: JSONObject): Boolean {
        if (s.confirm == null) return false
        val ci = s.confirmIf ?: return true
        return a.optString(ci.first) in ci.second
    }

    private fun fill(t: String, a: JSONObject) = Regex("\\{(\\w+)}").replace(t) { a.optString(it.groupValues[1]) }

    suspend fun run(name: String, args: JSONObject, io: AgentIO): String {
        val spec = specs[name] ?: return "Error: herramienta desconocida ($name)."
        val h = handlers[name] ?: return "Error: herramienta aún no implementada ($name)."
        if (needsConfirm(spec, args) && !io.confirm(fill(spec.confirm!!, args))) return "El usuario canceló la acción."
        return try { h(args) }
        catch (e: SecurityException) { "Falta un permiso de Android para esto. Actívalo en los ajustes de Verónica." }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Error: ${e.message ?: e.javaClass.simpleName}" }
    }
}
