package mx.veronica.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import mx.veronica.Veronica
import mx.veronica.service.A11yService
import mx.veronica.service.ListenService

/** Configuración completa. Nunca hace falta abrirla para hablar con Verónica. */
class SettingsActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFFFB347), onPrimary = Color(0xFF1A1208), secondary = Color(0xFFE0409A),
                background = Color(0xFF0E0B16), surface = Color(0xFF171322), onSurface = Color(0xFFFFF4E6),
                onBackground = Color(0xFFFFF4E6), surfaceVariant = Color(0xFF241E33), onSurfaceVariant = Color(0xFFCFC6DD),
            )) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Screen(tick.intValue) } }
        }
    }
    override fun onResume() { super.onResume(); tick.intValue++ }

    // ---------- piezas reutilizables ----------
    @Composable private fun Section(title: String, body: @Composable ColumnScope.() -> Unit) {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                body()
            }
        }
    }
    @Composable private fun Field(label: String, get: () -> String, set: (String) -> Unit, secret: Boolean = false) {
        var v by remember { mutableStateOf(get()) }
        OutlinedTextField(v, { v = it; set(it) }, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None)
    }
    @Composable private fun Toggle(label: String, hint: String? = null, get: () -> Boolean, set: (Boolean) -> Unit) {
        var v by remember { mutableStateOf(get()) }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(label); hint?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
            Switch(v, { v = it; set(it) })
        }
    }
    @Composable private fun Check(label: String, ok: Boolean, action: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (ok) "✓" else "○", color = if (ok) Color(0xFF6EE7A8) else Color(0xFFFFB347)); Spacer(Modifier.width(10.dp))
            Text(label, Modifier.weight(1f))
            if (!ok) OutlinedButton(onClick) { Text(action) }
        }
    }
    @Composable private fun Choice(label: String, options: List<Pair<String, String>>, get: () -> String, set: (String) -> Unit) {
        var v by remember { mutableStateOf(get()) }
        Column { Text(label, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { (id, name) -> FilterChip(v == id, { v = id; set(id) }, { Text(name) }) }
            }
        }
    }

    private fun open(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun pkgUri() = Uri.parse("package:$packageName")

    // ---------- pantalla ----------
    @Composable private fun Screen(t: Int) {
        val p = Veronica.prefs
        val scope = rememberCoroutineScope()
        val orb by Veronica.state.collectAsState()
        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick.intValue++ }
        fun granted(x: String) = ContextCompat.checkSelfPermission(this, x) == android.content.pm.PackageManager.PERMISSION_GRANTED
        var progress by remember { mutableIntStateOf(-1) }
        var dlError by remember { mutableStateOf("") }
        var listening by remember(t) { mutableStateOf(p.listeningEnabled) }
        val modelOk = remember(t, progress) { Veronica.models.installed() }
        val defaultAssistant = remember(t) { Settings.Secure.getString(contentResolver, "voice_interaction_service")?.startsWith(packageName) == true }
        val pm = getSystemService(PowerManager::class.java)

        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Verónica", style = MaterialTheme.typography.headlineMedium)
            Text("Estado del símbolo: ${orb.name.lowercase()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Section("Activación") {
                Toggle("Escuchar «${p.wakeList.firstOrNull() ?: "Oye Verónica"}»", "Servicio permanente. Verás el indicador de micrófono del sistema.",
                    { listening }, { on ->
                        listening = on; p.listeningEnabled = on
                        if (on) ListenService.start(this@SettingsActivity) else ListenService.stop(this@SettingsActivity)
                    })
                Toggle("Micrófono en pausa", "Libera el micrófono por completo.", { p.muted }, { m ->
                    p.muted = m; ListenService.conductor?.setMuted(m)
                })
            }

            Section("Permisos y requisitos") {
                Check("Micrófono", granted(Manifest.permission.RECORD_AUDIO), "Conceder") { perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
                if (Build.VERSION.SDK_INT >= 33) Check("Notificaciones", granted(Manifest.permission.POST_NOTIFICATIONS), "Conceder") { perms.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) }
                Check("Mostrar el símbolo sobre otras apps", Settings.canDrawOverlays(this@SettingsActivity), "Abrir") { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri())) }
                Check("Modelo de voz local (40 MB)", modelOk, if (progress in 0..99) "$progress %" else "Descargar") {
                    if (progress < 0 || progress >= 100) scope.launch {
                        dlError = ""; progress = 0
                        try { Veronica.models.download { progress = it } } catch (e: Exception) { dlError = e.message ?: "Error de descarga"; progress = -1 }
                    }
                }
                if (dlError.isNotEmpty()) Text(dlError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Check("Asistente digital predeterminado (recomendado)", defaultAssistant, "Elegir") { open(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) }
                Check("Sin restricción de batería", pm.isIgnoringBatteryOptimizations(packageName), "Permitir") { open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri())) }
                Check("Contactos, llamadas, SMS y calendario", granted(Manifest.permission.READ_CONTACTS) && granted(Manifest.permission.CALL_PHONE), "Conceder") {
                    perms.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_CALENDAR))
                }
                Check("Leer notificaciones (opcional)", NotificationManagerCompat.getEnabledListenerPackages(this@SettingsActivity).contains(packageName), "Activar") { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                Check("Accesibilidad: inicio, atrás, capturas (opcional)", A11yService.instance != null, "Activar") { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }

            Section("Inteligencia artificial") {
                Choice("Proveedor", listOf("anthropic" to "Anthropic", "openai" to "Compatible OpenAI"), { p.llmProvider }, { p.llmProvider = it })
                Text("Atajos: OpenAI · Groq · Gemini · OpenRouter · Ollama", style = MaterialTheme.typography.bodySmall)
                Field("URL base", { p.llmBaseUrl }, { p.llmBaseUrl = it })
                Field("Modelo", { p.llmModel }, { p.llmModel = it })
                Field("Clave de API (se guarda cifrada)", { p.llmKey }, { p.llmKey = it }, secret = true)
                Text("Voz a texto en la nube", style = MaterialTheme.typography.titleSmall)
                Field("URL base", { p.sttBaseUrl }, { p.sttBaseUrl = it })
                Field("Modelo", { p.sttModel }, { p.sttModel = it })
                Field("Clave (vacía = la misma del modelo)", { p.secrets.get("stt_key") }, { p.sttKey = it }, secret = true)
                Text("Búsqueda web y ciudad", style = MaterialTheme.typography.titleSmall)
                Field("Clave de Tavily (opcional)", { p.searchKey }, { p.searchKey = it }, secret = true)
                Field("Ciudad para el clima", { p.city }, { p.city = it })
            }

            Section("Voz y personalidad") {
                Field("Palabras de activación (separadas por comas)", { p.wakePhrases }, { p.wakePhrases = it })
                Text("Los cambios de palabra se aplican al reiniciar la escucha.", style = MaterialTheme.typography.bodySmall)
                Choice("Al despertar", listOf("voz" to "Saludo hablado", "tono" to "Tono", "ninguno" to "Nada"), { p.greeting }, { p.greeting = it })
                Field("Idioma (es-MX, en-US, fr-FR...)", { p.language }, { p.language = it })
                Choice("Voz", listOf("system" to "Del sistema", "cloud" to "Neuronal (nube)"), { p.ttsMode }, { p.ttsMode = it })
                Field("Voz del sistema (nombre exacto, opcional)", { p.systemVoice }, { p.systemVoice = it })
                Field("Voz en la nube (p. ej. nova, coral)", { p.ttsVoice }, { p.ttsVoice = it })
                Field("Modelo de voz en la nube", { p.ttsModel }, { p.ttsModel = it })
                Field("Clave de voz (vacía = la misma del modelo)", { p.secrets.get("tts_key") }, { p.ttsKey = it }, secret = true)
                var rate by remember { mutableFloatStateOf(p.ttsRate) }
                Text("Velocidad: ${"%.1f".format(rate)}×", style = MaterialTheme.typography.bodySmall)
                Slider(rate, { rate = it; p.ttsRate = it }, valueRange = 0.7f..1.4f)
                Toggle("Poder interrumpirla diciendo su nombre", get = { p.bargeIn }, set = { p.bargeIn = it })
                Field("App de música favorita (nombre)", { p.musicApp }, { p.musicApp = it })
            }

            Section("Memoria") {
                Toggle("Recordar datos sobre mí", "Nombre, preferencias, personas. Se guarda solo en este teléfono.", { p.memoryEnabled }, { p.memoryEnabled = it })
                val facts = remember(t) { mutableStateListOf<Pair<String, String>>().apply { addAll(Veronica.db.facts()) } }
                if (facts.isEmpty()) Text("Aún no sé nada de ti. Dime «recuerda que…».", style = MaterialTheme.typography.bodySmall)
                facts.toList().forEach { (k, v) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("$k: $v", Modifier.weight(1f))
                        TextButton({ Veronica.db.delFact(k); facts.removeAll { it.first == k } }) { Text("Borrar") }
                    }
                }
                OutlinedButton({ Veronica.db.wipeAll(); facts.clear() }) { Text("Borrar toda la memoria, notas y tareas") }
            }

            Section("Historial") {
                val hist = remember(t) { mutableStateListOf<Triple<String, String, Long>>().apply { addAll(Veronica.db.history(15)) } }
                if (hist.isEmpty()) Text("Sin historial.", style = MaterialTheme.typography.bodySmall)
                hist.forEach { (role, text, _) -> Text((if (role == "user") "Tú: " else "Verónica: ") + text, style = MaterialTheme.typography.bodySmall) }
                OutlinedButton({ Veronica.db.clearHistory(); hist.clear() }) { Text("Borrar historial") }
            }

            Section("Privacidad") {
                Toggle("Guardar historial de conversaciones", get = { p.saveHistory }, set = { p.saveHistory = it })
                Toggle("Modo privado", "No guarda historial ni memoria durante las conversaciones.", { p.privateMode }, { p.privateMode = it })
                Toggle("Solo en el teléfono", "Sin Internet: solo comandos básicos y voz local.", { p.offlineOnly }, { p.offlineOnly = it })
                Text("El audio nunca se guarda. Con la voz en la nube, solo la frase que dices tras despertar a Verónica se envía al proveedor que configuraste.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
