package mx.veronica.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Memoria local: hechos del usuario, notas, tareas, historial y recordatorios. Nada sale del teléfono. */
class MemoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "veronica.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE facts(k TEXT PRIMARY KEY, v TEXT NOT NULL, ts INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, ts INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, ts INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, at INTEGER NOT NULL, done INTEGER NOT NULL DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    private fun now() = System.currentTimeMillis()
    private inline fun <T> rows(sql: String, vararg args: String, map: (android.database.Cursor) -> T): List<T> =
        readableDatabase.rawQuery(sql, args).use { c -> buildList { while (c.moveToNext()) add(map(c)) } }

    // Hechos
    fun facts(): List<Pair<String, String>> = rows("SELECT k,v FROM facts ORDER BY ts DESC LIMIT 60") { it.getString(0) to it.getString(1) }
    fun putFact(k: String, v: String) = writableDatabase.execSQL("INSERT OR REPLACE INTO facts(k,v,ts) VALUES(?,?,?)", arrayOf(k.trim().lowercase(), v.trim(), now()))
    fun delFact(k: String) = writableDatabase.delete("facts", "k=?", arrayOf(k.trim().lowercase()))

    // Notas
    fun addNote(t: String) = writableDatabase.execSQL("INSERT INTO notes(text,ts) VALUES(?,?)", arrayOf(t.trim(), now()))
    fun notes(limit: Int = 10): List<String> = rows("SELECT text FROM notes ORDER BY id DESC LIMIT $limit") { it.getString(0) }

    // Tareas
    fun addTask(t: String) = writableDatabase.execSQL("INSERT INTO tasks(text,ts) VALUES(?,?)", arrayOf(t.trim(), now()))
    fun openTasks(): List<String> = rows("SELECT text FROM tasks WHERE done=0 ORDER BY id") { it.getString(0) }
    fun doneTask(match: String): Int =
        writableDatabase.compileStatement("UPDATE tasks SET done=1 WHERE done=0 AND lower(text) LIKE ?").run {
            bindString(1, "%" + match.trim().lowercase() + "%"); executeUpdateDelete()
        }

    // Historial (solo si el usuario lo permite)
    fun addHistory(role: String, text: String) = writableDatabase.execSQL("INSERT INTO history(role,text,ts) VALUES(?,?,?)", arrayOf(role, text, now()))
    fun history(limit: Int = 30): List<Triple<String, String, Long>> =
        rows("SELECT role,text,ts FROM history ORDER BY id DESC LIMIT $limit") { Triple(it.getString(0), it.getString(1), it.getLong(2)) }
    fun clearHistory() = writableDatabase.delete("history", null, null)

    // Recordatorios
    fun addReminder(text: String, at: Long): Long = writableDatabase.compileStatement("INSERT INTO reminders(text,at) VALUES(?,?)").run {
        bindString(1, text); bindLong(2, at); executeInsert()
    }
    fun pendingReminders(): List<Triple<Long, String, Long>> =
        rows("SELECT id,text,at FROM reminders WHERE done=0 AND at>?", now().toString()) { Triple(it.getLong(0), it.getString(1), it.getLong(2)) }
    fun finishReminder(id: Long) = writableDatabase.execSQL("UPDATE reminders SET done=1 WHERE id=?", arrayOf(id))

    /** Borra absolutamente todo lo que Verónica sabe del usuario. */
    fun wipeAll() = writableDatabase.run { listOf("facts", "notes", "tasks", "history", "reminders").forEach { delete(it, null, null) } }
}
