package mx.veronica.voice

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import mx.veronica.Veronica
import mx.veronica.ai.Http
import mx.veronica.util.Net
import mx.veronica.util.Wav
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.vosk.Recognizer

/** Voz a texto. Nube (alta calidad) con respaldo local (limitado, sin Internet). El audio nunca se guarda en disco. */
object Stt {
    suspend fun transcribe(ctx: Context, pcm: ByteArray): String {
        val p = Veronica.prefs
        if (!p.offlineOnly && Net.online(ctx) && p.sttKey.isNotBlank()) {
            try { return cloud(pcm) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { /* cae al modo local */ }
        }
        return offline(pcm)
    }

    private suspend fun cloud(pcm: ByteArray): String {
        val p = Veronica.prefs
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("model", p.sttModel)
            .addFormDataPart("language", p.lang2)
            .addFormDataPart("prompt", "Verónica, asistente personal. Oye Verónica.")
            .addFormDataPart("response_format", "json")
            .addFormDataPart("file", "audio.wav", Wav.wrap(pcm).toRequestBody("audio/wav".toMediaType()))
            .build()
        val req = Request.Builder().url(p.sttBaseUrl.trimEnd('/') + "/audio/transcriptions")
            .header("Authorization", "Bearer ${p.sttKey}").post(body).build()
        return JSONObject(Http.call(req)).optString("text").trim()
    }

    private suspend fun offline(pcm: ByteArray): String = withContext(Dispatchers.Default) {
        Recognizer(Veronica.models.model(), AudioEngine.RATE.toFloat()).use { r ->
            var i = 0
            while (i < pcm.size) { val n = minOf(8000, pcm.size - i); r.acceptWaveForm(pcm.copyOfRange(i, i + n), n); i += n }
            JSONObject(r.finalResult).optString("text").trim()
        }
    }
}
