package mx.veronica.tools

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import mx.veronica.Veronica
import mx.veronica.service.A11yService
import mx.veronica.service.NotificationHub
import mx.veronica.util.Calc
import mx.veronica.util.Net
import mx.veronica.util.Text
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object AppFinder {
    data class App(val label: String, val pkg: String)
    private val alias = mapOf("wasap" to "whatsapp", "guasap" to "whatsapp", "face" to "facebook", "insta" to "instagram", "mapas" to "maps")

    fun list(ctx: Context): List<App> {
        val pm = ctx.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
    }
    private fun score(label: String, q: String) = when {
        label == q -> 100; label.startsWith(q) -> 80; label.contains(q) -> 60
        q.split(" ").all { label.contains(it) } -> 40; else -> 0
    }
    fun find(ctx: Context, query: String): App? {
        val n = Text.norm(query).let { alias[it] ?: it }
        if (n.isEmpty()) return null
        return list(ctx).map { it to score(Text.norm(it.label), n) }.filter { it.second > 0 }.maxByOrNull { it.second }?.first
    }
}

object Contacts {
    private fun all(ctx: Context): List<Pair<String, String>> {
        val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        return ctx.contentResolver.query(p, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)
            ?.use { c -> buildList<Pair<String, String>> { while (c.moveToNext()) add(c.getString(0) to c.getString(1)) } } ?: emptyList()
    }
    /** Acepta un número directamente o busca por nombre (coincidencia exacta > empieza con > contiene). */
    fun resolve(ctx: Context, target: String): Pair<String, String>? {
        val digits = target.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 7) return target to digits
        val n = Text.norm(target)
        if (n.isEmpty()) return null
        return all(ctx).map { it to Text.norm(it.first).let { l -> when { l == n -> 3; l.startsWith(n) -> 2; l.contains(n) -> 1; else -> 0 } } }
            .filter { it.second > 0 }.maxByOrNull { it.second }?.first
    }
}

private fun fmtDur(s: Int): String {
    val h = s / 3600; val m = (s % 3600) / 60; val x = s % 60
    return listOfNotNull(
        if (h > 0) "$h hora${if (h > 1) "s" else ""}" else null,
        if (m > 0) "$m minuto${if (m > 1) "s" else ""}" else null,
        if (x > 0) "$x segundo${if (x > 1) "s" else ""}" else null,
    ).joinToString(" y ")
}

private fun isoToMillis(s: String) = LocalDateTime.parse(s).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

/** Implementaciones reales de cada herramienta de shared/tools.json para Android. */
fun androidHandlers(ctx: Context): Map<String, suspend (JSONObject) -> String> {
    val m = mutableMapOf<String, suspend (JSONObject) -> String>()
    val db = Veronica.db
    val p = Veronica.prefs
    fun h(name: String, f: suspend (JSONObject) -> String) { m[name] = f }
    fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }
    fun has(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
    fun key(code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // --- Aplicaciones y comunicación ---
    h("open_app") { a ->
        val q = a.optString("name")
        val app = AppFinder.find(ctx, q) ?: return@h "No encontré ninguna app llamada \"$q\"."
        go(ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return@h "No pude abrir ${app.label}.")
        "Abriendo ${app.label}."
    }
    h("call") { a ->
        val target = a.optString("contact")
        val (name, number) = Contacts.resolve(ctx, target) ?: return@h "No encontré a \"$target\" en tus contactos."
        val uri = Uri.parse("tel:" + Uri.encode(number))
        // Sin permiso CALL_PHONE se abre el marcador con el número; el usuario solo pulsa llamar.
        go(Intent(if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        "Llamando a $name."
    }
    h("send_sms") { a ->
        val target = a.optString("contact"); val msg = a.optString("message")
        val (name, number) = Contacts.resolve(ctx, target) ?: return@h "No encontré a \"$target\" en tus contactos."
        if (has(Manifest.permission.SEND_SMS)) {
            val sms = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            sms.sendMultipartTextMessage(number, null, sms.divideMessage(msg), null, null)
            "Mensaje enviado a $name."
        } else {
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", msg))
            "No tengo permiso de SMS; dejé el mensaje listo para $name en tu app de mensajes."
        }
    }
    h("send_whatsapp") { a ->
        val target = a.optString("contact")
        val (name, number) = Contacts.resolve(ctx, target) ?: return@h "No encontré a \"$target\" en tus contactos."
        var d = number.filter { it.isDigit() }
        if (d.length == 10) d = "52$d" // México: lada país por omisión para números de 10 dígitos
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=${Uri.encode(a.optString("message"))}")))
        "Abrí el chat con $name con el mensaje listo; solo pulsa enviar."
    }
    h("contacts_lookup") { a ->
        val r = Contacts.resolve(ctx, a.optString("name")) ?: return@h "No encontré ese contacto."
        "${r.first}: ${r.second}"
    }

    // --- Tiempo y organización ---
    h("timer") { a ->
        val secs = a.optInt("seconds", 0)
        if (secs <= 0) return@h "¿De cuánto tiempo quieres el temporizador?"
        try {
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Verónica")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Temporizador de ${fmtDur(secs)} en marcha."
        } catch (e: ActivityNotFoundException) {
            val at = System.currentTimeMillis() + secs * 1000L
            val text = "Tu temporizador de ${fmtDur(secs)} terminó"
            Reminders.schedule(ctx, db.addReminder(text, at), text, at)
            "Temporizador de ${fmtDur(secs)} en marcha."
        }
    }
    h("alarm") { a ->
        try {
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Verónica")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "Alarma creada para las ${a.optInt("hour")}:${"%02d".format(a.optInt("minute"))}."
        } catch (e: ActivityNotFoundException) { "No encontré una app de reloj para crear la alarma." }
    }
    h("reminder") { a ->
        val text = a.optString("text").ifBlank { return@h "¿Qué quieres que te recuerde?" }
        val at = if (a.optString("at").isNotBlank()) isoToMillis(a.optString("at")) else System.currentTimeMillis() + a.optLong("minutes", 0) * 60_000
        if (at <= System.currentTimeMillis() + 5_000) return@h "La hora del recordatorio ya pasó o no es válida."
        Reminders.schedule(ctx, db.addReminder(text, at), text, at)
        "Listo, te lo recordaré."
    }
    h("calendar_add") { a ->
        val start = isoToMillis(a.optString("start"))
        go(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, a.optString("title"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + a.optLong("minutes", 60) * 60_000))
        "Abrí tu calendario con el evento listo; solo falta que lo guardes."
    }
    h("calendar_upcoming") { a ->
        if (!has(Manifest.permission.READ_CALENDAR)) return@h "Necesito el permiso de Calendario."
        val begin = System.currentTimeMillis(); val days = a.optLong("days", 7)
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also { ContentUris.appendId(it, begin); ContentUris.appendId(it, begin + days * 86_400_000) }.build()
        val f = DateTimeFormatter.ofPattern("EEEE d 'de' MMMM, HH:mm", Locale("es", "MX"))
        val rows = ctx.contentResolver.query(uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), null, null, "${CalendarContract.Instances.BEGIN} ASC")
            ?.use { c -> buildList<String> { while (c.moveToNext() && size < 8) add("${Instant.ofEpochMilli(c.getLong(1)).atZone(ZoneId.systemDefault()).format(f)}: ${c.getString(0)}") } } ?: emptyList()
        if (rows.isEmpty()) "No tienes eventos en los próximos $days días." else rows.joinToString("\n")
    }
    h("notes_add") { a -> db.addNote(a.optString("text")); "Nota guardada." }
    h("notes_list") { _ -> db.notes().ifEmpty { return@h "No tienes notas guardadas." }.joinToString("\n") { "- $it" } }
    h("tasks_add") { a -> db.addTask(a.optString("text")); "Tarea agregada." }
    h("tasks_list") { _ -> db.openTasks().ifEmpty { return@h "No tienes tareas pendientes." }.joinToString("\n") { "- $it" } }
    h("tasks_done") { a -> if (db.doneTask(a.optString("text")) > 0) "Marcada como hecha." else "No encontré esa tarea." }
    h("remember") { a ->
        if (!p.memoryEnabled || p.privateMode) return@h "La memoria está desactivada; el usuario puede activarla en mis ajustes."
        db.putFact(a.optString("key"), a.optString("value")); "Guardado."
    }
    h("forget") { a -> db.delFact(a.optString("key")); "Olvidado." }

    // --- Datos en vivo ---
    h("weather") { a -> WebTools.weather(a.optString("city")) }
    h("news") { a -> WebTools.news(a.optString("topic")) }
    h("currency") { a -> WebTools.currency(a.optDouble("amount", 1.0), a.optString("from"), a.optString("to")) }
    h("web_search") { a -> WebTools.search(a.optString("query")) }
    h("calc") { a -> Calc.eval(a.optString("expression")) }
    h("open_url") { a ->
        val u = a.optString("url").let { if (it.startsWith("http")) it else "https://$it" }
        go(Intent(Intent.ACTION_VIEW, Uri.parse(u))); "Abriendo la página."
    }
    h("set_language") { a ->
        val l = a.optString("lang")
        if (Locale.forLanguageTag(l).language.isEmpty()) return@h "Código de idioma no válido."
        p.language = l; "Idioma cambiado a $l."
    }

    // --- Dispositivo ---
    h("media") { a ->
        key(when (a.optString("action")) {
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY
        }); "Hecho."
    }
    h("play_music") { a ->
        val q = a.optString("query")
        if (q.isBlank()) { key(KeyEvent.KEYCODE_MEDIA_PLAY); return@h "Reanudando la música." }
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*").putExtra(SearchManager.QUERY, q)
        if (p.musicApp.isNotBlank()) AppFinder.find(ctx, p.musicApp)?.let { i.setPackage(it.pkg) }
        try { go(i); "Buscando $q." } catch (e: ActivityNotFoundException) { "No encontré una app de música compatible." }
    }
    h("volume") { a ->
        val am = ctx.getSystemService(AudioManager::class.java)
        val s = AudioManager.STREAM_MUSIC
        when (a.optString("action")) {
            "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "unmute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
            "set" -> am.setStreamVolume(s, a.optInt("level", 50).coerceIn(0, 100) * am.getStreamMaxVolume(s) / 100, AudioManager.FLAG_SHOW_UI)
            else -> return@h "Acción de volumen no válida."
        }
        "Hecho."
    }
    h("flashlight") { a ->
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return@h "Este teléfono no tiene linterna."
        val on = a.optBoolean("on", true)
        cm.setTorchMode(id, on)
        if (on) "Linterna encendida." else "Linterna apagada."
    }
    h("open_settings") { a ->
        val action = when (a.optString("section")) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS; "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY; "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS; "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        go(Intent(action)); "Abriendo los ajustes."
    }
    h("device_info") { _ ->
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val free = StatFs(Environment.getDataDirectory().path).availableBytes / 1e9
        "Batería al ${lvl * 100 / scale}%${if (charging) ", cargando" else ""}. " +
            "${if (Net.online(ctx)) "Con conexión a Internet" else "Sin conexión a Internet"}. " +
            "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}. Almacenamiento libre: ${"%.1f".format(free)} gigabytes."
    }
    h("system_nav") { a -> A11yService.act(a.optString("action")) }
    h("read_notifications") { _ -> NotificationHub.summary(ctx) }
    h("share_text") { a ->
        go(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.optString("text")), null))
        "Abriendo el menú de compartir."
    }
    return m
}
