package mx.veronica.service

import android.content.Context
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import mx.veronica.Veronica

/**
 * Ancla del sistema. Cuando el usuario elige a Verónica como "app de asistente digital":
 *  - Android mantiene este servicio vivo y lo reconecta tras reiniciar.
 *  - Una app que provee VoiceInteractionService está exenta de las restricciones de Android 12-15 para
 *    iniciar un servicio de micrófono desde segundo plano, así que aquí se reactiva la escucha permanente.
 *  - El gesto del sistema (mantener botón de encendido / deslizar desde la esquina) activa a Verónica.
 */
class VeronicaInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        if (Veronica.prefs.listeningEnabled && !Veronica.prefs.muted) runCatching { ListenService.start(this) }
    }
}

class VeronicaSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = VeronicaSession(this)
}

class VeronicaSession(private val ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        ListenService.activate(ctx)
        hide() // la interfaz es el símbolo flotante propio, no la hoja del sistema
    }
}
