package mx.veronica.tools

import mx.veronica.Veronica
import mx.veronica.ai.Http
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder

/** Datos en vivo. Clima, noticias y divisas no requieren clave de API. */
object WebTools {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private suspend fun get(url: String) = Http.call(Request.Builder().url(url).header("User-Agent", "Veronica/0.1").build())

    private fun wmo(c: Int) = when (c) {
        0 -> "despejado"; 1 -> "mayormente despejado"; 2 -> "parcialmente nublado"; 3 -> "nublado"
        45, 48 -> "con niebla"; 51, 53, 55 -> "con llovizna"; 56, 57, 66, 67 -> "con lluvia helada"
        61 -> "con lluvia ligera"; 63 -> "con lluvia"; 65 -> "con lluvia fuerte"
        71, 73, 75, 77, 85, 86 -> "con nieve"; 80, 81, 82 -> "con chubascos"
        95 -> "con tormenta"; 96, 99 -> "con tormenta y granizo"; else -> "variable"
    }

    suspend fun weather(cityArg: String): String {
        val city = cityArg.ifBlank { Veronica.prefs.city }
        if (city.isBlank()) return "Falta la ciudad. Pregunta al usuario de qué ciudad quiere el clima."
        val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city.substringBefore(','))}&count=1&language=es"))
            .optJSONArray("results")?.optJSONObject(0) ?: return "No encontré la ciudad \"$city\"."
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${geo.getDouble("latitude")}&longitude=${geo.getDouble("longitude")}" +
            "&current=temperature_2m,apparent_temperature,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=3"
        val j = JSONObject(get(url))
        val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
        fun day(i: Int, label: String) =
            "$label: ${wmo(d.getJSONArray("weather_code").getInt(i))}, máxima ${d.getJSONArray("temperature_2m_max").getDouble(i).toInt()}°, " +
                "mínima ${d.getJSONArray("temperature_2m_min").getDouble(i).toInt()}°, probabilidad de lluvia ${d.getJSONArray("precipitation_probability_max").optInt(i)}%."
        return "Clima en ${geo.getString("name")}: ahora ${cur.getDouble("temperature_2m").toInt()}°, ${wmo(cur.getInt("weather_code"))}, " +
            "sensación de ${cur.getDouble("apparent_temperature").toInt()}°. ${day(0, "Hoy")} ${day(1, "Mañana")} ${day(2, "Pasado mañana")}"
    }

    suspend fun news(topic: String): String {
        val base = if (topic.isBlank()) "https://news.google.com/rss?" else "https://news.google.com/rss/search?q=${enc(topic)}&"
        val xml = get(base + "hl=es-419&gl=MX&ceid=MX:es-419")
        val titles = Regex("<item>.*?<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).findAll(xml).map {
            it.groupValues[1].replace("<![CDATA[", "").replace("]]>", "").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        }.take(5).toList()
        return if (titles.isEmpty()) "No encontré titulares." else titles.mapIndexed { i, t -> "${i + 1}. $t" }.joinToString("\n")
    }

    suspend fun currency(amount: Double, from: String, to: String): String {
        val f = from.uppercase().trim(); val t = to.uppercase().trim()
        val j = JSONObject(get("https://api.frankfurter.dev/v1/latest?base=$f&symbols=$t"))
        val rate = j.getJSONObject("rates").optDouble(t, Double.NaN)
        if (rate.isNaN()) return "No tengo el tipo de cambio de $f a $t."
        return "%,.2f $f equivalen a %,.2f $t (cambio del ${j.optString("date")}, datos del Banco Central Europeo).".format(amount, amount * rate)
    }

    suspend fun search(query: String): String {
        val key = Veronica.prefs.searchKey
        if (key.isNotBlank()) {
            val body = JSONObject().put("query", query).put("max_results", 4).put("include_answer", true).toString()
            val r = JSONObject(Http.call(Request.Builder().url("https://api.tavily.com/search")
                .header("Authorization", "Bearer $key").post(body.toRequestBody(Http.JSON)).build()))
            val items = r.optJSONArray("results")
            val lines = (0 until (items?.length() ?: 0)).map { items!!.getJSONObject(it).let { o -> "${o.optString("title")}: ${o.optString("content").take(260)}" } }
            return (r.optString("answer").takeIf { it.isNotBlank() && it != "null" }?.let { "Resumen: $it\n" } ?: "") + lines.joinToString("\n")
        }
        // Sin clave: Wikipedia en español como respaldo gratuito
        val w = JSONObject(get("https://es.wikipedia.org/w/api.php?action=query&list=search&srsearch=${enc(query)}&format=json&srlimit=3&utf8=1"))
            .getJSONObject("query").getJSONArray("search")
        if (w.length() == 0) return "No encontré resultados. Configura una clave de búsqueda web (Tavily) para resultados más amplios."
        return (0 until w.length()).joinToString("\n") {
            w.getJSONObject(it).let { o -> "${o.getString("title")}: ${o.getString("snippet").replace(Regex("<[^>]+>"), "")}" }
        } + "\n(Fuente: Wikipedia; para búsqueda web general configura Tavily.)"
    }
}
