package mx.veronica.ai

import mx.veronica.util.Text
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Nivel 1 de decisión: órdenes que se ejecutan directo, sin pasar por la IA (más rápido y funciona sin Internet).
 * Todo lo que no coincida aquí pasa al agente de lenguaje.
 */
object OfflineRouter {
    /** tool vacío = solo habla. soft = si falla, dejar que la IA lo intente. close = termina la conversación. */
    data class Cmd(val tool: String, val args: JSONObject, val say: String, val soft: Boolean = false, val close: Boolean = false)

    private fun c(tool: String, say: String, vararg kv: Pair<String, Any>, soft: Boolean = false, close: Boolean = false) =
        Cmd(tool, JSONObject().apply { kv.forEach { put(it.first, it.second) } }, say, soft, close)

    fun sayTime(now: LocalDateTime = LocalDateTime.now()): String {
        val h12 = (now.hour % 12).let { if (it == 0) 12 else it }
        val part = when { now.hour < 6 -> "de la madrugada"; now.hour < 12 -> "de la mañana"; now.hour < 19 -> "de la tarde"; else -> "de la noche" }
        val verb = if (h12 == 1) "Es la" else "Son las"
        return "$verb $h12:${"%02d".format(now.minute)} $part."
    }

    fun sayDate(now: LocalDateTime = LocalDateTime.now()): String =
        "Hoy es " + now.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "MX"))) + "."

    fun route(raw: String): Cmd? {
        val t = Text.norm(raw)
        if (t.isEmpty()) return null

        if (Regex("^(gracias|muchas gracias|nada mas|eso es todo|ya esta|cancela|cancelar|olvidalo|dejalo)( verónica| veronica)?$").matches(t))
            return c("", "Con gusto.", close = true)

        Regex("(temporizador|timer|cuenta regresiva).*?(\\d+)\\s*(segundo|minuto|hora)").find(t)?.let { m ->
            val n = m.groupValues[2].toInt()
            val unit = m.groupValues[3]
            val mul = when (unit) { "segundo" -> 1; "minuto" -> 60; else -> 3600 }
            return c("timer", "Listo, temporizador de $n $unit${if (n == 1) "" else "s"}.", "seconds" to n * mul)
        }
        if (Regex("\\bque hora es\\b|dime la hora|hora actual|me dices la hora").containsMatchIn(t)) return c("", sayTime())
        if (Regex("\\bque dia es\\b|fecha de hoy|que fecha es|a cuanto estamos").containsMatchIn(t)) return c("", sayDate())

        if (Regex("\\b(sube|subir|aumenta|aumentar)\\b.*volumen|mas volumen").containsMatchIn(t)) return c("volume", "Listo.", "action" to "up")
        if (Regex("\\b(baja|bajar|disminuye|reduce)\\b.*volumen|menos volumen").containsMatchIn(t)) return c("volume", "Listo.", "action" to "down")
        if (Regex("\\b(silencia|mutea|silenciar)\\b").containsMatchIn(t)) return c("volume", "Silenciado.", "action" to "mute")

        if (Regex("^(pausa|pausar|pon pausa|deten|detener|para)( la)?( musica| cancion| reproduccion)?$").matches(t)) return c("media", "", "action" to "pause")
        if (Regex("^(siguiente|siguiente cancion|salta|salta la cancion|pasa la cancion)$").matches(t)) return c("media", "", "action" to "next")
        if (Regex("^(anterior|cancion anterior|regresa|regresa la cancion)$").matches(t)) return c("media", "", "action" to "previous")
        if (Regex("^(reanuda|continua|continua la musica|dale play|reproduce)$").matches(t)) return c("media", "", "action" to "play")

        if (Regex("\\b(enciende|prende|activa)\\b.*linterna").containsMatchIn(t)) return c("flashlight", "Listo.", "on" to true)
        if (Regex("\\b(apaga|desactiva)\\b.*linterna").containsMatchIn(t)) return c("flashlight", "Listo.", "on" to false)

        Regex("^(abre|abrir|abreme|inicia|lanza|ejecuta)( la app de| la aplicacion de| la app| la aplicacion| el| la| mi)? (.+)$").find(t)?.let {
            return c("open_app", "", "name" to it.groupValues[3], soft = true)
        }
        return null
    }
}
