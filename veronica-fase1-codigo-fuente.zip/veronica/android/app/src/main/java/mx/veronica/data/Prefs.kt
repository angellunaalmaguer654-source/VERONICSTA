package mx.veronica.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Claves de API cifradas con AES-GCM; la llave maestra vive en el Android Keystore y no sale del dispositivo. */
class SecretStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("veronica_secrets", Context.MODE_PRIVATE)
    private val alias = "veronica_master"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return kg.generateKey()
    }

    fun put(name: String, value: String) {
        if (value.isBlank()) { sp.edit().remove(name).apply(); return }
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val ct = c.doFinal(value.toByteArray())
        sp.edit().putString(name, Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)).apply()
    }

    fun get(name: String): String = try {
        val raw = Base64.decode(sp.getString(name, null) ?: return "", Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
            .apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12)) }
        String(c.doFinal(raw, 12, raw.size - 12))
    } catch (e: Exception) { "" }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("veronica", Context.MODE_PRIVATE)
    val secrets = SecretStore(ctx)

    private fun str(k: String, d: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) = sp.edit().putString(k, value).apply()
    }
    private fun bool(k: String, d: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) = sp.edit().putBoolean(k, value).apply()
    }
    private fun int(k: String, d: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) = sp.edit().putInt(k, value).apply()
    }
    private fun float(k: String, d: Float) = object : ReadWriteProperty<Any?, Float> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getFloat(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) = sp.edit().putFloat(k, value).apply()
    }

    // Activación
    var listeningEnabled by bool("listening", false)
    var muted by bool("muted", false)
    var wakePhrases by str("wake", "oye verónica,hola verónica,verónica")
    var greeting by str("greeting", "voz")            // voz | tono | ninguno
    var followUpMs by int("followup", 4000)
    var bargeIn by bool("bargein", true)
    var language by str("lang", "es-MX")
    // Cerebro (LLM)
    var llmProvider by str("llm_provider", "anthropic") // anthropic | openai (compatible)
    var llmBaseUrl by str("llm_url", "https://api.anthropic.com")
    var llmModel by str("llm_model", "claude-haiku-5-5")
    // Voz a texto en la nube (compatible con OpenAI: OpenAI, Groq, etc.)
    var sttBaseUrl by str("stt_url", "https://api.openai.com/v1")
    var sttModel by str("stt_model", "whisper-1")
    // Texto a voz
    var ttsMode by str("tts_mode", "system")          // system | cloud
    var ttsBaseUrl by str("tts_url", "https://api.openai.com/v1")
    var ttsModel by str("tts_model", "gpt-4o-mini-tts")
    var ttsVoice by str("tts_voice", "nova")
    var systemVoice by str("sys_voice", "")
    var ttsRate by float("tts_rate", 1.0f)
    // Otros
    var city by str("city", "")
    var musicApp by str("music_app", "")
    // Privacidad
    var saveHistory by bool("save_history", true)
    var memoryEnabled by bool("memory", true)
    var privateMode by bool("private", false)
    var offlineOnly by bool("offline_only", false)

    var llmKey: String
        get() = secrets.get("llm_key")
        set(v) = secrets.put("llm_key", v)
    /** Si está vacía se reutiliza la clave del LLM (útil con Groq/OpenAI, que sirven ambos). */
    var sttKey: String
        get() = secrets.get("stt_key").ifBlank { llmKey }
        set(v) = secrets.put("stt_key", v)
    var ttsKey: String
        get() = secrets.get("tts_key").ifBlank { llmKey }
        set(v) = secrets.put("tts_key", v)
    var searchKey: String
        get() = secrets.get("search_key")
        set(v) = secrets.put("search_key", v)

    val wakeList: List<String> get() = wakePhrases.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    val lang2: String get() = language.substringBefore('-').lowercase()
}
