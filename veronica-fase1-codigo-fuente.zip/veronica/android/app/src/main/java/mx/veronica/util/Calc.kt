package mx.veronica.util

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*

/** Evaluador aritmético propio: los modelos de lenguaje calculan mal, así que Verónica delega aquí. */
object Calc {
    fun eval(src: String): String {
        val s = src.lowercase().replace(',', '.').replace('×', '*').replace('÷', '/').replace("−", "-")
        val v = Parser(s).run()
        if (v.isNaN() || v.isInfinite()) error("Resultado no válido")
        return BigDecimal(v).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var i = 0
        fun run(): Double { val v = expr(); skip(); if (i < s.length) error("Expresión no válida"); return v }
        fun skip() { while (i < s.length && s[i] == ' ') i++ }
        fun eat(c: Char): Boolean { skip(); return if (i < s.length && s[i] == c) { i++; true } else false }
        fun expr(): Double { var v = term(); while (true) v = if (eat('+')) v + term() else if (eat('-')) v - term() else return v }
        fun term(): Double { var v = pow(); while (true) v = if (eat('*')) v * pow() else if (eat('/')) v / pow() else if (eat('%')) v % pow() else return v }
        fun pow(): Double { val b = unary(); return if (eat('^')) b.pow(pow()) else b }
        fun unary(): Double = if (eat('-')) -unary() else if (eat('+')) unary() else atom()
        fun atom(): Double {
            skip()
            if (eat('(')) { val v = expr(); if (!eat(')')) error("Falta cerrar paréntesis"); return v }
            val st = i
            if (i < s.length && (s[i].isDigit() || s[i] == '.')) {
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                return s.substring(st, i).toDouble()
            }
            while (i < s.length && s[i].isLetter()) i++
            val name = s.substring(st, i)
            if (name == "pi") return PI
            if (name == "e") return E
            if (name.isEmpty() || !eat('(')) error("Expresión no válida")
            val a = expr(); eat(')')
            return when (name) {
                "sqrt", "raiz" -> sqrt(a)
                "sin" -> sin(Math.toRadians(a)); "cos" -> cos(Math.toRadians(a)); "tan" -> tan(Math.toRadians(a))
                "log" -> log10(a); "ln" -> ln(a); "abs" -> abs(a)
                "round" -> a.roundToInt().toDouble(); "floor" -> floor(a); "ceil" -> ceil(a)
                else -> error("Función desconocida: $name")
            }
        }
    }
}
