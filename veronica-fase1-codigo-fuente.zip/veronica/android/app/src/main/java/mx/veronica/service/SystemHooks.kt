package mx.veronica.service

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import mx.veronica.R
import mx.veronica.Veronica
import mx.veronica.tools.Reminders

/** Tras reiniciar: reprograma recordatorios y reintenta la escucha; si Android lo impide, avisa con una notificación tocable. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Reminders.rescheduleAll(ctx)
        if (!Veronica.prefs.listeningEnabled || Veronica.prefs.muted) return
        try { ListenService.start(ctx) }
        catch (e: Exception) {
            // Android 14+ prohíbe iniciar un servicio de micrófono desde BOOT_COMPLETED.
            // Tocar la notificación sí está permitido: es una acción del usuario.
            val pi = PendingIntent.getForegroundService(ctx, 9, Intent(ctx, ListenService::class.java).setAction(ListenService.ACTION_START),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            Reminders.channel(ctx)
            ctx.getSystemService(NotificationManager::class.java).notify(9,
                NotificationCompat.Builder(ctx, Reminders.CHANNEL).setSmallIcon(R.drawable.ic_stat_orb)
                    .setContentTitle("Verónica está en pausa").setContentText("Toca para reactivar la escucha").setContentIntent(pi).setAutoCancel(true).build())
        }
    }
}

/** Lee notificaciones activas bajo demanda. No guarda nada en disco. */
class NotificationHub : NotificationListenerService() {
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }

    companion object {
        @Volatile var instance: NotificationHub? = null
        fun summary(ctx: Context): String {
            if (!NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName))
                return "Necesito acceso a notificaciones. Actívalo en los ajustes de Verónica."
            val hub = instance ?: return "El acceso a notificaciones aún no está listo; intenta en unos segundos."
            val pm = ctx.packageManager
            val lines = hub.activeNotifications.filter { !it.isOngoing && it.packageName != ctx.packageName }.take(8).mapNotNull { n ->
                val ex = n.notification.extras
                val title = ex.getCharSequence("android.title")?.toString().orEmpty()
                val text = ex.getCharSequence("android.text")?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) null
                else "${runCatching { pm.getApplicationLabel(pm.getApplicationInfo(n.packageName, 0)) }.getOrDefault(n.packageName)}: $title $text".trim()
            }
            return if (lines.isEmpty()) "No tienes notificaciones pendientes." else lines.joinToString("\n")
        }
    }
}

/** Solo acciones globales (inicio, atrás, recientes...). No lee el contenido de la pantalla (canRetrieveWindowContent=false). */
class A11yService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { if (instance === this) instance = null; return super.onUnbind(intent) }

    companion object {
        @Volatile var instance: A11yService? = null
        fun act(action: String): String {
            val s = instance ?: return "Necesito el servicio de accesibilidad de Verónica. Actívalo en sus ajustes."
            val code = when (action) {
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME; "back" -> AccessibilityService.GLOBAL_ACTION_BACK; "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS; "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return "Bloquear la pantalla requiere Android 9 o superior."
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return "Las capturas requieren Android 9 o superior."
                else -> return "Acción de navegación no válida."
            }
            return if (s.performGlobalAction(code)) "Hecho." else "Android no me permitió hacerlo."
        }
    }
}

/** Exigido por el sistema para listar a Verónica como asistente; no ofrece reconocimiento a otras apps. */
class VeronicaRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, callback: Callback?) { callback?.error(SpeechRecognizer.ERROR_CLIENT) }
    override fun onCancel(callback: Callback?) {}
    override fun onStopListening(callback: Callback?) {}
}
