package mx.veronica.ai

import android.content.Context
import kotlinx.coroutines.CancellationException
import mx.veronica.Veronica
import mx.veronica.tools.ToolRegistry
import mx.veronica.util.Net
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Puente entre el cerebro y quien habla/escucha/confirma (el Conductor). */
interface AgentIO {
    suspend fun say(text: String)
    suspend fun confirm(question: String): Boolean
    fun executing()
    fun error()
}

data class AgentReply(val say: String, val calls: List<Pair<String, JSONObject>>, val followUp: String)

object Reply {
    fun parse(raw: String): AgentReply {
        val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return AgentReply(raw.trim(), emptyList(), "open")
        return try {
            val o = JSONObject(raw.substring(s, e + 1))
            val calls = o.optJSONArray("tools")?.let { a ->
                (0 until a.length()).mapNotNull { i ->
                    a.optJSONObject(i)?.let { t -> t.optString("name") to (t.optJSONObject("args") ?: JSONObject()) }
                }
            }.orEmpty()
            AgentReply(o.optString("say"), calls, o.optString("follow_up", "open"))
        } catch (ex: Exception) { AgentReply(raw.trim(), emptyList(), "open") }
    }
}

object Prompt {
    private var template: String? = null

    fun build(ctx: Context, tools: ToolRegistry): String {
        val p = Veronica.prefs
        val tpl = template ?: ctx.assets.open("system_prompt.es-MX.txt").bufferedReader().readText().also { template = it }
        val now = ZonedDateTime.now()
        val fecha = now.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es", "MX"))) + " (${now.zone})"
        val facts = if (p.memoryEnabled && !p.privateMode) Veronica.db.facts() else emptyList()
        val memoria = if (facts.isEmpty()) "(sin datos guardados)" else facts.joinToString("\n") { "- ${it.first}: ${it.second}" }
        val usuario = facts.firstOrNull { it.first == "nombre" }?.second ?: "su dueño"
        return tpl.replace("{{usuario}}", usuario).replace("{{plataforma}}", "teléfono Android")
            .replace("{{fecha}}", fecha).replace("{{idioma}}", p.language)
            .replace("{{memoria}}", memoria).replace("{{herramientas}}", tools.catalog())
    }
}

/**
 * Cerebro: 1) órdenes directas, 2) bucle de lenguaje + herramientas (máx. 4 vueltas),
 * 3) respaldo limitado sin Internet. El historial se descarta tras 10 min de inactividad.
 */
class Agent(private val ctx: Context, private val tools: ToolRegistry) {
    private val p get() = Veronica.prefs
    private val history = ArrayDeque<Msg>()
    private var lastAt = 0L
    var followUp = "open"; private set

    private fun log(role: String, text: String) {
        if (p.saveHistory && !p.privateMode && text.isNotBlank()) Veronica.db.addHistory(role, text)
    }

    suspend fun handle(text: String, io: AgentIO) {
        if (System.currentTimeMillis() - lastAt > 10 * 60_000) history.clear()
        lastAt = System.currentTimeMillis()
        followUp = "open"
        log("user", text)

        // Nivel 1: orden directa
        OfflineRouter.route(text)?.let { cmd ->
            var ok = true
            if (cmd.tool.isNotEmpty()) {
                io.executing()
                val res = tools.run(cmd.tool, cmd.args, io)
                ok = !res.startsWith("No encontré") && !res.startsWith("Error") && !res.startsWith("Falta")
                if (!ok && !cmd.soft) { io.say(res); log("assistant", res); return }
                if (ok && cmd.say.isBlank() && cmd.tool == "open_app") { io.say(res); log("assistant", res) }
            }
            if (ok) {
                if (cmd.say.isNotBlank()) { io.say(cmd.say); log("assistant", cmd.say) }
                followUp = if (cmd.close) "close" else "open"
                return
            }
        }

        // Respaldo: sin conexión o sin configurar
        if (p.offlineOnly || !Net.online(ctx)) {
            val m = "Ahora mismo estoy sin conexión. Puedo ayudarte con comandos básicos como abrir apps, temporizadores, volumen, la hora o tus notas."
            io.say(m); log("assistant", m); return
        }
        if (p.llmKey.isBlank() && p.llmBaseUrl.startsWith("https://")) {
            val m = "Todavía no tengo configurada mi inteligencia. Abre mis ajustes y agrega una clave de API."
            io.say(m); log("assistant", m); return
        }

        // Nivel 2: lenguaje + herramientas
        val system = Prompt.build(ctx, tools)
        val msgs = history.toMutableList().also { it += Msg("user", text) }
        val spoken = StringBuilder()
        try {
            for (step in 0 until 4) {
                val raw = Llms.current(p).chat(system, msgs)
                val r = Reply.parse(raw)
                msgs += Msg("assistant", raw)
                if (r.say.isNotBlank()) { io.say(r.say); spoken.append(r.say).append(' ') }
                followUp = r.followUp
                if (r.calls.isEmpty()) break
                io.executing()
                val results = r.calls.take(4).map { (name, args) ->
                    JSONObject().put("tool", name).put("result", tools.run(name, args, io)).toString()
                }
                msgs += Msg("user", "RESULTADOS_DE_HERRAMIENTAS:\n" + results.joinToString("\n"))
            }
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) {
            io.error()
            io.say("No pude conectarme con mi inteligencia. Revisa tu conexión o la configuración de la API.")
            return
        }
        if (spoken.isBlank()) { io.say("Listo."); spoken.append("Listo.") }
        val finalText = spoken.toString().trim()
        log("assistant", finalText)
        history += Msg("user", text)
        history += Msg("assistant", JSONObject().put("say", finalText).put("tools", JSONArray()).put("follow_up", followUp).toString())
        while (history.size > 16) history.removeFirst()
    }
}
