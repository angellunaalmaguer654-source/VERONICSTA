package mx.veronica.ui

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator

/**
 * Ventana flotante transparente con el símbolo. Permanece oculta mientras Verónica espera:
 * aparece al activarse y se desvanece al terminar. Requiere el permiso "Mostrar sobre otras apps".
 * Android no dibuja superposiciones sobre la pantalla de bloqueo.
 */
class OverlayController(private val ctx: Context, private val onTap: () -> Unit) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private val orb = OrbView(ctx)
    private var attached = false
    private val size = (176 * ctx.resources.displayMetrics.density).toInt()

    private val lp = WindowManager.LayoutParams(
        size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (56 * ctx.resources.displayMetrics.density).toInt() }

    val canShow get() = Settings.canDrawOverlays(ctx)

    init {
        orb.visibility = View.GONE
        orb.setOnClickListener { onTap() }
        orb.setOnLongClickListener {
            ctx.startActivity(Intent(ctx, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        }
    }

    fun attach() = main.post {
        if (!attached && canShow) { wm.addView(orb, lp); attached = true }
    }

    fun detach() = main.post {
        if (attached) { runCatching { wm.removeView(orb) }; attached = false }
    }

    fun setState(s: OrbState) = main.post { orb.state = s }
    fun level(v: Float) { orb.level = v }

    fun show() = main.post {
        if (!attached) return@post
        orb.animate().cancel()
        if (orb.visibility != View.VISIBLE) { orb.alpha = 0f; orb.scaleX = 0.55f; orb.scaleY = 0.55f; orb.visibility = View.VISIBLE }
        orb.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(1.3f)).start()
    }

    fun hide() = main.post {
        if (!attached) return@post
        orb.animate().cancel()
        orb.animate().alpha(0f).scaleX(0.7f).scaleY(0.7f).setDuration(260)
            .withEndAction { orb.visibility = View.GONE }.start()
    }
}
