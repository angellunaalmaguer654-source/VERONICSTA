using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using NAudio.CoreAudioApi;

namespace Veronica;

delegate Task<string> Handler(JsonObject args, CancellationToken ct);

/// <summary>Enlaces del Conductor para herramientas que necesitan tocar la interfaz.</summary>
static class Hooks
{
    public static Action? HideOverlay, ShowOverlay;
    public static Action<string>? Announce;
}

sealed record ToolSpec(string Name, string Desc, Dictionary<string, string> Args, string? Confirm, (string Key, string[] Values)? ConfirmIf, bool Offline);

/// <summary>Catálogo en shared/tools.json (idéntico en Android); aquí solo se enlaza con su implementación.</summary>
sealed class ToolRegistry
{
    public readonly Dictionary<string, ToolSpec> Specs = new();
    readonly Dictionary<string, Handler> handlers;

    public ToolRegistry(Dictionary<string, Handler> handlers)
    {
        this.handlers = handlers;
        foreach (var o in JsonNode.Parse(Embedded.Read("tools.json"))!.AsArray().OfType<JsonObject>())
        {
            if (!o["platforms"]!.AsArray().Any(p => p!.ToString() == "windows")) continue;
            var args = o["args"]!.AsObject().ToDictionary(k => k.Key, k => k.Value!.ToString());
            (string, string[])? ci = null;
            if (o["confirm_if"] is JsonObject c) { var f = c.First(); ci = (f.Key, f.Value!.AsArray().Select(x => x!.ToString()).ToArray()); }
            var name = o["name"]!.ToString();
            Specs[name] = new ToolSpec(name, o["desc"]!.ToString(), args, o["confirm"]?.ToString(), ci, o["offline"]?.GetValue<bool>() ?? false);
        }
    }

    public string Catalog() => string.Join("\n", Specs.Values.Where(s => !Cfg.S.OfflineOnly || s.Offline)
        .Select(s => $"- {s.Name}({string.Join(", ", s.Args.Select(a => $"{a.Key}: {a.Value}"))}): {s.Desc}"));

    bool NeedsConfirm(ToolSpec s, JsonObject a) => s.Confirm is not null && (s.ConfirmIf is not { } ci || ci.Values.Contains(a[ci.Key]?.ToString() ?? ""));

    static string Fill(string t, JsonObject a) => System.Text.RegularExpressions.Regex.Replace(t, @"\{(\w+)\}", m => a[m.Groups[1].Value]?.ToString() ?? "");

    public async Task<string> Run(string name, JsonObject args, IAgentIO io, CancellationToken ct)
    {
        if (!Specs.TryGetValue(name, out var spec)) return $"Error: herramienta desconocida ({name}).";
        if (!handlers.TryGetValue(name, out var h)) return $"Error: herramienta aún no implementada ({name}).";
        if (NeedsConfirm(spec, args) && !await io.Confirm(Fill(spec.Confirm!, args), ct)) return "El usuario canceló la acción.";
        try { return await h(args, ct); }
        catch (OperationCanceledException) { throw; }
        catch (Exception e) { return "Error: " + e.Message; }
    }
}

static class Native
{
    [DllImport("user32.dll")] public static extern bool LockWorkStation();
    [DllImport("powrprof.dll")] public static extern bool SetSuspendState(bool hibernate, bool force, bool disableWake);
    [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);

    public static void Press(params byte[] keys)
    {
        foreach (var k in keys) keybd_event(k, 0, 0, UIntPtr.Zero);
        foreach (var k in keys.Reverse()) keybd_event(k, 0, 2, UIntPtr.Zero);
    }
}

/// <summary>Índice de aplicaciones instaladas (Win32 y de la Tienda) con Get-StartApps; se abren con shell:AppsFolder.</summary>
static class AppIndex
{
    static List<(string Name, string Id)>? cache;
    static readonly SemaphoreSlim gate = new(1, 1);
    static readonly Dictionary<string, string> alias = new() { ["chrome"] = "google chrome", ["wasap"] = "whatsapp", ["guasap"] = "whatsapp", ["explorador"] = "explorador de archivos", ["calculadora"] = "calculadora" };

    static async Task Load()
    {
        await gate.WaitAsync();
        try
        {
            if (cache is not null) return;
            var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -NonInteractive -Command \"[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-StartApps | ConvertTo-Json -Compress\"")
            { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true, StandardOutputEncoding = Encoding.UTF8 };
            using var p = Process.Start(psi)!;
            var json = await p.StandardOutput.ReadToEndAsync();
            await p.WaitForExitAsync();
            var node = JsonNode.Parse(json);
            var items = node is JsonArray a ? a.OfType<JsonObject>() : node is JsonObject o ? new[] { o } : Array.Empty<JsonObject>();
            cache = items.Select(i => (i["Name"]?.ToString() ?? "", i["AppID"]?.ToString() ?? "")).Where(x => x.Item1.Length > 0 && x.Item2.Length > 0).ToList();
        }
        catch { cache ??= new(); }
        finally { gate.Release(); }
    }

    static int Score(string label, string q) =>
        label == q ? 100 : label.StartsWith(q) ? 80 : label.Contains(q) ? 60 : q.Split(' ').All(label.Contains) ? 40 : 0;

    public static async Task<(string Name, string Id)?> Find(string query)
    {
        await Load();
        var n = Txt.Norm(query); if (alias.TryGetValue(n, out var al)) n = al;
        if (n.Length == 0) return null;
        var best = cache!.Select(a => (App: a, Score: Score(Txt.Norm(a.Name), n))).Where(x => x.Score > 0).OrderByDescending(x => x.Score).ThenBy(x => x.App.Name.Length).FirstOrDefault();
        return best.Score > 0 ? best.App : null;
    }
}

/// <summary>Recordatorios y temporizadores persistentes; se revisan cada 5 s mientras Verónica está residente.</summary>
static class Scheduler
{
    static Timer? timer;
    public static void Add(string text, DateTime at) { Cfg.M.Reminders.Add(new Reminder { Text = text, At = at }); Cfg.M.Save(); }
    public static void Start() => timer = new Timer(_ =>
    {
        var due = Cfg.M.Reminders.Where(r => !r.Done && r.At <= DateTime.Now).ToList();
        foreach (var r in due) { r.Done = true; Hooks.Announce?.Invoke(r.Text); }
        if (due.Count > 0) { Cfg.M.Reminders.RemoveAll(r => r.Done); Cfg.M.Save(); }
    }, null, 5000, 5000);
}

static class WinTools
{
    static string S(JsonObject a, string k) => a[k]?.ToString() ?? "";
    static double D(JsonObject a, string k, double def = 0) => double.TryParse(S(a, k), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : def;
    static string Known(string n) => Txt.Norm(n) switch
    {
        "documentos" => Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
        "descargas" => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"),
        "escritorio" => Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
        "imagenes" => Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
        "musica" => Environment.GetFolderPath(Environment.SpecialFolder.MyMusic),
        "videos" => Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
        _ => "",
    };
    static string Fmt(int s) => s >= 3600 && s % 3600 == 0 ? $"{s / 3600} hora(s)" : s >= 60 && s % 60 == 0 ? $"{s / 60} minuto(s)" : $"{s} segundo(s)";

    public static Dictionary<string, Handler> Build()
    {
        var m = new Dictionary<string, Handler>();
        void H(string n, Handler f) => m[n] = f;
        void HS(string n, Func<JsonObject, string> f) => m[n] = (a, ct) => Task.FromResult(f(a));
        var M = Cfg.M;

        H("open_app", async (a, ct) =>
        {
            var q = S(a, "name"); var app = await AppIndex.Find(q);
            if (app is null) return $"No encontré ningún programa llamado \"{q}\".";
            Process.Start(new ProcessStartInfo("explorer.exe", "shell:AppsFolder\\" + app.Value.Id) { UseShellExecute = true });
            return $"Abriendo {app.Value.Name}.";
        });
        HS("open_folder", a =>
        {
            var path = Known(S(a, "name")); if (path.Length == 0) path = S(a, "name");
            if (!Directory.Exists(path)) return $"No encontré la carpeta \"{S(a, "name")}\".";
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
            return "Abriendo la carpeta.";
        });
        H("find_files", (a, ct) => Task.Run(() =>
        {
            var words = Txt.Norm(S(a, "query")).Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (words.Length == 0) return "¿Qué archivo quieres que busque?";
            var roots = new[] { "documentos", "escritorio", "descargas", "imagenes", "musica", "videos" }.Select(Known).Where(Directory.Exists).Distinct();
            var opt = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, MaxRecursionDepth = 6 };
            var found = new List<string>(); var sw = Stopwatch.StartNew();
            foreach (var r in roots)
            {
                foreach (var f in Directory.EnumerateFiles(r, "*" + words[0] + "*", opt))
                {
                    ct.ThrowIfCancellationRequested();
                    var n = Txt.Norm(Path.GetFileNameWithoutExtension(f));
                    if (words.All(n.Contains)) found.Add(f);
                    if (found.Count >= 10 || sw.Elapsed.TotalSeconds > 8) break;
                }
                if (found.Count >= 10 || sw.Elapsed.TotalSeconds > 8) break;
            }
            if (found.Count == 0) return $"No encontré archivos que coincidan con \"{S(a, "query")}\" en tus carpetas personales.";
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{found[0]}\"") { UseShellExecute = true });
            return $"Encontré {found.Count} archivo(s). El primero es {Path.GetFileName(found[0])}, en {Path.GetFileName(Path.GetDirectoryName(found[0]))}. Lo mostré en el Explorador.";
        }, ct));
        HS("create_folder", a =>
        {
            var name = string.Concat(S(a, "name").Where(c => !Path.GetInvalidFileNameChars().Contains(c))).Trim();
            if (name.Length == 0) return "¿Cómo se llamará la carpeta?";
            var loc = Known(S(a, "location").Length == 0 ? "documentos" : S(a, "location")); if (loc.Length == 0) loc = Known("documentos");
            var path = Path.Combine(loc, name);
            if (Directory.Exists(path)) return $"La carpeta {name} ya existe.";
            Directory.CreateDirectory(path); return $"Listo, creé la carpeta {name}.";
        });
        H("screenshot", async (a, ct) =>
        {
            Hooks.HideOverlay?.Invoke(); await Task.Delay(350, ct);
            try
            {
                var b = System.Windows.Forms.SystemInformation.VirtualScreen;
                using var bmp = new Bitmap(b.Width, b.Height);
                using (var g = Graphics.FromImage(bmp)) g.CopyFromScreen(b.Left, b.Top, 0, 0, b.Size);
                var dir = Path.Combine(Known("imagenes"), "Capturas de Verónica"); Directory.CreateDirectory(dir);
                bmp.Save(Path.Combine(dir, $"Captura_{DateTime.Now:yyyyMMdd_HHmmss}.png"), ImageFormat.Png);
                return "Captura guardada en Imágenes, dentro de Capturas de Verónica.";
            }
            finally { Hooks.ShowOverlay?.Invoke(); }
        });
        HS("power", a =>
        {
            void Sh(string args) => Process.Start(new ProcessStartInfo("shutdown", args) { CreateNoWindow = true, UseShellExecute = false });
            switch (S(a, "action"))
            {
                case "lock": Native.LockWorkStation(); return "Bloqueado.";
                case "sleep": Task.Run(async () => { await Task.Delay(1500); Native.SetSuspendState(false, false, false); }); return "Suspendiendo el equipo.";
                case "restart": Sh("/r /t 15"); return "Reinicio en 15 segundos. Di «cancela el reinicio» para detenerlo.";
                case "shutdown": Sh("/s /t 15"); return "Apagado en 15 segundos. Di «cancela el apagado» para detenerlo.";
                case "cancel": Sh("/a"); return "Cancelado.";
                default: return "Acción de energía no válida.";
            }
        });
        HS("window", a =>
        {
            var w = Native.GetForegroundWindow();
            switch (S(a, "action"))
            {
                case "minimize": Native.ShowWindow(w, 6); break;
                case "maximize": Native.ShowWindow(w, 3); break;
                case "close": Native.PostMessage(w, 0x0010, IntPtr.Zero, IntPtr.Zero); break; // WM_CLOSE: la app puede pedir guardar
                case "switch": Native.Press(0x12, 0x09); break;
                case "desktop": Native.Press(0x5B, 0x44); break;
                default: return "Acción de ventana no válida.";
            }
            return "Hecho.";
        });
        HS("volume", a =>
        {
            using var en = new MMDeviceEnumerator();
            var v = en.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia).AudioEndpointVolume;
            switch (S(a, "action"))
            {
                case "up": v.MasterVolumeLevelScalar = Math.Min(1f, v.MasterVolumeLevelScalar + 0.1f); break;
                case "down": v.MasterVolumeLevelScalar = Math.Max(0f, v.MasterVolumeLevelScalar - 0.1f); break;
                case "mute": v.Mute = true; break;
                case "unmute": v.Mute = false; break;
                case "set": v.MasterVolumeLevelScalar = (float)Math.Clamp(D(a, "level", 50) / 100, 0, 1); break;
                default: return "Acción de volumen no válida.";
            }
            return "Hecho.";
        });
        HS("media", a =>
        {
            // Las teclas multimedia de Windows son un interruptor: play y pause usan la misma.
            Native.Press(S(a, "action") switch { "next" => (byte)0xB0, "previous" => (byte)0xB1, "stop" => (byte)0xB2, _ => (byte)0xB3 });
            return "Hecho.";
        });

        HS("timer", a =>
        {
            var s = (int)D(a, "seconds"); if (s <= 0) return "¿De cuánto tiempo quieres el temporizador?";
            Scheduler.Add($"Tu temporizador de {Fmt(s)} terminó", DateTime.Now.AddSeconds(s)); return $"Temporizador de {Fmt(s)} en marcha.";
        });
        HS("reminder", a =>
        {
            if (S(a, "text").Length == 0) return "¿Qué quieres que te recuerde?";
            var at = S(a, "at").Length > 0 ? DateTime.Parse(S(a, "at")) : DateTime.Now.AddMinutes(D(a, "minutes"));
            if (at <= DateTime.Now.AddSeconds(5)) return "La hora del recordatorio ya pasó o no es válida.";
            Scheduler.Add(S(a, "text"), at); return "Listo, te lo recordaré.";
        });
        HS("notes_add", a => { M.Notes.Add(S(a, "text")); M.Save(); return "Nota guardada."; });
        HS("notes_list", _ => M.Notes.Count == 0 ? "No tienes notas guardadas." : string.Join("\n", M.Notes.TakeLast(10).Reverse().Select(n => "- " + n)));
        HS("tasks_add", a => { M.Tasks.Add(new TaskItem { Text = S(a, "text") }); M.Save(); return "Tarea agregada."; });
        HS("tasks_list", _ => M.Tasks.Any(t => !t.Done) ? string.Join("\n", M.Tasks.Where(t => !t.Done).Select(t => "- " + t.Text)) : "No tienes tareas pendientes.");
        HS("tasks_done", a =>
        {
            var t = M.Tasks.FirstOrDefault(x => !x.Done && Txt.Norm(x.Text).Contains(Txt.Norm(S(a, "text"))));
            if (t is null) return "No encontré esa tarea."; t.Done = true; M.Save(); return "Marcada como hecha.";
        });
        HS("remember", a =>
        {
            if (!Cfg.S.MemoryEnabled || Cfg.S.PrivateMode) return "La memoria está desactivada; el usuario puede activarla en mi configuración.";
            M.Facts[S(a, "key").Trim().ToLowerInvariant()] = S(a, "value").Trim(); M.Save(); return "Guardado.";
        });
        HS("forget", a => { M.Facts.Remove(S(a, "key").Trim().ToLowerInvariant()); M.Save(); return "Olvidado."; });

        H("weather", (a, ct) => Web.Weather(S(a, "city"), ct));
        H("news", (a, ct) => Web.News(S(a, "topic"), ct));
        H("currency", (a, ct) => Web.Currency(D(a, "amount", 1), S(a, "from"), S(a, "to"), ct));
        H("web_search", (a, ct) => Web.Search(S(a, "query"), ct));
        HS("calc", a => Calc.Eval(S(a, "expression")));
        HS("open_url", a =>
        {
            var u = S(a, "url"); if (!u.StartsWith("http")) u = "https://" + u;
            if (!Uri.TryCreate(u, UriKind.Absolute, out var uri) || (uri.Scheme != "http" && uri.Scheme != "https")) return "Solo abro direcciones web.";
            Process.Start(new ProcessStartInfo(uri.ToString()) { UseShellExecute = true }); return "Abriendo la página.";
        });
        HS("set_language", a =>
        {
            try { _ = new System.Globalization.CultureInfo(S(a, "lang")); } catch { return "Código de idioma no válido."; }
            Cfg.S.Language = S(a, "lang"); Cfg.S.Save(); return $"Idioma cambiado a {S(a, "lang")}.";
        });
        return m;
    }
}
