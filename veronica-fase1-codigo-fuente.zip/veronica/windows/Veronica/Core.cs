using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Veronica;

/// <summary>Estado global mínimo.</summary>
static class Cfg
{
    public static readonly string Dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Veronica");
    public static Settings S = Settings.Load();
    public static Store M = Store.Load();
    public static string Of(string name) { Directory.CreateDirectory(Dir); return Path.Combine(Dir, name); }
}

/// <summary>Ajustes. Las claves de API se guardan cifradas con DPAPI (solo este usuario de Windows puede descifrarlas).</summary>
sealed class Settings
{
    public bool ListeningEnabled { get; set; } = true;
    public bool Muted { get; set; }
    public string WakePhrases { get; set; } = "oye verónica,hola verónica,verónica";
    public string Greeting { get; set; } = "voz"; // voz | tono | ninguno
    public int FollowUpMs { get; set; } = 4000;
    public bool BargeIn { get; set; } // Windows no cancela el eco: actívalo solo con audífonos
    public string Language { get; set; } = "es-MX";
    public string LlmProvider { get; set; } = "anthropic";
    public string LlmBaseUrl { get; set; } = "https://api.anthropic.com";
    public string LlmModel { get; set; } = "claude-haiku-5-5";
    public string SttBaseUrl { get; set; } = "https://api.openai.com/v1";
    public string SttModel { get; set; } = "whisper-1";
    public string TtsMode { get; set; } = "system"; // system | cloud
    public string TtsBaseUrl { get; set; } = "https://api.openai.com/v1";
    public string TtsModel { get; set; } = "gpt-4o-mini-tts";
    public string TtsVoice { get; set; } = "nova";
    public string City { get; set; } = "";
    public bool SaveHistory { get; set; } = true;
    public bool MemoryEnabled { get; set; } = true;
    public bool PrivateMode { get; set; }
    public bool OfflineOnly { get; set; }
    public bool AutoStart { get; set; }
    public Dictionary<string, string> Secrets { get; set; } = new();

    [JsonIgnore] public string Lang2 => Language.Split('-')[0].ToLowerInvariant();
    [JsonIgnore] public string[] WakeList => WakePhrases.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
    [JsonIgnore] public string LlmKey { get => Get("llm"); set => Put("llm", value); }
    [JsonIgnore] public string SearchKey { get => Get("search"); set => Put("search", value); }
    [JsonIgnore] public string SttKeyRaw { get => Get("stt"); set => Put("stt", value); }
    [JsonIgnore] public string TtsKeyRaw { get => Get("tts"); set => Put("tts", value); }
    [JsonIgnore] public string SttKey => SttKeyRaw is { Length: > 0 } k ? k : LlmKey;
    [JsonIgnore] public string TtsKey => TtsKeyRaw is { Length: > 0 } k ? k : LlmKey;

    string Get(string n)
    {
        try { return Secrets.TryGetValue(n, out var v) ? Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(v), null, DataProtectionScope.CurrentUser)) : ""; }
        catch { return ""; }
    }
    void Put(string n, string v)
    {
        if (string.IsNullOrWhiteSpace(v)) Secrets.Remove(n);
        else Secrets[n] = Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(v), null, DataProtectionScope.CurrentUser));
    }

    public static Settings Load()
    {
        try { var p = Cfg.Of("settings.json"); if (File.Exists(p)) return JsonSerializer.Deserialize<Settings>(File.ReadAllText(p)) ?? new(); } catch { }
        return new();
    }
    public void Save() => File.WriteAllText(Cfg.Of("settings.json"), JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
}

sealed class TaskItem { public string Text { get; set; } = ""; public bool Done { get; set; } }
sealed class HistItem { public string Role { get; set; } = ""; public string Text { get; set; } = ""; public DateTime At { get; set; } }
sealed class Reminder { public string Id { get; set; } = Guid.NewGuid().ToString("N"); public string Text { get; set; } = ""; public DateTime At { get; set; } public bool Done { get; set; } }

/// <summary>Memoria local cifrada con DPAPI: hechos, notas, tareas, historial y recordatorios.</summary>
sealed class Store
{
    public Dictionary<string, string> Facts { get; set; } = new();
    public List<string> Notes { get; set; } = new();
    public List<TaskItem> Tasks { get; set; } = new();
    public List<HistItem> History { get; set; } = new();
    public List<Reminder> Reminders { get; set; } = new();
    static readonly object L = new();

    public static Store Load()
    {
        try { var p = Cfg.Of("memory.dat"); if (File.Exists(p)) return JsonSerializer.Deserialize<Store>(ProtectedData.Unprotect(File.ReadAllBytes(p), null, DataProtectionScope.CurrentUser)) ?? new(); } catch { }
        return new();
    }
    public void Save() { lock (L) File.WriteAllBytes(Cfg.Of("memory.dat"), ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(this), null, DataProtectionScope.CurrentUser)); }
    public void Log(string role, string text)
    {
        if (!Cfg.S.SaveHistory || Cfg.S.PrivateMode || string.IsNullOrWhiteSpace(text)) return;
        History.Add(new HistItem { Role = role, Text = text, At = DateTime.Now });
        if (History.Count > 300) History.RemoveRange(0, History.Count - 300);
        Save();
    }
    public void WipeAll() { Facts.Clear(); Notes.Clear(); Tasks.Clear(); History.Clear(); Reminders.Clear(); Save(); }
}

static class Txt
{
    public static string Norm(string s)
    {
        var sb = new StringBuilder();
        foreach (var c in s.ToLowerInvariant().Normalize(NormalizationForm.FormD))
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(char.IsLetterOrDigit(c) ? c : ' ');
        }
        return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
    }
    public static string ForSpeech(string s) => Regex.Replace(Regex.Replace(Regex.Replace(s, @"https?://\S+", ""), @"[*_#`>~]", ""), @"\s+", " ").Trim();
    public static string Fmt(double v) => Math.Round(v, 6).ToString("0.######", CultureInfo.InvariantCulture);
}

static class Net
{
    public static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(45) };
    public static bool Online => System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable();
    public static async Task<byte[]> Bytes(HttpRequestMessage req, CancellationToken ct)
    {
        using var r = await Http.SendAsync(req, ct);
        var b = await r.Content.ReadAsByteArrayAsync(ct);
        if (!r.IsSuccessStatusCode) { var t = Encoding.UTF8.GetString(b); throw new HttpRequestException($"HTTP {(int)r.StatusCode}: {(t.Length > 200 ? t[..200] : t)}"); }
        return b;
    }
    public static async Task<string> Text(HttpRequestMessage req, CancellationToken ct) => Encoding.UTF8.GetString(await Bytes(req, ct));
    public static Task<string> Get(string url, CancellationToken ct)
    {
        var r = new HttpRequestMessage(HttpMethod.Get, url); r.Headers.UserAgent.ParseAdd("Veronica/0.1");
        return Text(r, ct);
    }
    public static StringContent Json(JsonNode n) => new(n.ToJsonString(), Encoding.UTF8, "application/json");
}

// ───────────── Proveedores de IA (intercambiables) ─────────────
sealed record Msg(string Role, string Content);

interface ILlm { Task<string> Chat(string system, List<Msg> msgs, CancellationToken ct); }

static class LlmUtil
{
    public static List<Msg> Merge(IEnumerable<Msg> msgs)
    {
        var o = new List<Msg>();
        foreach (var m in msgs) if (o.Count > 0 && o[^1].Role == m.Role) o[^1] = new Msg(m.Role, o[^1].Content + "\n" + m.Content); else o.Add(m);
        return o;
    }
}

/// <summary>OpenAI, Groq, Gemini (endpoint compatible), OpenRouter, Ollama, LM Studio...</summary>
sealed class OpenAiCompatLlm(string baseUrl, string key, string model) : ILlm
{
    public async Task<string> Chat(string system, List<Msg> msgs, CancellationToken ct)
    {
        var arr = new JsonArray { new JsonObject { ["role"] = "system", ["content"] = system } };
        foreach (var m in LlmUtil.Merge(msgs)) arr.Add(new JsonObject { ["role"] = m.Role, ["content"] = m.Content });
        var body = new JsonObject { ["model"] = model, ["messages"] = arr, ["temperature"] = 0.5, ["max_tokens"] = 700 };
        var req = new HttpRequestMessage(HttpMethod.Post, baseUrl.TrimEnd('/') + "/chat/completions") { Content = Net.Json(body) };
        if (key.Length > 0) req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", key);
        return JsonNode.Parse(await Net.Text(req, ct))!["choices"]![0]!["message"]!["content"]!.GetValue<string>();
    }
}

sealed class AnthropicLlm(string baseUrl, string key, string model) : ILlm
{
    public async Task<string> Chat(string system, List<Msg> msgs, CancellationToken ct)
    {
        var arr = new JsonArray();
        foreach (var m in LlmUtil.Merge(msgs)) arr.Add(new JsonObject { ["role"] = m.Role, ["content"] = m.Content });
        var body = new JsonObject { ["model"] = model, ["max_tokens"] = 700, ["system"] = system, ["messages"] = arr };
        var req = new HttpRequestMessage(HttpMethod.Post, baseUrl.TrimEnd('/') + "/v1/messages") { Content = Net.Json(body) };
        req.Headers.Add("x-api-key", key); req.Headers.Add("anthropic-version", "2023-06-01");
        var content = JsonNode.Parse(await Net.Text(req, ct))!["content"]!.AsArray();
        return string.Concat(content.Select(c => c?["text"]?.GetValue<string>() ?? ""));
    }
}

static class Llms
{
    public static ILlm Current() => Cfg.S.LlmProvider == "anthropic"
        ? new AnthropicLlm(Cfg.S.LlmBaseUrl, Cfg.S.LlmKey, Cfg.S.LlmModel)
        : new OpenAiCompatLlm(Cfg.S.LlmBaseUrl, Cfg.S.LlmKey, Cfg.S.LlmModel);
}

// ───────────── Calculadora ─────────────
static class Calc
{
    public static string Eval(string src)
    {
        var p = new P(src.ToLowerInvariant().Replace(',', '.').Replace('×', '*').Replace('÷', '/').Replace('−', '-'));
        var v = p.Run();
        if (double.IsNaN(v) || double.IsInfinity(v)) throw new InvalidOperationException("Resultado no válido");
        return Txt.Fmt(v);
    }
    sealed class P(string s)
    {
        int i;
        public double Run() { var v = Expr(); Skip(); if (i < s.Length) throw new FormatException("Expresión no válida"); return v; }
        void Skip() { while (i < s.Length && s[i] == ' ') i++; }
        bool Eat(char c) { Skip(); if (i < s.Length && s[i] == c) { i++; return true; } return false; }
        double Expr() { var v = Term(); while (true) { if (Eat('+')) v += Term(); else if (Eat('-')) v -= Term(); else return v; } }
        double Term() { var v = Pow(); while (true) { if (Eat('*')) v *= Pow(); else if (Eat('/')) v /= Pow(); else if (Eat('%')) v %= Pow(); else return v; } }
        double Pow() { var b = Unary(); return Eat('^') ? Math.Pow(b, Pow()) : b; }
        double Unary() => Eat('-') ? -Unary() : Eat('+') ? Unary() : Atom();
        double Atom()
        {
            Skip();
            if (Eat('(')) { var v = Expr(); if (!Eat(')')) throw new FormatException("Falta cerrar paréntesis"); return v; }
            int st = i;
            if (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.')) { while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.')) i++; return double.Parse(s[st..i], CultureInfo.InvariantCulture); }
            while (i < s.Length && char.IsLetter(s[i])) i++;
            var n = s[st..i];
            if (n == "pi") return Math.PI; if (n == "e") return Math.E;
            if (n.Length == 0 || !Eat('(')) throw new FormatException("Expresión no válida");
            var a = Expr(); Eat(')');
            return n switch
            {
                "sqrt" or "raiz" => Math.Sqrt(a), "sin" => Math.Sin(a * Math.PI / 180), "cos" => Math.Cos(a * Math.PI / 180), "tan" => Math.Tan(a * Math.PI / 180),
                "log" => Math.Log10(a), "ln" => Math.Log(a), "abs" => Math.Abs(a), "round" => Math.Round(a), "floor" => Math.Floor(a), "ceil" => Math.Ceiling(a),
                _ => throw new FormatException("Función desconocida: " + n),
            };
        }
    }
}

// ───────────── Datos en vivo (sin clave salvo Tavily) ─────────────
static class Web
{
    static string Wmo(int c) => c switch
    {
        0 => "despejado", 1 => "mayormente despejado", 2 => "parcialmente nublado", 3 => "nublado", 45 or 48 => "con niebla",
        51 or 53 or 55 => "con llovizna", 56 or 57 or 66 or 67 => "con lluvia helada", 61 => "con lluvia ligera", 63 => "con lluvia", 65 => "con lluvia fuerte",
        71 or 73 or 75 or 77 or 85 or 86 => "con nieve", 80 or 81 or 82 => "con chubascos", 95 => "con tormenta", 96 or 99 => "con tormenta y granizo", _ => "variable",
    };

    public static async Task<string> Weather(string cityArg, CancellationToken ct)
    {
        var city = string.IsNullOrWhiteSpace(cityArg) ? Cfg.S.City : cityArg;
        if (string.IsNullOrWhiteSpace(city)) return "Falta la ciudad. Pregunta al usuario de qué ciudad quiere el clima.";
        var g = JsonNode.Parse(await Net.Get($"https://geocoding-api.open-meteo.com/v1/search?name={Uri.EscapeDataString(city.Split(',')[0])}&count=1&language=es", ct))!["results"]?[0];
        if (g is null) return $"No encontré la ciudad \"{city}\".";
        var inv = CultureInfo.InvariantCulture;
        var url = $"https://api.open-meteo.com/v1/forecast?latitude={g["latitude"]!.GetValue<double>().ToString(inv)}&longitude={g["longitude"]!.GetValue<double>().ToString(inv)}" +
                  "&current=temperature_2m,apparent_temperature,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=3";
        var j = JsonNode.Parse(await Net.Get(url, ct))!; var cur = j["current"]!; var d = j["daily"]!;
        string Day(int i, string l) => $"{l}: {Wmo(d["weather_code"]![i]!.GetValue<int>())}, máxima {(int)d["temperature_2m_max"]![i]!.GetValue<double>()}°, mínima {(int)d["temperature_2m_min"]![i]!.GetValue<double>()}°, probabilidad de lluvia {d["precipitation_probability_max"]![i]?.GetValue<int>() ?? 0}%.";
        return $"Clima en {g["name"]}: ahora {(int)cur["temperature_2m"]!.GetValue<double>()}°, {Wmo(cur["weather_code"]!.GetValue<int>())}, sensación de {(int)cur["apparent_temperature"]!.GetValue<double>()}°. {Day(0, "Hoy")} {Day(1, "Mañana")} {Day(2, "Pasado mañana")}";
    }

    public static async Task<string> News(string topic, CancellationToken ct)
    {
        var b = string.IsNullOrWhiteSpace(topic) ? "https://news.google.com/rss?" : $"https://news.google.com/rss/search?q={Uri.EscapeDataString(topic)}&";
        var xml = await Net.Get(b + "hl=es-419&gl=MX&ceid=MX:es-419", ct);
        var t = Regex.Matches(xml, "<item>.*?<title>(.*?)</title>", RegexOptions.Singleline).Select(m => System.Net.WebUtility.HtmlDecode(m.Groups[1].Value.Replace("<![CDATA[", "").Replace("]]>", ""))).Take(5).ToList();
        return t.Count == 0 ? "No encontré titulares." : string.Join("\n", t.Select((x, i) => $"{i + 1}. {x}"));
    }

    public static async Task<string> Currency(double amount, string from, string to, CancellationToken ct)
    {
        from = from.ToUpperInvariant().Trim(); to = to.ToUpperInvariant().Trim();
        var j = JsonNode.Parse(await Net.Get($"https://api.frankfurter.dev/v1/latest?base={from}&symbols={to}", ct))!;
        var r = j["rates"]?[to]?.GetValue<double>();
        if (r is null) return $"No tengo el tipo de cambio de {from} a {to}.";
        return $"{amount:N2} {from} equivalen a {amount * r.Value:N2} {to} (cambio del {j["date"]}, datos del Banco Central Europeo).";
    }

    public static async Task<string> Search(string q, CancellationToken ct)
    {
        if (Cfg.S.SearchKey.Length > 0)
        {
            var req = new HttpRequestMessage(HttpMethod.Post, "https://api.tavily.com/search") { Content = Net.Json(new JsonObject { ["query"] = q, ["max_results"] = 4, ["include_answer"] = true }) };
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Cfg.S.SearchKey);
            var r = JsonNode.Parse(await Net.Text(req, ct))!;
            var lines = (r["results"]?.AsArray() ?? new JsonArray()).Select(o => $"{o!["title"]}: {Trunc(o["content"]?.ToString() ?? "", 260)}");
            var ans = r["answer"]?.ToString();
            return (string.IsNullOrWhiteSpace(ans) ? "" : $"Resumen: {ans}\n") + string.Join("\n", lines);
        }
        var w = JsonNode.Parse(await Net.Get($"https://es.wikipedia.org/w/api.php?action=query&list=search&srsearch={Uri.EscapeDataString(q)}&format=json&srlimit=3&utf8=1", ct))!["query"]!["search"]!.AsArray();
        if (w.Count == 0) return "No encontré resultados. Configura una clave de búsqueda web (Tavily) para resultados más amplios.";
        return string.Join("\n", w.Select(o => $"{o!["title"]}: {Regex.Replace(o["snippet"]!.ToString(), "<[^>]+>", "")}")) + "\n(Fuente: Wikipedia; para búsqueda general configura Tavily.)";
    }
    static string Trunc(string s, int n) => s.Length <= n ? s : s[..n];
}
