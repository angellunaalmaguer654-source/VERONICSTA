using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Veronica;

enum OrbState { Off, Idle, Listening, Thinking, Speaking, Executing, Error }

/// <summary>
/// El símbolo de Verónica (mismo diseño que en Android): núcleo perlado con tres velos de luz (ámbar, magenta, índigo).
/// Cada estado cambia el movimiento: respira, late con el micrófono, gira con un arco de energía, dibuja un anillo ondulado
/// al hablar, orbita un arco dorado al ejecutar, vira a rojo en error y se apaga cuando está desactivada.
/// Solo se anima mientras la ventana está visible (consumo ≈ 0 en espera).
/// </summary>
sealed class OrbControl : FrameworkElement
{
    public OrbState State { get; set; } = OrbState.Idle;
    public volatile float Level;

    static readonly Color Amber = Color.FromRgb(255, 179, 71), Magenta = Color.FromRgb(224, 64, 154), Indigo = Color.FromRgb(91, 75, 255),
        Pearl = Color.FromRgb(255, 244, 230), Red = Color.FromRgb(255, 59, 78), Gold = Color.FromRgb(255, 214, 102), Grey = Color.FromRgb(120, 118, 135);
    readonly Stopwatch clock = Stopwatch.StartNew();
    float smooth, mix; bool running;

    public void Run(bool on)
    {
        if (on && !running) { CompositionTarget.Rendering += Tick; running = true; }
        else if (!on && running) { CompositionTarget.Rendering -= Tick; running = false; }
    }
    void Tick(object? s, EventArgs e) => InvalidateVisual();

    static Color Lerp(Color a, Color b, float t) => Color.FromRgb((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));
    static Brush Glow(Color c, double alpha)
    {
        byte a = (byte)(Math.Clamp(alpha, 0, 1) * 255);
        var b = new RadialGradientBrush(new GradientStopCollection {
            new(Color.FromArgb(a, c.R, c.G, c.B), 0), new(Color.FromArgb((byte)(a * 0.6), c.R, c.G, c.B), 0.5), new(Color.FromArgb(0, c.R, c.G, c.B), 1) });
        b.Freeze(); return b;
    }
    static Pen P(Color c, double alpha, double w) { var p = new Pen(new SolidColorBrush(Color.FromArgb((byte)(Math.Clamp(alpha, 0, 1) * 255), c.R, c.G, c.B)), w) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }; p.Freeze(); return p; }

    protected override void OnRender(DrawingContext dc)
    {
        float t = (float)clock.Elapsed.TotalSeconds;
        double cx = ActualWidth / 2, cy = ActualHeight / 2, R = ActualWidth * 0.2;
        var s = State; bool off = s == OrbState.Off;

        float target = s switch
        {
            OrbState.Listening => Math.Clamp(Level, 0, 1),
            OrbState.Speaking => 0.35f + 0.3f * Math.Abs(MathF.Sin(t * 7f)) * (0.6f + 0.4f * MathF.Sin(t * 2.3f)),
            OrbState.Thinking => 0.4f, OrbState.Executing => 0.45f, OrbState.Error => 0.6f,
            OrbState.Idle => 0.12f + 0.06f * MathF.Sin(t * 1.6f), _ => 0f,
        };
        smooth += (target - smooth) * 0.18f;
        float speed = s switch { OrbState.Thinking => 2.4f, OrbState.Executing => 3.2f, OrbState.Listening => 1f + smooth * 2f, OrbState.Speaking => 1.5f, OrbState.Error => 0.4f, _ => 0.5f };
        bool special = s is OrbState.Error or OrbState.Off or OrbState.Executing;
        mix += ((special ? 1f : 0f) - mix) * 0.12f;
        var alt = s switch { OrbState.Error => Red, OrbState.Off => Grey, OrbState.Executing => Gold, _ => Amber };
        var cols = new[] { Lerp(Amber, alt, mix), Lerp(Magenta, alt, mix), Lerp(Indigo, s == OrbState.Error ? Red : alt, mix) };

        double shake = s == OrbState.Error ? MathF.Sin(t * 45f) * 2 : 0;
        var c = new Point(cx + shake, cy);

        dc.DrawEllipse(Glow(Color.FromRgb(255, 190, 140), off ? 0.07 : 0.24), null, c, R * 2.1, R * 2.1);

        double orbit = R * (0.16 + 0.14 * smooth);
        for (int i = 0; i < 3; i++)
        {
            double a = t * speed * (1 + i * 0.35) * (i == 1 ? -1 : 1) + i * 2.094;
            double r = R * (0.80 + 0.20 * smooth + 0.05 * Math.Sin(t * 1.3 + i));
            dc.DrawEllipse(Glow(cols[i], off ? 0.18 : 0.7), null, new Point(c.X + Math.Cos(a) * orbit, c.Y + Math.Sin(a) * orbit), r * 1.5, r * 1.5);
        }
        dc.DrawEllipse(Glow(off ? Grey : Pearl, off ? 0.3 : 0.95), null, c, R * (0.62 + 0.22 * smooth) * 1.5, R * (0.62 + 0.22 * smooth) * 1.5);

        switch (s)
        {
            case OrbState.Listening:
                for (int k = 0; k < 2; k++)
                {
                    float ph = (t * 0.9f + k * 0.5f) % 1f;
                    dc.DrawEllipse(null, P(Pearl, (1 - ph) * (0.43 + 0.47 * smooth), 2.5), c, R * (1.15 + 0.95 * ph + 0.2 * smooth), R * (1.15 + 0.95 * ph + 0.2 * smooth));
                }
                break;
            case OrbState.Speaking:
                var pts = new List<Point>();
                for (int i = 0; i <= 96; i++)
                {
                    double th = i / 96.0 * Math.PI * 2;
                    double w = (Math.Sin(3 * th + t * 6) + 0.6 * Math.Sin(5 * th - t * 4.3) + 0.4 * Math.Sin(7 * th + t * 9)) / 2;
                    double rr = R * 1.25 + R * 0.3 * smooth * w;
                    pts.Add(new Point(c.X + Math.Cos(th) * rr, c.Y + Math.Sin(th) * rr));
                }
                var g = new StreamGeometry();
                using (var gc = g.Open()) { gc.BeginFigure(pts[0], false, true); gc.PolyLineTo(pts.Skip(1).ToList(), true, true); }
                g.Freeze();
                dc.DrawGeometry(null, P(Color.FromRgb(255, 214, 160), 0.22, 7), g);
                dc.DrawGeometry(null, P(Pearl, 0.9, 2.2), g);
                break;
            case OrbState.Thinking:
            case OrbState.Executing:
                double a0 = t * speed * 140 % 360; double rad = R * 1.3;
                var pen = P(s == OrbState.Executing ? Gold : Pearl, 0.9, 2.5);
                Arc(dc, pen, c, rad, a0, s == OrbState.Executing ? 110 : 80); Arc(dc, pen, c, rad, a0 + 180, 50);
                break;
            case OrbState.Error: dc.DrawEllipse(null, P(Red, 0.8, 2.5), c, R * 1.3, R * 1.3); break;
            case OrbState.Off: dc.DrawEllipse(null, P(Grey, 0.45, 1.5), c, R * 1.1, R * 1.1); break;
        }
    }

    static void Arc(DrawingContext dc, Pen pen, Point c, double r, double startDeg, double sweepDeg)
    {
        Point At(double d) => new(c.X + Math.Cos(d * Math.PI / 180) * r, c.Y + Math.Sin(d * Math.PI / 180) * r);
        var g = new StreamGeometry();
        using (var gc = g.Open()) { gc.BeginFigure(At(startDeg), false, false); gc.ArcTo(At(startDeg + sweepDeg), new Size(r, r), 0, sweepDeg > 180, SweepDirection.Clockwise, true, false); }
        g.Freeze(); dc.DrawGeometry(null, pen, g);
    }
}

/// <summary>Ventana flotante transparente, sin marco, siempre al frente, que no roba el foco ni bloquea clics.</summary>
sealed class OverlayWindow : Window
{
    public readonly OrbControl Orb = new();
    readonly ScaleTransform scale = new(1, 1);
    HwndSource? src; IntPtr hwnd;
    public event Action? Hotkey;
    bool shown;

    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr h, int i, int v);
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);

    public OverlayWindow()
    {
        WindowStyle = WindowStyle.None; AllowsTransparency = true; Background = Brushes.Transparent; ShowInTaskbar = false;
        Topmost = true; ResizeMode = ResizeMode.NoResize; ShowActivated = false; Focusable = false;
        Width = Height = 200; Content = Orb; Orb.RenderTransform = scale; Orb.RenderTransformOrigin = new Point(0.5, 0.5);
        var wa = SystemParameters.WorkArea; Left = wa.Left + (wa.Width - Width) / 2; Top = wa.Bottom - Height - 6;
    }

    /// <summary>Crea el HWND sin mostrar la ventana: aplica estilos de no-foco/clic-a-través y registra Ctrl+Alt+V.</summary>
    public void Init()
    {
        hwnd = new WindowInteropHelper(this).EnsureHandle();
        SetWindowLong(hwnd, -20, GetWindowLong(hwnd, -20) | 0x80 /*TOOLWINDOW*/ | 0x08000000 /*NOACTIVATE*/ | 0x20 /*TRANSPARENT*/);
        src = HwndSource.FromHwnd(hwnd);
        src.AddHook((IntPtr h, int msg, IntPtr w, IntPtr l, ref bool handled) => { if (msg == 0x0312) { Hotkey?.Invoke(); handled = true; } return IntPtr.Zero; });
        RegisterHotKey(hwnd, 1, 0x0003 /*CTRL+ALT*/, 0x56 /*V*/);
    }

    public void ShowOrb()
    {
        if (shown) return; shown = true;
        if (!IsVisible) { Opacity = 0; Show(); }
        Orb.Run(true);
        BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(280)));
        var grow = new DoubleAnimation(0.55, 1, TimeSpan.FromMilliseconds(360)) { EasingFunction = new BackEase { Amplitude = 0.6, EasingMode = EasingMode.EaseOut } };
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, grow); scale.BeginAnimation(ScaleTransform.ScaleYProperty, grow);
    }

    public void HideOrb(bool animate = true)
    {
        if (!shown) return; shown = false;
        if (!animate) { Orb.Run(false); Hide(); return; }
        var fade = new DoubleAnimation(0, TimeSpan.FromMilliseconds(240));
        fade.Completed += (_, _) => { if (!shown) { Orb.Run(false); Hide(); } };
        BeginAnimation(OpacityProperty, fade);
    }

    protected override void OnClosed(EventArgs e) { if (hwnd != IntPtr.Zero) UnregisterHotKey(hwnd, 1); base.OnClosed(e); }
}

/// <summary>Configuración completa. Nunca hace falta abrirla para hablar con Verónica.</summary>
sealed class SettingsWindow : Window
{
    static readonly Brush Bg = new SolidColorBrush(Color.FromRgb(0x0E, 0x0B, 0x16)), PanelBg = new SolidColorBrush(Color.FromRgb(0x24, 0x1E, 0x33)),
        Fg = new SolidColorBrush(Color.FromRgb(0xFF, 0xF4, 0xE6)), Accent = new SolidColorBrush(Color.FromRgb(0xFF, 0xB3, 0x47));
    readonly ModelManager models; readonly Conductor conductor;

    public SettingsWindow(ModelManager models, Conductor conductor)
    {
        this.models = models; this.conductor = conductor;
        Title = "Verónica — Configuración"; Width = 580; Height = 700; Background = Bg; Foreground = Fg; WindowStartupLocation = WindowStartupLocation.CenterScreen;
        var tabs = new TabControl { Background = Bg, Margin = new Thickness(8) };
        tabs.Items.Add(Tab("Estado", StatusTab)); tabs.Items.Add(Tab("Inteligencia", AiTab)); tabs.Items.Add(Tab("Voz", VoiceTab));
        tabs.Items.Add(Tab("Memoria", MemoryTab)); tabs.Items.Add(Tab("Privacidad", PrivacyTab));
        Content = tabs;
        Closing += (_, e) => { e.Cancel = true; Cfg.S.Save(); Hide(); }; // vive en la bandeja; se cierra desde su menú
    }

    static TabItem Tab(string title, Action<StackPanel> fill)
    {
        var p = new StackPanel { Margin = new Thickness(12) }; fill(p);
        return new TabItem { Header = title, Content = new ScrollViewer { Content = p, VerticalScrollBarVisibility = ScrollBarVisibility.Auto } };
    }
    static TextBlock Label(StackPanel p, string t, bool small = false) { var l = new TextBlock { Text = t, Foreground = small ? Brushes.Gray : Fg, Margin = new Thickness(0, 10, 0, 3), TextWrapping = TextWrapping.Wrap, FontSize = small ? 11 : 13 }; p.Children.Add(l); return l; }
    static void Text(StackPanel p, string label, string val, Action<string> set)
    {
        Label(p, label); var b = new TextBox { Text = val, Background = PanelBg, Foreground = Fg, CaretBrush = Fg, Padding = new Thickness(6) };
        b.TextChanged += (_, _) => set(b.Text); p.Children.Add(b);
    }
    static void Secret(StackPanel p, string label, string val, Action<string> set)
    {
        Label(p, label + " (se guarda cifrada)"); var b = new PasswordBox { Password = val, Background = PanelBg, Foreground = Fg, Padding = new Thickness(6) };
        b.PasswordChanged += (_, _) => set(b.Password); p.Children.Add(b);
    }
    static void Check(StackPanel p, string text, bool val, Action<bool> set)
    {
        var c = new CheckBox { Content = text, IsChecked = val, Foreground = Fg, Margin = new Thickness(0, 10, 0, 0) };
        c.Click += (_, _) => set(c.IsChecked == true); p.Children.Add(c);
    }
    static void Choice(StackPanel p, string label, string[] items, string val, Action<string> set)
    {
        Label(p, label); var c = new ComboBox { ItemsSource = items, SelectedItem = val };
        c.SelectionChanged += (_, _) => { if (c.SelectedItem is string s) set(s); }; p.Children.Add(c);
    }
    static Button Btn(StackPanel p, string text, Action click)
    {
        var b = new Button { Content = text, Margin = new Thickness(0, 10, 0, 0), Padding = new Thickness(10, 6, 10, 6), HorizontalAlignment = HorizontalAlignment.Left };
        b.Click += (_, _) => click(); p.Children.Add(b); return b;
    }

    void StatusTab(StackPanel p)
    {
        var s = Cfg.S;
        Label(p, "Di «Oye Verónica» desde cualquier programa, o usa Ctrl + Alt + V. Verás el icono de micrófono de Windows mientras escucha.");
        var state = Label(p, models.Installed ? "✓ Modelo de voz local instalado." : "○ Falta el modelo de voz local (40 MB).");
        var bar = new ProgressBar { Height = 8, Margin = new Thickness(0, 6, 0, 0), Visibility = Visibility.Collapsed }; p.Children.Add(bar);
        Btn(p, "Descargar modelo de voz", async () =>
        {
            bar.Visibility = Visibility.Visible;
            try { await models.Download(new Progress<int>(v => bar.Value = v), CancellationToken.None); state.Text = "✓ Modelo instalado."; conductor.Restart(); }
            catch (Exception e) { state.Text = "Error de descarga: " + e.Message; }
        });
        Check(p, "Micrófono en pausa", s.Muted, m => conductor.SetMuted(m));
        Check(p, "Iniciar con Windows", s.AutoStart, v => { s.AutoStart = v; Autostart.Set(v); });
        Text(p, "Palabras de activación (separadas por comas)", s.WakePhrases, v => s.WakePhrases = v);
        Label(p, "Los cambios de palabra se aplican al reiniciar la escucha.", true);
        Btn(p, "Reiniciar escucha", () => { s.Save(); conductor.Restart(); });
        Btn(p, "Activar ahora", () => conductor.OnWake());
        Choice(p, "Al despertar", ["voz", "tono", "ninguno"], s.Greeting, v => s.Greeting = v);
        Text(p, "Idioma (es-MX, en-US, fr-FR…)", s.Language, v => s.Language = v);
    }

    void AiTab(StackPanel p)
    {
        var s = Cfg.S;
        Choice(p, "Proveedor", ["anthropic", "openai"], s.LlmProvider, v => s.LlmProvider = v);
        Label(p, "«openai» sirve para cualquier API compatible: OpenAI, Groq, Gemini, OpenRouter, Ollama…", true);
        Text(p, "URL base", s.LlmBaseUrl, v => s.LlmBaseUrl = v); Text(p, "Modelo", s.LlmModel, v => s.LlmModel = v);
        Secret(p, "Clave de API", s.LlmKey, v => s.LlmKey = v);
        Label(p, "Voz a texto en la nube");
        Text(p, "URL base", s.SttBaseUrl, v => s.SttBaseUrl = v); Text(p, "Modelo", s.SttModel, v => s.SttModel = v);
        Secret(p, "Clave (vacía = la misma del modelo)", s.SttKeyRaw, v => s.SttKeyRaw = v);
        Label(p, "Búsqueda web y ciudad");
        Secret(p, "Clave de Tavily (opcional)", s.SearchKey, v => s.SearchKey = v);
        Text(p, "Ciudad para el clima", s.City, v => s.City = v);
    }

    void VoiceTab(StackPanel p)
    {
        var s = Cfg.S;
        Choice(p, "Voz", ["system", "cloud"], s.TtsMode, v => s.TtsMode = v);
        Label(p, "system = voz de Windows (gratis, sin Internet). cloud = voz neuronal más natural (requiere clave).", true);
        Text(p, "Voz en la nube (p. ej. nova, coral)", s.TtsVoice, v => s.TtsVoice = v);
        Text(p, "Modelo de voz en la nube", s.TtsModel, v => s.TtsModel = v);
        Text(p, "URL base de voz", s.TtsBaseUrl, v => s.TtsBaseUrl = v);
        Secret(p, "Clave de voz (vacía = la misma del modelo)", s.TtsKeyRaw, v => s.TtsKeyRaw = v);
        Check(p, "Poder interrumpirla diciendo su nombre (solo con audífonos)", s.BargeIn, v => s.BargeIn = v);
    }

    void MemoryTab(StackPanel p)
    {
        var s = Cfg.S; var m = Cfg.M;
        Check(p, "Recordar datos sobre mí (se guardan cifrados en este equipo)", s.MemoryEnabled, v => s.MemoryEnabled = v);
        Label(p, "Lo que sé de ti");
        var facts = new ListBox { Height = 140, Background = PanelBg, Foreground = Fg }; p.Children.Add(facts);
        void Refresh() => facts.ItemsSource = m.Facts.Select(f => $"{f.Key}: {f.Value}").ToList();
        Refresh();
        Btn(p, "Borrar el dato seleccionado", () => { if (facts.SelectedItem is string t) { m.Facts.Remove(t.Split(':')[0]); m.Save(); Refresh(); } });
        Btn(p, "Borrar toda la memoria, notas y tareas", () => { m.WipeAll(); Refresh(); });
        Label(p, "Historial reciente");
        var hist = new ListBox { Height = 160, Background = PanelBg, Foreground = Fg }; p.Children.Add(hist);
        void RefreshH() => hist.ItemsSource = m.History.TakeLast(20).Reverse().Select(h => (h.Role == "user" ? "Tú: " : "Verónica: ") + h.Text).ToList();
        RefreshH();
        Btn(p, "Borrar historial", () => { m.History.Clear(); m.Save(); RefreshH(); });
    }

    void PrivacyTab(StackPanel p)
    {
        var s = Cfg.S;
        Check(p, "Guardar historial de conversaciones", s.SaveHistory, v => s.SaveHistory = v);
        Check(p, "Modo privado (sin historial ni memoria)", s.PrivateMode, v => s.PrivateMode = v);
        Check(p, "Solo en el equipo (sin Internet: voz local y comandos básicos)", s.OfflineOnly, v => s.OfflineOnly = v);
        Label(p, "El audio nunca se guarda. Con la voz en la nube, solo la frase que dices tras despertar a Verónica se envía al proveedor que configuraste. Las claves se cifran con tu cuenta de Windows.", true);
    }
}
