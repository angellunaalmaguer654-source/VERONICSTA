using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Veronica;

/// <summary>
/// Orquesta el ciclo completo: espera → palabra de activación → símbolo → escucha → transcribe →
/// piensa/ejecuta → habla → (seguimiento) → espera. Una sesión a la vez; una nueva activación interrumpe la anterior.
/// </summary>
sealed class Conductor : IAgentIO
{
    readonly ModelManager models;
    readonly AudioEngine audio;
    readonly SpeakerHub speaker = new();
    readonly OverlayWindow overlay;
    readonly Agent agent;
    readonly object gate = new();
    CancellationTokenSource? cts, hideCts;
    Task session = Task.CompletedTask;

    public event Action<string>? Notice;
    public OrbState State { get; private set; } = OrbState.Off;
    bool Busy => !session.IsCompleted;

    public Conductor(ModelManager models, OverlayWindow overlay)
    {
        this.models = models; this.overlay = overlay;
        audio = new AudioEngine(models);
        agent = new Agent(new ToolRegistry(WinTools.Build()));
        audio.OnLevel = l => overlay.Orb.Level = l;
        audio.OnFail = msg => { SetState(OrbState.Error); Notice?.Invoke(msg); };
        overlay.Hotkey += OnWake;
        Hooks.HideOverlay = () => Ui(() => overlay.HideOrb(false));
        Hooks.ShowOverlay = () => Ui(overlay.ShowOrb);
        Hooks.Announce = Announce;
    }

    static void Ui(Action a) => Application.Current.Dispatcher.BeginInvoke(a);

    void SetState(OrbState s)
    {
        State = s;
        Ui(() => { overlay.Orb.State = s; if (s is not (OrbState.Idle or OrbState.Off) || Busy) overlay.ShowOrb(); });
    }

    public void Start()
    {
        if (Cfg.S.Muted) { SetState(OrbState.Off); return; }
        if (!models.Installed) { SetState(OrbState.Error); Notice?.Invoke("Falta descargar el modelo de voz. Abre la configuración y pulsa «Descargar modelo de voz»."); return; }
        audio.Start(Cfg.S.WakeList, OnWake);
        SetState(OrbState.Idle);
    }

    public void Restart() { audio.Stop(); Start(); }

    public void SetMuted(bool m)
    {
        Cfg.S.Muted = m; Cfg.S.Save();
        if (m)
        {
            cts?.Cancel(); speaker.Stop(); audio.Stop(); SetState(OrbState.Off);
            ScheduleHide(1600);
        }
        else Start();
    }

    public void OnWake()
    {
        if (Cfg.S.Muted || !audio.Running) return;
        if (!Cfg.S.BargeIn && Busy) return;
        lock (gate)
        {
            var oldCts = cts; var oldTask = session;
            var mine = new CancellationTokenSource(); cts = mine;
            session = Task.Run(async () =>
            {
                oldCts?.Cancel(); speaker.Stop();
                try { await oldTask; } catch { }
                try { await RunSession(mine.Token); }
                catch (OperationCanceledException) { }
                catch (Exception)
                {
                    SetState(OrbState.Error);
                    try { await speaker.Speak("Tuve un problema. Intenta de nuevo.", CancellationToken.None); } catch { }
                    await Task.Delay(800);
                }
                finally { Finish(mine); }
            });
        }
    }

    async Task RunSession(CancellationToken ct)
    {
        hideCts?.Cancel();
        SetState(OrbState.Listening);
        await Greet(ct);
        int window = 8000;
        while (true)
        {
            SetState(OrbState.Listening);
            var pcm = await audio.CaptureUtterance(window, ct); if (pcm is null) break;
            SetState(OrbState.Thinking);
            var text = await Stt.Transcribe(pcm, models, ct); // el audio solo vive en memoria
            if (string.IsNullOrWhiteSpace(text)) break;
            await agent.Handle(text, this, ct);
            window = agent.FollowUp switch { "close" => 0, "ask" => 9000, _ => Cfg.S.FollowUpMs };
            if (window <= 0) break;
        }
    }

    async Task Greet(CancellationToken ct)
    {
        switch (Cfg.S.Greeting)
        {
            case "voz":
                SetState(OrbState.Speaking);
                Cfg.M.Facts.TryGetValue("nombre", out var name);
                string[] es = ["Aquí estoy, ¿qué necesitas?", "Dime.", "¿Sí?", "Te escucho.", name is null ? "Aquí estoy." : $"Dime, {name}."];
                string[] en = ["I'm here.", "Yes?", "Go ahead."];
                var pool = Cfg.S.Lang2 == "es" ? es : en;
                await speaker.Speak(pool[Random.Shared.Next(pool.Length)], ct); break;
            case "tono": System.Media.SystemSounds.Asterisk.Play(); await Task.Delay(250, ct); break;
        }
    }

    void Finish(CancellationTokenSource mine)
    {
        if (!ReferenceEquals(cts, mine)) return; // fue reemplazada por una sesión nueva: no ocultar el símbolo
        SetState(Cfg.S.Muted ? OrbState.Off : OrbState.Idle);
        ScheduleHide(900);
    }

    void ScheduleHide(int ms)
    {
        hideCts?.Cancel(); var h = hideCts = new CancellationTokenSource();
        Task.Delay(ms, h.Token).ContinueWith(t => { if (!t.IsCanceled && !Busy) Ui(() => overlay.HideOrb()); });
    }

    /// <summary>Aviso hablado (recordatorios y temporizadores). No interrumpe una conversación en curso.</summary>
    void Announce(string text)
    {
        Notice?.Invoke(text);
        if (Busy || Cfg.S.Muted) return;
        lock (gate)
        {
            var mine = new CancellationTokenSource(); cts = mine;
            session = Task.Run(async () =>
            {
                try { hideCts?.Cancel(); SetState(OrbState.Speaking); await speaker.Speak(text, mine.Token); }
                catch { }
                finally { Finish(mine); }
            });
        }
    }

    // ── IAgentIO ──
    public async Task Say(string text, CancellationToken ct) { SetState(OrbState.Speaking); await speaker.Speak(Txt.ForSpeech(text), ct); }
    public async Task<bool> Confirm(string question, CancellationToken ct)
    {
        SetState(OrbState.Speaking); await speaker.Speak(question, ct);
        SetState(OrbState.Listening);
        return await audio.ListenYesNo(ct) == true; // sin respuesta clara = no
    }
    public void Executing() => SetState(OrbState.Executing);
    public void Error() => SetState(OrbState.Error);

    public void Shutdown() { cts?.Cancel(); speaker.Stop(); audio.Dispose(); }
}
