using System;
using System.Diagnostics;
using System.Threading;
using System.Windows;
using Microsoft.Win32;
using WinForms = System.Windows.Forms;

namespace Veronica;

/// <summary>Inicio automático con Windows (solo si el usuario lo activa): clave HKCU\...\Run, sin permisos de administrador.</summary>
static class Autostart
{
    const string Key = @"Software\Microsoft\Windows\CurrentVersion\Run";
    public static void Set(bool on)
    {
        using var k = Registry.CurrentUser.OpenSubKey(Key, true); if (k is null) return;
        if (on) k.SetValue("Veronica", $"\"{Environment.ProcessPath}\" --background"); else k.DeleteValue("Veronica", false);
    }
}

static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        using var mutex = new Mutex(true, "Veronica.SingleInstance.v1", out var first);
        if (!first) return; // ya hay una Verónica residente

        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        var models = new ModelManager();
        var overlay = new OverlayWindow(); overlay.Init();
        var conductor = new Conductor(models, overlay);
        var settings = new SettingsWindow(models, conductor);
        Scheduler.Start();

        // Icono de bandeja: único elemento visible permanente (sin ventana principal).
        var tray = new WinForms.NotifyIcon { Icon = MakeIcon(), Text = "Verónica", Visible = true };
        var menu = new WinForms.ContextMenuStrip();
        menu.Items.Add("Activar ahora", null, (_, _) => conductor.OnWake());
        var mute = new WinForms.ToolStripMenuItem("Micrófono en pausa") { CheckOnClick = true, Checked = Cfg.S.Muted };
        mute.Click += (_, _) => conductor.SetMuted(mute.Checked);
        menu.Items.Add(mute);
        menu.Items.Add("Configuración…", null, (_, _) => { settings.Show(); settings.Activate(); });
        menu.Items.Add(new WinForms.ToolStripSeparator());
        menu.Items.Add("Salir", null, (_, _) => { tray.Visible = false; conductor.Shutdown(); app.Shutdown(); });
        tray.ContextMenuStrip = menu;
        tray.DoubleClick += (_, _) => { settings.Show(); settings.Activate(); };
        conductor.Notice += msg => app.Dispatcher.BeginInvoke(() => tray.ShowBalloonTip(6000, "Verónica", msg, WinForms.ToolTipIcon.Info));

        conductor.Start();
        // Primera vez o sin modelo: abre la configuración. Con --background (inicio automático) permanece oculta.
        if (!models.Installed || Array.IndexOf(args, "--background") < 0) { settings.Show(); }
        app.Run();
    }

    static System.Drawing.Icon MakeIcon()
    {
        using var bmp = new System.Drawing.Bitmap(32, 32);
        using (var g = System.Drawing.Graphics.FromImage(bmp))
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var b1 = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(200, 91, 75, 255));
            using var b2 = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(200, 224, 64, 154));
            using var b3 = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(200, 255, 179, 71));
            using var b4 = new System.Drawing.SolidBrush(System.Drawing.Color.FromArgb(255, 255, 244, 230));
            g.FillEllipse(b1, 12, 11, 18, 18); g.FillEllipse(b2, 3, 8, 18, 18); g.FillEllipse(b3, 8, 2, 17, 17); g.FillEllipse(b4, 11, 11, 10, 10);
        }
        return System.Drawing.Icon.FromHandle(bmp.GetHicon());
    }
}
