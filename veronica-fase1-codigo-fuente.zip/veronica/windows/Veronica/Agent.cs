using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Veronica;

/// <summary>Puente entre el cerebro y quien habla, escucha y confirma (el Conductor).</summary>
interface IAgentIO
{
    Task Say(string text, CancellationToken ct);
    Task<bool> Confirm(string question, CancellationToken ct);
    void Executing();
    void Error();
}

sealed record AgentReply(string Say, List<(string Name, JsonObject Args)> Calls, string FollowUp);

static class Reply
{
    public static AgentReply Parse(string raw)
    {
        int s = raw.IndexOf('{'), e = raw.LastIndexOf('}');
        if (s < 0 || e <= s) return new(raw.Trim(), new(), "open");
        try
        {
            var o = JsonNode.Parse(raw[s..(e + 1)])!.AsObject();
            var calls = new List<(string, JsonObject)>();
            if (o["tools"] is JsonArray a)
                foreach (var t in a.OfType<JsonObject>()) calls.Add((t["name"]?.ToString() ?? "", t["args"] as JsonObject ?? new JsonObject()));
            return new(o["say"]?.ToString() ?? "", calls, o["follow_up"]?.ToString() ?? "open");
        }
        catch { return new(raw.Trim(), new(), "open"); }
    }
}

/// <summary>Orden directa (sin IA): más rápida y funciona sin Internet.</summary>
static class OfflineRouter
{
    public sealed record Cmd(string Tool, JsonObject Args, string Say, bool Soft = false, bool Close = false);

    static Cmd C(string tool, string say, string? key = null, JsonNode? arg = null, bool soft = false, bool close = false)
    {
        var o = new JsonObject(); if (key is not null) o[key] = arg; return new(tool, o, say, soft, close);
    }

    public static string SayTime()
    {
        var n = DateTime.Now; var h12 = n.Hour % 12 == 0 ? 12 : n.Hour % 12;
        var part = n.Hour < 6 ? "de la madrugada" : n.Hour < 12 ? "de la mañana" : n.Hour < 19 ? "de la tarde" : "de la noche";
        return $"{(h12 == 1 ? "Es la" : "Son las")} {h12}:{n.Minute:00} {part}.";
    }
    public static string SayDate() => "Hoy es " + DateTime.Now.ToString("dddd d 'de' MMMM 'de' yyyy", new CultureInfo("es-MX")) + ".";

    static readonly string[] Folders = ["documentos", "descargas", "escritorio", "imagenes", "musica", "videos"];

    public static Cmd? Route(string raw)
    {
        var t = Txt.Norm(raw);
        if (t.Length == 0) return null;
        if (Regex.IsMatch(t, @"^(gracias|muchas gracias|nada mas|eso es todo|ya esta|cancela|cancelar|olvidalo|dejalo)( veronica)?$")) return C("", "Con gusto.", close: true);

        var m = Regex.Match(t, @"(temporizador|timer|cuenta regresiva).*?(\d+)\s*(segundo|minuto|hora)");
        if (m.Success)
        {
            int n = int.Parse(m.Groups[2].Value); var u = m.Groups[3].Value;
            return C("timer", $"Listo, temporizador de {n} {u}{(n == 1 ? "" : "s")}.", "seconds", n * (u == "segundo" ? 1 : u == "minuto" ? 60 : 3600));
        }
        if (Regex.IsMatch(t, @"\bque hora es\b|dime la hora|hora actual|me dices la hora")) return C("", SayTime());
        if (Regex.IsMatch(t, @"\bque dia es\b|fecha de hoy|que fecha es|a cuanto estamos")) return C("", SayDate());

        if (Regex.IsMatch(t, @"\b(sube|subir|aumenta|aumentar)\b.*volumen|mas volumen")) return C("volume", "Listo.", "action", "up");
        if (Regex.IsMatch(t, @"\b(baja|bajar|disminuye|reduce)\b.*volumen|menos volumen")) return C("volume", "Listo.", "action", "down");
        if (Regex.IsMatch(t, @"\b(silencia|mutea|silenciar)\b")) return C("volume", "Silenciado.", "action", "mute");

        if (Regex.IsMatch(t, @"^(pausa|pausar|pon pausa|deten|detener|para)( la)?( musica| cancion| reproduccion)?$")) return C("media", "", "action", "pause");
        if (Regex.IsMatch(t, @"^(siguiente|siguiente cancion|salta|salta la cancion|pasa la cancion)$")) return C("media", "", "action", "next");
        if (Regex.IsMatch(t, @"^(anterior|cancion anterior|regresa|regresa la cancion)$")) return C("media", "", "action", "previous");
        if (Regex.IsMatch(t, @"^(reanuda|continua|continua la musica|dale play|reproduce)$")) return C("media", "", "action", "play");

        if (Regex.IsMatch(t, @"(toma|haz|saca|tomar|hacer).*(captura|pantallazo)|captura de pantalla")) return C("screenshot", "");
        if (Regex.IsMatch(t, @"cancela.*(apagado|reinicio|apagar|reiniciar)")) return C("power", "Cancelado.", "action", "cancel");
        if (Regex.IsMatch(t, @"\b(bloquea|bloquear)\b.*(computadora|equipo|pantalla|pc|sesion)")) return C("power", "", "action", "lock");

        m = Regex.Match(t, @"^(abre|abrir|abreme)( mi| la| el)? (carpeta de |carpeta )?(" + string.Join("|", Folders) + ")$");
        if (m.Success && (m.Groups[3].Length > 0 || m.Groups[2].Value.Trim() == "mi")) return C("open_folder", "", "name", m.Groups[4].Value);

        m = Regex.Match(t, @"^(abre|abrir|abreme|inicia|lanza|ejecuta)( la app de| la aplicacion de| la app| la aplicacion| el| la| mi)? (.+)$");
        if (m.Success) return C("open_app", "", "name", m.Groups[3].Value, soft: true);
        return null;
    }
}

static class Prompt
{
    static string? tpl;
    public static string Build(ToolRegistry tools)
    {
        tpl ??= Embedded.Read("system_prompt.es-MX.txt");
        var s = Cfg.S;
        var facts = s.MemoryEnabled && !s.PrivateMode ? Cfg.M.Facts : new Dictionary<string, string>();
        var memoria = facts.Count == 0 ? "(sin datos guardados)" : string.Join("\n", facts.Select(f => $"- {f.Key}: {f.Value}"));
        var fecha = DateTime.Now.ToString("dddd d 'de' MMMM 'de' yyyy, HH:mm", new CultureInfo("es-MX")) + $" ({TimeZoneInfo.Local.Id})";
        return tpl.Replace("{{usuario}}", facts.TryGetValue("nombre", out var n) ? n : "su dueño").Replace("{{plataforma}}", "computadora con Windows")
            .Replace("{{fecha}}", fecha).Replace("{{idioma}}", s.Language).Replace("{{memoria}}", memoria).Replace("{{herramientas}}", tools.Catalog());
    }
}

static class Embedded
{
    public static string Read(string name)
    {
        using var st = Assembly.GetExecutingAssembly().GetManifestResourceStream(name) ?? throw new FileNotFoundException(name);
        using var r = new StreamReader(st, Encoding.UTF8); return r.ReadToEnd();
    }
}

/// <summary>Cerebro: 1) orden directa, 2) bucle IA + herramientas (máx. 4 vueltas), 3) respaldo sin Internet.</summary>
sealed class Agent(ToolRegistry tools)
{
    readonly List<Msg> history = new();
    DateTime lastAt = DateTime.MinValue;
    public string FollowUp { get; private set; } = "open";

    public async Task Handle(string text, IAgentIO io, CancellationToken ct)
    {
        var s = Cfg.S;
        if (DateTime.Now - lastAt > TimeSpan.FromMinutes(10)) history.Clear();
        lastAt = DateTime.Now; FollowUp = "open";
        Cfg.M.Log("user", text);

        var cmd = OfflineRouter.Route(text);
        if (cmd is not null)
        {
            var ok = true;
            if (cmd.Tool.Length > 0)
            {
                io.Executing();
                var res = await tools.Run(cmd.Tool, cmd.Args, io, ct);
                ok = !res.StartsWith("No encontré") && !res.StartsWith("Error") && !res.StartsWith("Falta");
                if (!ok && !cmd.Soft) { await io.Say(res, ct); Cfg.M.Log("assistant", res); return; }
                if (ok && cmd.Say.Length == 0 && cmd.Tool is "open_app" or "open_folder") { await io.Say(res, ct); Cfg.M.Log("assistant", res); }
            }
            if (ok)
            {
                if (cmd.Say.Length > 0) { await io.Say(cmd.Say, ct); Cfg.M.Log("assistant", cmd.Say); }
                FollowUp = cmd.Close ? "close" : "open";
                return;
            }
        }

        if (s.OfflineOnly || !Net.Online)
        {
            const string m = "Ahora mismo estoy sin conexión. Puedo ayudarte con comandos básicos como abrir programas, temporizadores, volumen, la hora o tus notas.";
            await io.Say(m, ct); Cfg.M.Log("assistant", m); return;
        }
        if (s.LlmKey.Length == 0 && s.LlmBaseUrl.StartsWith("https://"))
        {
            const string m = "Todavía no tengo configurada mi inteligencia. Abre mi configuración y agrega una clave de API.";
            await io.Say(m, ct); Cfg.M.Log("assistant", m); return;
        }

        var system = Prompt.Build(tools);
        var msgs = new List<Msg>(history) { new("user", text) };
        var spoken = new StringBuilder();
        try
        {
            for (int step = 0; step < 4; step++)
            {
                var raw = await Llms.Current().Chat(system, msgs, ct);
                var r = Reply.Parse(raw);
                msgs.Add(new("assistant", raw));
                if (r.Say.Length > 0) { await io.Say(r.Say, ct); spoken.Append(r.Say).Append(' '); }
                FollowUp = r.FollowUp;
                if (r.Calls.Count == 0) break;
                io.Executing();
                var results = new List<string>();
                foreach (var (name, args) in r.Calls.Take(4))
                    results.Add(new JsonObject { ["tool"] = name, ["result"] = await tools.Run(name, args, io, ct) }.ToJsonString());
                msgs.Add(new("user", "RESULTADOS_DE_HERRAMIENTAS:\n" + string.Join("\n", results)));
            }
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception)
        {
            io.Error();
            await io.Say("No pude conectarme con mi inteligencia. Revisa tu conexión o la configuración de la API.", ct);
            return;
        }
        if (spoken.Length == 0) { await io.Say("Listo.", ct); spoken.Append("Listo."); }
        var final = spoken.ToString().Trim();
        Cfg.M.Log("assistant", final);
        history.Add(new("user", text));
        history.Add(new("assistant", new JsonObject { ["say"] = final, ["tools"] = new JsonArray(), ["follow_up"] = FollowUp }.ToJsonString()));
        while (history.Count > 16) history.RemoveAt(0);
    }
}
