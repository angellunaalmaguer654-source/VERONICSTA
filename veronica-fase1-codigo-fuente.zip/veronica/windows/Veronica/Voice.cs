using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using NAudio.Wave;
using Vosk;
using Windows.Media.Core;
using Windows.Media.Playback;
using Windows.Media.SpeechSynthesis;

namespace Veronica;

/// <summary>Descarga (una vez, ~40 MB) y carga el modelo de voz local en español.</summary>
sealed class ModelManager
{
    const string Url = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip";
    readonly string root = Path.Combine(Cfg.Dir, "vosk");
    string Dir => Path.Combine(root, "vosk-model-small-es-0.42");
    Model? model;
    public bool Installed => Directory.Exists(Path.Combine(Dir, "am"));

    public Model GetModel()
    {
        if (model is null) { global::Vosk.Vosk.SetLogLevel(-1); model = new Model(Dir); }
        return model;
    }

    public async Task Download(IProgress<int> progress, CancellationToken ct)
    {
        Directory.CreateDirectory(root);
        var tmp = Path.Combine(Path.GetTempPath(), "vosk-model.zip");
        using (var http = new HttpClient { Timeout = TimeSpan.FromMinutes(15) })
        using (var r = await http.GetAsync(Url, HttpCompletionOption.ResponseHeadersRead, ct))
        {
            r.EnsureSuccessStatusCode();
            var total = r.Content.Headers.ContentLength ?? 0; long done = 0;
            await using var input = await r.Content.ReadAsStreamAsync(ct);
            await using var output = File.Create(tmp);
            var buf = new byte[64 * 1024]; int n;
            while ((n = await input.ReadAsync(buf, ct)) > 0)
            {
                await output.WriteAsync(buf.AsMemory(0, n), ct); done += n;
                if (total > 0) progress.Report((int)(done * 90 / total));
            }
        }
        ZipFile.ExtractToDirectory(tmp, root, overwriteFiles: true); // .NET rechaza rutas con ".." (zip-slip)
        File.Delete(tmp); progress.Report(100);
    }
}

/// <summary>
/// Único dueño del micrófono. Un solo flujo alterna entre:
///  Wake - Vosk con gramática restringida a la palabra de activación (100 % local).
///  Capture - graba una frase y detecta el final con un detector de voz (VAD).
///  YesNo - Vosk con gramática de sí/no para confirmaciones (100 % local).
/// </summary>
sealed class AudioEngine(ModelManager models) : IDisposable
{
    public const int Rate = 16000;
    enum Mode { Wake, Capture, YesNo }

    volatile Mode mode = Mode.Wake;
    volatile Capture? capture;
    volatile YesNo? yesNo;
    WaveInEvent? wave;
    VoskRecognizer? wake;
    string[] wakeNorm = [];
    long cooldownUntil;
    Action onWake = () => { };

    public Action<float> OnLevel = _ => { };
    public Action<string> OnFail = _ => { };
    public bool Running => wave is not null;

    public void Start(string[] phrases, Action onWakeCb)
    {
        if (Running) return;
        onWake = onWakeCb; wakeNorm = phrases.Select(Txt.Norm).ToArray();
        // Se crea en un hilo del pool para que NAudio no entregue el audio en el hilo de la interfaz.
        Task.Run(() =>
        {
            try
            {
                wake = new VoskRecognizer(models.GetModel(), Rate, JsonSerializer.Serialize(phrases.Append("[unk]")));
                var w = new WaveInEvent { WaveFormat = new WaveFormat(Rate, 16, 1), BufferMilliseconds = 100 };
                w.DataAvailable += OnData;
                w.RecordingStopped += (_, e) => { if (e.Exception is not null) OnFail("Error del micrófono: " + e.Exception.Message); };
                w.StartRecording(); wave = w;
            }
            catch (Exception e) { OnFail("No pude abrir el micrófono: " + e.Message); }
        });
    }

    /// <summary>Suelta el micrófono por completo (el indicador de privacidad de Windows se apaga).</summary>
    public void Stop()
    {
        var w = wave; wave = null;
        if (w is not null) { w.DataAvailable -= OnData; try { w.StopRecording(); } catch { } w.Dispose(); }
        wake?.Dispose(); wake = null;
    }

    public async Task<byte[]?> CaptureUtterance(int timeoutMs, CancellationToken ct, int maxMs = 15000)
    {
        if (!Running) return null;
        var c = new Capture(timeoutMs, maxMs); capture = c; mode = Mode.Capture;
        using var reg = ct.Register(() => c.Done.TrySetCanceled());
        try { return await c.Done.Task; } finally { mode = Mode.Wake; capture = null; }
    }

    public async Task<bool?> ListenYesNo(CancellationToken ct, int timeoutMs = 7000)
    {
        if (!Running) return null;
        var y = new YesNo(new VoskRecognizer(models.GetModel(), Rate, YesNo.Grammar)); yesNo = y; mode = Mode.YesNo;
        using var reg = ct.Register(() => y.Done.TrySetCanceled());
        try { var t = y.Done.Task; return await Task.WhenAny(t, Task.Delay(timeoutMs, ct)) == t ? await t : null; }
        finally { mode = Mode.Wake; yesNo = null; y.Dispose(); }
    }

    void OnData(object? s, WaveInEventArgs e)
    {
        int n = e.BytesRecorded; if (n <= 0) return;
        double sum = 0; int samples = n / 2;
        for (int i = 0; i < samples; i++) { short v = BitConverter.ToInt16(e.Buffer, i * 2); sum += (double)v * v; }
        double rms = Math.Sqrt(sum / Math.Max(1, samples));
        OnLevel((float)Math.Min(1.0, rms / 5000.0));
        switch (mode)
        {
            case Mode.Wake:
                var r = wake; if (r is null) return;
                var text = r.AcceptWaveform(e.Buffer, n) ? JsonNode.Parse(r.Result())?["text"]?.ToString() : JsonNode.Parse(r.PartialResult())?["partial"]?.ToString();
                var now = Environment.TickCount64;
                if (!string.IsNullOrWhiteSpace(text) && now > cooldownUntil)
                {
                    var t = Txt.Norm(text);
                    if (wakeNorm.Any(w => w.Length > 0 && t.Contains(w))) { r.Reset(); cooldownUntil = now + 1500; Task.Run(onWake); }
                }
                break;
            case Mode.Capture: capture?.Feed(e.Buffer, n, rms); break;
            case Mode.YesNo: yesNo?.Feed(e.Buffer, n); break;
        }
    }

    public void Dispose() => Stop();

    /// <summary>Graba hasta detectar silencio (900 ms tras al menos 300 ms de voz).</summary>
    sealed class Capture(int timeoutMs, int maxMs)
    {
        public readonly TaskCompletionSource<byte[]?> Done = new(TaskCreationOptions.RunContinuationsAsynchronously);
        readonly MemoryStream buf = new(); readonly Stopwatch clock = Stopwatch.StartNew();
        double noise = -1; int voiced; long lastVoice; bool inSpeech;
        public void Feed(byte[] b, int n, double rms)
        {
            var now = clock.ElapsedMilliseconds; buf.Write(b, 0, n);
            if (noise < 0) noise = rms; else if (!inSpeech) noise = noise * 0.9 + rms * 0.1;
            if (rms > Math.Max(500, noise * 2.5)) { voiced++; lastVoice = now; if (voiced >= 3) inSpeech = true; }
            if (inSpeech && now - lastVoice > 900) Done.TrySetResult(buf.ToArray());
            else if (!inSpeech && voiced > 0 && now - lastVoice > 400) voiced = 0; // ruido breve
            else if (!inSpeech && now > timeoutMs) Done.TrySetResult(null);
            else if (now > maxMs) Done.TrySetResult(inSpeech ? buf.ToArray() : null);
        }
    }

    sealed class YesNo(VoskRecognizer rec) : IDisposable
    {
        public const string Grammar = "[\"sí\",\"si\",\"no\",\"claro\",\"confirmo\",\"confirmado\",\"adelante\",\"hazlo\",\"dale\",\"cancela\",\"cancelar\",\"detente\",\"[unk]\"]";
        static readonly HashSet<string> Neg = ["no", "cancela", "cancelar", "detente"];
        static readonly HashSet<string> Pos = ["si", "claro", "confirmo", "confirmado", "adelante", "hazlo", "dale"];
        public readonly TaskCompletionSource<bool?> Done = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public void Feed(byte[] b, int n)
        {
            var text = rec.AcceptWaveform(b, n) ? JsonNode.Parse(rec.Result())?["text"]?.ToString() : JsonNode.Parse(rec.PartialResult())?["partial"]?.ToString();
            var words = Txt.Norm(text ?? "").Split(' ');
            if (words.Any(Neg.Contains)) Done.TrySetResult(false); // ante la duda, cancelar
            else if (words.Any(Pos.Contains)) Done.TrySetResult(true);
        }
        public void Dispose() => rec.Dispose();
    }
}

/// <summary>Voz a texto: nube (alta calidad) con respaldo local. El audio nunca se escribe en disco.</summary>
static class Stt
{
    public static async Task<string> Transcribe(byte[] pcm, ModelManager models, CancellationToken ct)
    {
        var s = Cfg.S;
        if (!s.OfflineOnly && Net.Online && s.SttKey.Length > 0)
        {
            try { return await Cloud(pcm, ct); } catch (OperationCanceledException) { throw; } catch { /* cae al modo local */ }
        }
        return await Task.Run(() => Offline(pcm, models), ct);
    }

    static byte[] Wav(byte[] pcm)
    {
        using var ms = new MemoryStream(); using var w = new BinaryWriter(ms);
        w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + pcm.Length); w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
        w.Write(16); w.Write((short)1); w.Write((short)1); w.Write(AudioEngine.Rate); w.Write(AudioEngine.Rate * 2); w.Write((short)2); w.Write((short)16);
        w.Write(Encoding.ASCII.GetBytes("data")); w.Write(pcm.Length); w.Write(pcm); w.Flush(); return ms.ToArray();
    }

    static async Task<string> Cloud(byte[] pcm, CancellationToken ct)
    {
        var s = Cfg.S;
        var form = new MultipartFormDataContent
        {
            { new StringContent(s.SttModel), "model" }, { new StringContent(s.Lang2), "language" },
            { new StringContent("Verónica, asistente personal. Oye Verónica."), "prompt" }, { new StringContent("json"), "response_format" },
        };
        var file = new ByteArrayContent(Wav(pcm)); file.Headers.ContentType = new MediaTypeHeaderValue("audio/wav"); form.Add(file, "file", "audio.wav");
        var req = new HttpRequestMessage(HttpMethod.Post, s.SttBaseUrl.TrimEnd('/') + "/audio/transcriptions") { Content = form };
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", s.SttKey);
        return (JsonNode.Parse(await Net.Text(req, ct))?["text"]?.ToString() ?? "").Trim();
    }

    static string Offline(byte[] pcm, ModelManager models)
    {
        using var r = new VoskRecognizer(models.GetModel(), AudioEngine.Rate);
        for (int i = 0; i < pcm.Length; i += 8000) r.AcceptWaveform(pcm.AsSpan(i, Math.Min(8000, pcm.Length - i)).ToArray(), Math.Min(8000, pcm.Length - i));
        return (JsonNode.Parse(r.FinalResult())?["text"]?.ToString() ?? "").Trim();
    }
}

/// <summary>Voz del sistema (gratis, sin Internet). Usa la voz es-MX instalada en Windows si existe.</summary>
sealed class SystemTts
{
    readonly SpeechSynthesizer synth = new(); MediaPlayer? player;

    public async Task Speak(string text, string lang, CancellationToken ct)
    {
        var voices = SpeechSynthesizer.AllVoices;
        var v = voices.FirstOrDefault(x => x.Language.Equals(lang, StringComparison.OrdinalIgnoreCase))
             ?? voices.FirstOrDefault(x => x.Language.StartsWith(lang[..2], StringComparison.OrdinalIgnoreCase));
        if (v is not null) synth.Voice = v;
        using var stream = await synth.SynthesizeTextToStreamAsync(text);
        var done = new TaskCompletionSource();
        var p = new MediaPlayer { Source = MediaSource.CreateFromStream(stream, stream.ContentType) }; player = p;
        p.MediaEnded += (_, _) => done.TrySetResult(); p.MediaFailed += (_, _) => done.TrySetResult();
        using var reg = ct.Register(() => { try { p.Pause(); } catch { } done.TrySetCanceled(); });
        p.Play();
        try { await done.Task; } finally { p.Dispose(); player = null; }
    }
    public void Stop() { try { player?.Pause(); } catch { } }
}

/// <summary>Voz neuronal en la nube (/audio/speech, compatible con OpenAI). Más natural; requiere clave e Internet.</summary>
sealed class CloudTts
{
    WaveOutEvent? output;
    public async Task Speak(string text, CancellationToken ct)
    {
        var s = Cfg.S;
        var req = new HttpRequestMessage(HttpMethod.Post, s.TtsBaseUrl.TrimEnd('/') + "/audio/speech")
        { Content = Net.Json(new JsonObject { ["model"] = s.TtsModel, ["voice"] = s.TtsVoice, ["input"] = text, ["response_format"] = "mp3" }) };
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", s.TtsKey);
        var file = Path.Combine(Path.GetTempPath(), $"veronica-tts-{Guid.NewGuid():N}.mp3");
        await File.WriteAllBytesAsync(file, await Net.Bytes(req, ct), ct);
        try
        {
            using var reader = new MediaFoundationReader(file);
            using var o = new WaveOutEvent(); output = o;
            var done = new TaskCompletionSource();
            o.PlaybackStopped += (_, _) => done.TrySetResult();
            using var reg = ct.Register(() => { try { o.Stop(); } catch { } done.TrySetCanceled(); });
            o.Init(reader); o.Play();
            await done.Task;
        }
        finally { output = null; try { File.Delete(file); } catch { } }
    }
    public void Stop() { try { output?.Stop(); } catch { } }
}

/// <summary>Elige nube o sistema, y cae al sistema si la nube falla.</summary>
sealed class SpeakerHub
{
    readonly SystemTts system = new(); readonly CloudTts cloud = new();
    public async Task Speak(string text, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        var s = Cfg.S;
        if (s.TtsMode == "cloud" && s.TtsKey.Length > 0 && Net.Online && !s.OfflineOnly)
        {
            try { await cloud.Speak(text, ct); return; } catch (OperationCanceledException) { throw; } catch { /* respaldo */ }
        }
        await system.Speak(text, s.Language, ct);
    }
    public void Stop() { system.Stop(); cloud.Stop(); }
}
