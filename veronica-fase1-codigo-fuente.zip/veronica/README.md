# VERÓNICA — asistente personal de voz (Android + Windows)

Asistente que vive en segundo plano, se despierta con **«Oye Verónica»** y responde con voz.
Su interfaz es un único símbolo animado que aparece solo cuando se le necesita.

> **Estado: Fase 1 (código fuente completo, sin compilar ni probar en dispositivo).**
> Este código se escribió en un entorno sin Android SDK, Gradle ni .NET, así que **no se ha compilado ni ejecutado todavía**.
> Es de esperar algún error de compilación menor en la primera construcción; el flujo de `.github/workflows/build.yml`
> compila todo en la nube y te muestra los errores exactos para corregirlos rápido. Ver `docs/03`.

## Qué hay

| Carpeta | Contenido |
|---|---|
| `shared/` | Personalidad (prompt) y catálogo de 39 herramientas, **compartidos por ambas plataformas** (cada una expone las que puede) |
| `android/` | App nativa Kotlin: servicio de micrófono, asistente del sistema, símbolo flotante, 33 herramientas |
| `windows/` | App .NET 8 (WPF) residente en bandeja: símbolo flotante, 25 herramientas, EXE único |
| `docs/` | Viabilidad, arquitectura, instalación, APIs, privacidad, hoja de ruta |
| `.github/workflows/` | Compilación en la nube de APK, AAB y EXE |

## Estado de cada función (Fase 1)

| Función | Android | Windows |
|---|:-:|:-:|
| Palabra de activación local (personalizable) | ✅ | ✅ |
| Símbolo animado por estados (7) | ✅ | ✅ |
| Voz a texto (nube + respaldo local) | ✅ | ✅ |
| Texto a voz (sistema + neuronal en nube) | ✅ | ✅ |
| Conversación con contexto y seguimiento | ✅ | ✅ |
| Proveedores de IA intercambiables | ✅ | ✅ |
| Órdenes directas sin Internet | ✅ | ✅ |
| Memoria con consentimiento, revisable y borrable | ✅ | ✅ |
| Confirmación por voz de acciones sensibles | ✅ | ✅ |
| Interrumpirla al hablar | ✅ | ⚠️ solo con audífonos |
| Reiniciar y seguir escuchando sin tocar nada | ⚠️ requiere ser el asistente predeterminado | ✅ con «Iniciar con Windows» |
| Actualización automática | — | ⏳ Fase 2 |
| Motor Porcupine (menor consumo) | ⏳ Fase 2 | ⏳ Fase 2 |
| Panel web complementario (HTML) | ⏳ Fase 3 | ⏳ Fase 3 |

Léelo todo en orden: `docs/01` (lo que Android y Windows **no** permiten) → `docs/03` (cómo instalar) → `docs/04` (claves de API).
